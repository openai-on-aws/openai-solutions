# Workshop Orchestration Contract

This file defines the internal handoffs behind the participant-facing task prompts. The lead Codex Desktop session resolves these inputs automatically; participants should not be asked to enumerate files or schemas.

## Operating Pattern

For each task:

1. Confirm the previous task's outcome and locate the canonical inputs below.
2. Validate required JSON inputs against their checked-in schemas.
3. Invoke the named agent when one is assigned, pass the validated inputs and expected output, and wait for completion.
4. Validate the new deliverable and summarize the result in plain language.
5. Report a prerequisite blocker rather than improvising missing evidence.

Repository-supported checks should be selected for the discovered application. Do not perform irrelevant commands merely to satisfy a checklist.

## Source Baseline

### Start source application

- Owner: lead session
- Inputs: `migration-context.json`, `source-architecture.md`, selected source root
- Work: discover and run the source's supported local components; prefer an existing credential-free profile
- Output: `source-runtime.md`

### Validate source application

- Owner: `migration-validation`
- Inputs: `migration-context.json`, `source-runtime.md`, selected source root
- Work: capture representative build, API, browser, state, error, health, provider, and observability behavior
- Output: `source-validation.md`

## Migration Analysis

### Discover source

- Owner: `migration-discovery`
- Inputs: `migration-context.json`, `source-runtime.md`, `source-validation.md`, `schemas/source-profile.schema.json`
- Output: schema-valid `source-profile.json`

### Rank AWS architecture

- Owner: `migration-architect`
- Inputs: `migration-context.json`, `source-profile.json`, `source-validation.md`, `schemas/architecture-decision.schema.json`
- Output: schema-valid `architecture-decision.json`

### Map Chat Completions to Responses

- Owner: `migration-architect`
- Inputs: `migration-context.json`, `source-profile.json`, `source-validation.md`, `architecture-decision.json`, `schemas/model-api-decision.schema.json`
- Output: provisional, schema-valid `model-api-decision.json`

### Challenge decisions

- Owner: `migration-validation`
- Inputs: migration context, source profile and baseline, architecture decision, model/API decision, corresponding schemas
- Output: `migration-findings.md` with identifiers, evidence, severity, remediation, owner, and status

### Resolve findings

- Owner: `migration-architect`
- Inputs: canonical migration artifacts and `migration-findings.md`
- Outputs: updated schema-valid decisions, `migration-resolution.md`, and `migration-guide.md`

## Model And Migration Approval

### Verify live Bedrock tuple

- Owner: lead session
- Inputs: validated migration context and provisional model/API decision
- Human action: securely provide the Amazon Bedrock API key in the terminal
- Work: query the selected Region's Models API, verify the exact model, update the availability decision with redacted evidence, and clear the key
- Output: accepted, live-verified, schema-valid `model-api-decision.json`

### Approve migration

- Owner: lead session
- Inputs: all resolved migration contract artifacts
- Human action: enter `APPROVE MIGRATION` after reviewing the presented contract
- Output: `migration-approval.md` containing the exact token, approved scope, artifact digests, and timestamp

## Target Implementation

### Generate target

- Owner: lead session
- Inputs: migration approval and current validated contract artifacts
- Work: generate only within the configured target root, preserve approved behavior, and run relevant build/static checks
- Output: generated target and `target-generation.md`

### Validate generated target

- Owner: `migration-validation`
- Inputs: source baseline, approved decisions, resolution, generation report, target root, and schemas
- Work: credential-free build, provider replacement, contract parity, secret, fallback, request, parsing, and architecture checks
- Output: `target-validation.md`

### Validate local target live

- Owner: lead session starts the target; `migration-validation` validates it
- Inputs: accepted model/API decision, source baseline, target validation, and target root
- Human action: securely provide the Amazon Bedrock API key in the target terminal
- Work: repeat representative API and browser workflows against live Bedrock without passing the key to the agent
- Output: `live-target-validation.md`; clear the key after the run

## Deployment Packaging

### Generate package

- Owner: `aws-deployment-engineer`
- Inputs: approved migration artifacts, validated target evidence, target root, deployment schema, and CDK scaffold
- Outputs: schema-valid `deployment-manifest.json`, generated CDK package, and `production-data-migration-plan.md` when stateful data exists
- Boundary: do not contact AWS or create resources

### Validate package

- Owner: `migration-validation`
- Inputs: deployment manifest, architecture and model decisions, target root, generated CDK, and schemas
- Work: relevant builds, artifact architecture, CDK type check and synthesis, template, IAM, network, secrets, health, rollback, cost, and teardown review
- Output: `deployment-validation.md`

### Preflight AWS

- Owner: `aws-deployment-engineer`
- Inputs: validated deployment package and accepted model decision
- Work: read-only identity, Region, service, bootstrap, permission, quota, model, cost, rollback, teardown, and CDK diff checks
- Output: `aws-preflight.md`

## Deployment And Validation

### Deploy

- Owner: lead session presents impact; `aws-deployment-engineer` operates after approval
- Inputs: validated manifest, package, deployment validation, and preflight
- Human action: enter `DEPLOY`
- Output: `aws-deployment.md` with redacted resources, outputs, readiness, rollback, and cleanup identifiers

### Validate deployed application

- Owner: `migration-validation`
- Inputs: source and local-target baselines, deployment manifest, and deployment record
- Work: representative public API/browser workflows, persistence, errors, selected inference path, and redacted operational correlation
- Output: `deployed-application-validation.md`

## Reusable Plugin Packaging

### Package the migration workflow

- Owner: lead session using the installed plugin-creation workflow
- Inputs: current workshop rules, agent contracts, architecture guidance, schemas, validators, deployment archetype factory, and redacted lessons from the validated migration
- Work: create a source-agnostic Codex plugin named `azure-bedrock-migration` under `plugins/`; include a lead migration skill, specialist role templates or skills, orchestration assets, schemas, validation scripts, AWS grounding, and deployment guidance
- Boundaries: preserve credential and approval controls; exclude the bundled application's implementation, generated target, secrets, account identifiers, generated evidence, build output, and source-specific assumptions
- Validation: validate the plugin manifest and skills, scan the package, and run a discovery-only dry run against the bundled source without modifying either application
- Outputs: `plugins/azure-bedrock-migration`, `plugin-validation.md`, and `plugin-usage.md`

Do not install the plugin or modify a personal or team marketplace without separate participant approval. The package must accept a source folder and automatically coordinate the same migration stages and human gates demonstrated in the workshop.

## Teardown

### Destroy

- Owner: lead session presents impact; `aws-deployment-engineer` operates after approval
- Inputs: deployment manifest, deployment record, and deployed validation
- Human action: enter `DESTROY`
- Output: `aws-teardown.md` listing deleted, retained, failed-delete, and still-billable resources

Do not declare teardown complete while an unintended billable workshop resource remains.
