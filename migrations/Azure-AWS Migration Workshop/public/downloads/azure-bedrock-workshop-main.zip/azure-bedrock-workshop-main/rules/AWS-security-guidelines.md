# AWS Security Guidelines

Apply these rules to any code, documentation, or generated target work that interacts with AWS.

## Identity And Scope

- Run `aws sts get-caller-identity` before account-specific AWS operations.
- Prefer read-only credentials for discovery and review.
- Use least-privilege IAM for every runtime role, CI role, and operator role.
- Do not broaden IAM permissions to unblock implementation without explicit approval.

## Secrets

- Never commit credentials, tokens, private keys, or generated secrets.
- Keep `OPENAI_API_KEY`, database passwords, bearer tokens, and cloud credentials in terminal environment variables or managed secret stores.
- In this workshop, `OPENAI_API_KEY` is an Amazon Bedrock API key for the Bedrock Mantle OpenAI-compatible endpoint, not an OpenAI Platform key.
- Use AWS Secrets Manager for hosted runtime secrets.
- Prefer workload identity for deployed services. If AgentCore is selected by evidence, use its supported IAM identity pattern rather than storing a long-term API key.
- Redact account identifiers when sharing outside the trusted workshop context if required by policy.

## Data Protection

- Encrypt stateful resources at rest and in transit.
- Prefer customer-managed AWS KMS keys when key ownership, rotation, or audit controls matter.
- Do not log prompts, responses, request headers, or secrets that may contain sensitive data.

## Network And Access

- Avoid public exposure by default.
- Use private networking and security groups for hosted databases.
- Public endpoints must have a documented reason, logging, and appropriate access controls.
- Derive network controls from the selected archetype. Document every public ingress and egress path.

## Logging And Audit

- Prefer structured application logs without sensitive values.
- Capture target service errors, latency, model IDs, and provider status codes.
- Use Amazon CloudWatch for hosted runtime logs and metrics.
- Do not log AgentCore invocation payloads, Mantle authorization headers, short-term tokens, database credentials, or complete model responses.

## Destructive Operations

Never deploy without the exact `DEPLOY` approval and never tear down without the exact `DESTROY` approval. Production resources and production data remain out of scope.
