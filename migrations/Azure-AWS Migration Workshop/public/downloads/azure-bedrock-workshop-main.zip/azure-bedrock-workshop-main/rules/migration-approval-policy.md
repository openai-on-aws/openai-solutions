# Migration Approval Policy

The main Codex Desktop session owns approval boundaries. Agents analyze and recommend; they do not infer authorization.

## APPROVE MIGRATION

Before generating or materially changing the target, present:

- selected source and target roots;
- validated source behavior and public interfaces;
- ranked AWS archetypes and selected architecture;
- complete Bedrock model/API/Region/endpoint tuple;
- accepted model/API decision with redacted live `/v1/models` evidence;
- Chat Completions-to-Responses transformations;
- behavior, cost, security, data, and operational risks;
- proposed remediation and acceptance checks.

Proceed only after the participant enters `APPROVE MIGRATION` in the current session. Record digests for the accepted model/API decision and the other approved contract artifacts; later target and deployment work must reject changed or unmatched digests.

## DEPLOY

Before creating AWS resources, present read-only identity and Region checks, model availability, quota and permission findings, synthesized resources, estimated cost drivers, `cdk diff`, and teardown inventory. Proceed only after `DEPLOY`.

## DESTROY

Before teardown, present the deployed inventory and retained shared resources. Proceed only after `DESTROY`, then verify that workshop-created billable resources have been removed.

No approval authorizes production data movement. Production migration remains a separate reviewed plan.
