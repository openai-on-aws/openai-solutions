# Execution Hygiene

These rules apply to workspace commands, generated artifacts, and migration validation.

## Non-Interactive Commands

Commands must not block on prompts, pagers, editors, or interactive wizards.

Use non-interactive patterns:

| Tool | Pattern |
|---|---|
| git | `git --no-pager <cmd>` |
| aws | `aws ... --no-cli-pager --output json` |
| npm | `npm install` or `npm ci` |
| npx | `npx --yes <package>` |
| Maven | `./mvnw package -DskipTests` |
| curl | `curl -sS ...` |

If a command requires login or browser interaction, ask the participant to complete that setup step.

## Dependency Isolation

- Never install project dependencies globally.
- Use local language tooling, Maven wrappers, and workspace `node_modules`.
- Commit lock files only when they belong to the source project.
- Keep generated dependency directories and caches out of git.

## Verification Notes

When verification fails:

- Record the exact command.
- Keep failure output concise.
- Distinguish missing credentials from application defects.
- Do not mark work complete until the issue is fixed or explicitly accepted.
