from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Sequence
from urllib.parse import urlparse


SUPPORTED_MODEL_REGIONS = {
    "openai.gpt-5.4": {"us-east-1", "us-east-2", "us-west-2"},
    "openai.gpt-5.5": {"us-east-1", "us-east-2"},
}
SUPPORTED_ARCHETYPES = {
    "static-web",
    "serverless-http",
    "public-web-container",
    "private-container-service",
    "event-worker",
    "kubernetes",
}
ARCHETYPE_ALIASES = {
    "static-web": "static-web",
    "s3-cloudfront": "static-web",
    "amazon-s3-amazon-cloudfront": "static-web",
    "serverless-http": "serverless-http",
    "lambda-api-gateway": "serverless-http",
    "aws-lambda-amazon-api-gateway": "serverless-http",
    "public-web-container": "public-web-container",
    "app-runner": "public-web-container",
    "aws-app-runner": "public-web-container",
    "private-container-service": "private-container-service",
    "ecs-fargate": "private-container-service",
    "amazon-ecs-on-aws-fargate": "private-container-service",
    "event-worker": "event-worker",
    "lambda-event-worker": "event-worker",
    "kubernetes": "kubernetes",
    "eks": "kubernetes",
    "amazon-eks": "kubernetes",
}
ASSET_ARCHETYPES = {
    "static-web",
    "serverless-http",
    "public-web-container",
    "private-container-service",
    "event-worker",
    "kubernetes",
}
CONTAINER_ARCHETYPES = {
    "public-web-container",
    "private-container-service",
    "kubernetes",
}
IGNORED_DIRECTORIES = {
    ".git",
    ".mypy_cache",
    ".next",
    ".pytest_cache",
    ".ruff_cache",
    ".terraform",
    ".venv",
    "__pycache__",
    "build",
    "cdk.out",
    "coverage",
    "dist",
    "node_modules",
    "target",
    "venv",
}
TEXT_SUFFIXES = {
    ".cfg",
    ".conf",
    ".css",
    ".env",
    ".go",
    ".gradle",
    ".html",
    ".ini",
    ".java",
    ".js",
    ".json",
    ".jsx",
    ".kt",
    ".md",
    ".mjs",
    ".properties",
    ".py",
    ".rb",
    ".rs",
    ".sh",
    ".sql",
    ".toml",
    ".ts",
    ".tsx",
    ".txt",
    ".xml",
    ".yaml",
    ".yml",
}
SENSITIVE_PATTERNS = {
    "AWS access key": re.compile(r"\b(?:AKIA|ASIA)[A-Z0-9]{16}\b"),
    "private key": re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----"),
    "API key": re.compile(r"\bsk-[A-Za-z0-9_-]{20,}\b"),
    "GitHub token": re.compile(r"\bgh[pousr]_[A-Za-z0-9]{20,}\b"),
    "JWT": re.compile(
        r"\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b"
    ),
}
LOCAL_PATH_PATTERN = re.compile(r"(?:/Users/[^/\s]+/|/home/[^/\s]+/|[A-Za-z]:\\Users\\[^\\\s]+\\)")


class Validation:
    def __init__(self) -> None:
        self.failures: list[str] = []
        self.warnings: list[str] = []

    def passed(self, message: str) -> None:
        print(f"[PASS] {message}")

    def failed(self, message: str) -> None:
        self.failures.append(message)
        print(f"[FAIL] {message}")

    def warned(self, message: str) -> None:
        self.warnings.append(message)
        print(f"[WARN] {message}")


@dataclass(frozen=True)
class ModelDecision:
    model_id: str
    region: str
    inference_url: str
    status: str
    source_path: Path | None


@dataclass(frozen=True)
class ManifestView:
    path: Path
    document: dict[str, Any]
    manifest_id: str
    status: str
    region: str
    archetype: str
    runtime: str
    source_paths: tuple[str, ...]
    containers: tuple[dict[str, Any], ...]
    integrations: tuple[dict[str, Any], ...]
    data: tuple[dict[str, Any], ...]
    secrets: tuple[dict[str, Any], ...]
    approvals: tuple[dict[str, Any], ...]
    validation_gates: tuple[dict[str, Any], ...]
    agentcore: dict[str, Any]
    teardown: tuple[dict[str, Any], ...]

    @property
    def agentcore_enabled(self) -> bool:
        return self.agentcore.get("enabled") is True


def _run(
    command: Sequence[str],
    cwd: Path | None = None,
    timeout: int = 60,
) -> subprocess.CompletedProcess[str]:
    environment = os.environ.copy()
    environment["AWS_PAGER"] = ""
    try:
        return subprocess.run(
            list(command),
            cwd=cwd,
            check=False,
            capture_output=True,
            text=True,
            timeout=timeout,
            env=environment,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        return subprocess.CompletedProcess(list(command), 127, "", type(exc).__name__)


def _load_json(path: Path, label: str, validation: Validation) -> dict[str, Any] | None:
    if not path.is_file():
        validation.failed(f"{label} is missing: {path}")
        return None
    try:
        document = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        validation.failed(f"{label} is not valid JSON: {type(exc).__name__}")
        return None
    if not isinstance(document, dict):
        validation.failed(f"{label} root must be a JSON object")
        return None
    return document


def _objects(value: Any, field: str, validation: Validation) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        validation.failed(f"Manifest field {field} must be an array")
        return []
    result: list[dict[str, Any]] = []
    for index, item in enumerate(value):
        if not isinstance(item, dict):
            validation.failed(f"Manifest field {field}[{index}] must be an object")
        else:
            result.append(item)
    return result


def _strings(value: Any, field: str, validation: Validation) -> list[str]:
    if not isinstance(value, list) or any(not isinstance(item, str) or not item for item in value):
        validation.failed(f"Manifest field {field} must be an array of non-empty strings")
        return []
    return list(value)


def _map_archetype(service: Any, validation: Validation) -> str:
    if not isinstance(service, str) or not service.strip():
        validation.failed("Manifest compute[0].service must select an AWS archetype")
        return ""
    normalized = re.sub(r"[\s_/]+", "-", service.strip().lower())
    archetype = ARCHETYPE_ALIASES.get(normalized, "")
    if not archetype:
        validation.failed(
            f"Unsupported compute archetype {service!r}; expected one of: "
            + ", ".join(sorted(SUPPORTED_ARCHETYPES))
        )
    return archetype


def _manifest_view(
    path: Path,
    document: dict[str, Any],
    validation: Validation,
) -> ManifestView | None:
    if document.get("schema_version") != "1.0":
        validation.failed("Manifest schema_version must be '1.0'")
    if document.get("kind") != "deployment-manifest":
        validation.failed("Manifest kind must be 'deployment-manifest'")
    if document.get("target_cloud") != "aws":
        validation.failed("Manifest target_cloud must be 'aws'")

    environments = _objects(document.get("environments"), "environments", validation)
    region = ""
    if len(environments) != 1:
        validation.failed("Deployment readiness requires exactly one environments[] entry")
    elif environments:
        regions = _strings(environments[0].get("regions"), "environments[0].regions", validation)
        if len(regions) != 1:
            validation.failed("Deployment readiness requires exactly one target Region")
        elif regions:
            region = regions[0]

    compute = _objects(document.get("compute"), "compute", validation)
    archetype = ""
    runtime = ""
    source_paths: list[str] = []
    if len(compute) != 1:
        validation.failed("Deployment readiness requires exactly one primary compute[] entry")
    elif compute:
        archetype = _map_archetype(compute[0].get("service"), validation)
        runtime_value = compute[0].get("runtime")
        if isinstance(runtime_value, str) and runtime_value.strip():
            runtime = runtime_value
        else:
            validation.failed("Manifest compute[0].runtime must be a non-empty string")
        source_paths = _strings(
            compute[0].get("source_paths"), "compute[0].source_paths", validation
        )

    manifest_id = document.get("id")
    if not isinstance(manifest_id, str) or not manifest_id:
        validation.failed("Manifest id must be a non-empty string")
        manifest_id = "unknown"
    status = document.get("status")
    if not isinstance(status, str):
        validation.failed("Manifest status must be a string")
        status = "unknown"

    agentcore = document.get("agentcore")
    if not isinstance(agentcore, dict):
        validation.failed("Manifest agentcore must be an object")
        agentcore = {}

    approvals = _objects(document.get("approvals"), "approvals", validation)
    view = ManifestView(
        path=path,
        document=document,
        manifest_id=manifest_id,
        status=status,
        region=region,
        archetype=archetype,
        runtime=runtime,
        source_paths=tuple(source_paths),
        containers=tuple(_objects(document.get("containers"), "containers", validation)),
        integrations=tuple(_objects(document.get("integration"), "integration", validation)),
        data=tuple(_objects(document.get("data"), "data", validation)),
        secrets=tuple(_objects(document.get("secrets"), "secrets", validation)),
        approvals=tuple(approvals),
        validation_gates=tuple(
            _objects(document.get("validation_gates"), "validation_gates", validation)
        ),
        agentcore=agentcore,
        teardown=tuple(
            _objects(document.get("teardown_inventory"), "teardown_inventory", validation)
        ),
    )
    if view.agentcore_enabled and agentcore.get("status") not in {"approved", "deployed"}:
        validation.failed("Enabled AgentCore requires agentcore.status approved or deployed")
    if view.agentcore_enabled and not any(
        item.get("status") == "approved"
        and "agentcore" in str(item.get("scope", "")).lower()
        for item in approvals
    ):
        validation.failed("Enabled AgentCore requires an approved AgentCore approval entry")
    if not view.teardown:
        validation.failed("Manifest teardown_inventory must enumerate selected resources")
    return view


def _run_schema_validator(
    documents: Sequence[Path],
    repo_root: Path,
    validation: Validation,
) -> None:
    tool = repo_root / "tools" / "validate_migration_contracts.py"
    if not tool.is_file():
        validation.warned(
            "tools/validate_migration_contracts.py is unavailable; using focused manifest checks only"
        )
        return
    command = [sys.executable, str(tool), "--strict", *(str(path) for path in documents)]
    result = _run(command, cwd=repo_root)
    if result.returncode == 0:
        validation.passed("Migration contract schemas and semantic checks pass")
        return
    error_lines = [line for line in result.stdout.splitlines() if line.startswith("ERROR ")]
    if not error_lines:
        error_lines = ["migration contract validator returned a non-zero status"]
    for line in error_lines[:20]:
        validation.failed(line.removeprefix("ERROR "))
    if len(error_lines) > 20:
        validation.failed(f"Migration contract validation reported {len(error_lines) - 20} more errors")


def _candidate_document_paths(
    manifest: dict[str, Any],
    manifest_path: Path,
    repo_root: Path,
) -> list[Path]:
    candidates = [manifest_path.parent / "model-api-decision.json"]
    for approval in manifest.get("approvals", []):
        if not isinstance(approval, dict):
            continue
        for evidence in approval.get("evidence", []):
            if isinstance(evidence, str) and "model" in Path(evidence).name.lower():
                candidates.extend(_resolve_candidates(evidence, manifest_path, repo_root))
    for evidence in manifest.get("evidence", []):
        if not isinstance(evidence, dict):
            continue
        value = evidence.get("path")
        if isinstance(value, str) and "model" in Path(value).name.lower():
            candidates.extend(_resolve_candidates(value, manifest_path, repo_root))
    unique: list[Path] = []
    seen: set[Path] = set()
    for candidate in candidates:
        resolved = candidate.expanduser().resolve()
        if resolved not in seen:
            seen.add(resolved)
            unique.append(resolved)
    return unique


def _resolve_candidates(value: str, manifest_path: Path, repo_root: Path) -> list[Path]:
    if urlparse(value).scheme:
        return []
    candidate = Path(value).expanduser()
    if candidate.is_absolute():
        return [candidate]
    return [manifest_path.parent / candidate, repo_root / candidate]


def _model_decision(
    view: ManifestView,
    repo_root: Path,
    validation: Validation,
    explicit_path: Path | None = None,
) -> tuple[ModelDecision | None, Path | None, dict[str, Any] | None]:
    decision_path = explicit_path
    if decision_path is not None and not decision_path.is_file():
        validation.failed(f"Model/API decision is missing: {decision_path}")
        return None, decision_path, None
    if decision_path is None:
        decision_path = next(
            (
                path
                for path in _candidate_document_paths(view.document, view.path, repo_root)
                if path.is_file()
            ),
            None,
        )
    decision_document: dict[str, Any] | None = None
    if decision_path is not None:
        decision_document = _load_json(decision_path, "Model/API decision", validation)

    if decision_path is None:
        if _requires_model(view):
            validation.failed(
                "Model/API decision is missing; place model-api-decision.json beside the manifest or reference it from manifest evidence"
            )
        else:
            validation.passed("Manifest selects no model capability; no model/API decision is required")
        return None, None, None
    if decision_document is None:
        return None, decision_path, None

    model_id = ""
    inference_url = ""
    region = view.region
    status = "unknown"
    status_value = decision_document.get("status")
    status = status_value if isinstance(status_value, str) else "unknown"
    target = decision_document.get("target", {})
    if isinstance(target, dict):
        selection = target.get("model_selection", {})
        if isinstance(selection, dict) and isinstance(selection.get("value"), str):
            model_id = selection["value"]
        api_family = target.get("api_family")
        if isinstance(api_family, str) and api_family.lower() != "responses":
            validation.failed("Model/API decision target.api_family must be Responses")
    value = decision_document.get("inference_url")
    if isinstance(value, str):
        inference_url = value
    gate = decision_document.get("availability_gate", {})
    if isinstance(gate, dict) and isinstance(gate.get("region"), str):
        region = gate["region"]

    model_integrations = [
        item for item in view.integrations if item.get("type") == "model-api"
    ]
    for integration in model_integrations:
        destination = integration.get("destination")
        if isinstance(destination, str):
            if inference_url and destination != inference_url:
                validation.failed(
                    "Manifest model-api integration destination does not match model-api-decision inference_url"
                )
            elif not inference_url:
                inference_url = destination

    if model_id not in SUPPORTED_MODEL_REGIONS:
        validation.failed(
            "Selected model must be exactly openai.gpt-5.4 or openai.gpt-5.5"
        )
        return None, decision_path, decision_document
    if region not in SUPPORTED_MODEL_REGIONS[model_id]:
        validation.failed(f"Unsupported model/Region tuple: {model_id} in {region or 'unset'}")
    expected_url = f"https://bedrock-mantle.{region}.api.aws/openai/v1/responses"
    if inference_url != expected_url:
        validation.failed(
            f"Model inference_url must be the complete authoritative URL: {expected_url}"
        )
    else:
        validation.passed(f"Model decision uses the allowed {model_id} tuple and full Responses URL")
    if region != view.region:
        validation.failed(
            f"Model decision Region {region!r} does not match manifest Region {view.region!r}"
        )

    if view.agentcore_enabled:
        agentcore_values: dict[str, str] = {}
        interfaces = view.agentcore.get("interfaces", [])
        if isinstance(interfaces, list):
            for item in interfaces:
                if isinstance(item, str) and "=" in item:
                    key, interface_value = item.split("=", 1)
                    agentcore_values[key] = interface_value
        if agentcore_values.get("model_id") != model_id:
            validation.failed(
                "Enabled AgentCore model_id interface must match the model/API decision"
            )
        if agentcore_values.get("inference_url") != inference_url:
            validation.failed(
                "Enabled AgentCore inference_url interface must match the model/API decision"
            )
    return (
        ModelDecision(
            model_id=model_id,
            region=region,
            inference_url=inference_url,
            status=status,
            source_path=decision_path,
        ),
        decision_path,
        decision_document,
    )


def _requires_model(view: ManifestView) -> bool:
    return view.agentcore_enabled or any(
        item.get("type") == "model-api" for item in view.integrations
    )


def _text_files(root: Path) -> list[Path]:
    if not root.exists():
        return []
    result: list[Path] = []
    for path in root.rglob("*"):
        if not path.is_file() or any(part in IGNORED_DIRECTORIES for part in path.parts):
            continue
        if path.suffix.lower() in TEXT_SUFFIXES or path.name in {
            "Dockerfile",
            "Gemfile",
            "Makefile",
            "Procfile",
        }:
            result.append(path)
    return result


def _relative(path: Path, root: Path) -> str:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        return path.name


def _scan_public_safety(root: Path, validation: Validation) -> None:
    unsafe_files: list[str] = []
    local_path_files: list[str] = []
    escaping_links: list[str] = []
    if not root.exists():
        return
    for path in root.rglob("*"):
        if any(part in IGNORED_DIRECTORIES for part in path.parts):
            continue
        if path.is_symlink():
            try:
                path.resolve().relative_to(root.resolve())
            except (OSError, ValueError):
                escaping_links.append(_relative(path, root))
            continue
        if not path.is_file():
            continue
        environment_template = path.name.startswith(".env") and path.name.endswith(
            (".example", ".sample")
        )
        if path.name.startswith(".env") and not environment_template:
            unsafe_files.append(_relative(path, root))
            continue
        if not environment_template and path.suffix.lower() not in TEXT_SUFFIXES and path.name not in {
            "Dockerfile",
            "Gemfile",
            "Makefile",
            "Procfile",
        }:
            continue
        try:
            if path.stat().st_size > 2_000_000:
                continue
            text = path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        if any(pattern.search(text) for pattern in SENSITIVE_PATTERNS.values()):
            unsafe_files.append(_relative(path, root))
        if LOCAL_PATH_PATTERN.search(text):
            local_path_files.append(_relative(path, root))
    if unsafe_files:
        validation.failed(
            "Potential secret or private environment files found under target: "
            + ", ".join(sorted(set(unsafe_files)))
        )
    else:
        validation.passed("Target contains no obvious credential or private environment files")
    if local_path_files:
        validation.failed(
            "Machine-local absolute paths found under target: "
            + ", ".join(sorted(set(local_path_files)))
        )
    if escaping_links:
        validation.failed(
            "Target symlinks escape the target root: " + ", ".join(sorted(escaping_links))
        )


def _check_empty_target(target: Path, validation: Validation) -> None:
    if not target.exists():
        validation.passed("Public target is absent")
        return
    files = sorted(
        path.relative_to(target).as_posix()
        for path in target.rglob("*")
        if path.is_file() or path.is_symlink()
    )
    if files in ([], [".gitkeep"]):
        validation.passed("Public target is empty except for optional .gitkeep")
    else:
        validation.failed(f"Expected an empty public target, found: {files}")


def _check_nonempty_target(target: Path, validation: Validation) -> None:
    files = [
        path
        for path in target.rglob("*")
        if path.is_file()
        and path.name != ".gitkeep"
        and not any(part in IGNORED_DIRECTORIES for part in path.parts)
    ] if target.is_dir() else []
    if files:
        validation.passed("Generated target contains implementation files")
    else:
        validation.failed(f"Generated target is missing or empty: {target}")


def _read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return ""


def _check_cdk_scaffold(
    cdk_dir: Path,
    view: ManifestView | None,
    validation: Validation,
) -> None:
    required = [
        cdk_dir / "package.json",
        cdk_dir / "package-lock.json",
        cdk_dir / "cdk.json",
        cdk_dir / "tsconfig.json",
        cdk_dir / "bin" / "app.ts",
        cdk_dir / "lib" / "manifest.ts",
        cdk_dir / "lib" / "archetype-stack.ts",
        cdk_dir / "lib" / "archetype-factory.ts",
        cdk_dir / "lib" / "capabilities.ts",
    ]
    missing = [str(path.relative_to(cdk_dir)) for path in required if not path.is_file()]
    if missing:
        validation.failed("CDK scaffold is missing: " + ", ".join(missing))
        return
    validation.passed("Manifest-driven CDK scaffold files are present")

    package = _load_json(cdk_dir / "package.json", "CDK package.json", validation)
    if package is not None:
        scripts = package.get("scripts", {})
        if not isinstance(scripts, dict):
            validation.failed("CDK package.json scripts must be an object")
        else:
            for name in ("build", "synth", "synth:contract"):
                if not isinstance(scripts.get(name), str):
                    validation.failed(f"CDK package.json is missing script {name!r}")
            for command in scripts.values():
                if not isinstance(command, str):
                    continue
                for script_path in re.findall(r"(?:node|python3?)\s+([^\s]+)", command):
                    candidate = cdk_dir / script_path
                    if not candidate.is_file():
                        validation.failed(
                            f"CDK package script references a missing file: {script_path}"
                        )

    app_text = _read_text(cdk_dir / "bin" / "app.ts")
    factory_text = _read_text(cdk_dir / "lib" / "archetype-factory.ts")
    manifest_text = _read_text(cdk_dir / "lib" / "manifest.ts")
    capabilities_text = _read_text(cdk_dir / "lib" / "capabilities.ts")
    for signal in ("loadManifest", "ArchetypeStack", "manifest"):
        if signal not in app_text:
            validation.failed(f"CDK entrypoint is missing manifest-driven signal: {signal}")

    if view is None or not view.archetype:
        return
    archetype_signals = {
        "static-web": ("createStaticWeb", "cloudfront.Distribution", "s3.Bucket"),
        "serverless-http": ("createServerlessHttp", "apigateway.RestApi", "lambda.Code.fromAsset"),
        "public-web-container": ("createAppRunner", "apprunner.CfnService", "DockerImageAsset"),
        "private-container-service": (
            "createPrivateContainer",
            "ApplicationLoadBalancedFargateService",
            "ContainerImage.fromAsset",
        ),
        "event-worker": ("createEventWorker", "SqsEventSource", "lambda.Code.fromAsset"),
        "kubernetes": ("createKubernetes", "new eks.Cluster", "addNodegroupCapacity"),
    }
    for signal in archetype_signals[view.archetype]:
        if signal not in factory_text:
            validation.failed(
                f"CDK factory does not implement {view.archetype} requirement: {signal}"
            )
    if view.archetype == "static-web" and not re.search(
        r"BucketDeployment|s3deploy|Source\.asset", factory_text
    ):
        validation.failed("Static-web CDK path does not publish the selected site asset")
    if view.archetype in CONTAINER_ARCHETYPES and "LINUX_AMD64" not in factory_text:
        validation.failed("Application container CDK path must select linux/amd64")

    if view.agentcore_enabled:
        for signal in (
            "AgentCoreRuntime",
            "LINUX_ARM64",
            "grantInvokeRuntime",
            "BEDROCK_OPENAI_RESPONSES_URL",
        ):
            if signal not in capabilities_text:
                validation.failed(f"Enabled AgentCore CDK path is missing signal: {signal}")
    elif "agentcore.enabled" not in manifest_text:
        validation.warned("CDK manifest parser does not visibly gate optional AgentCore")


def _application_container(view: ManifestView) -> dict[str, Any] | None:
    for container in view.containers:
        if re.match(r"^(application|app|web|worker)$", str(container.get("name", "")), re.I):
            return container
    return next(
        (container for container in view.containers if "agentcore" not in str(container.get("name", "")).lower()),
        None,
    )


def _agentcore_container(view: ManifestView) -> dict[str, Any] | None:
    return next(
        (container for container in view.containers if "agentcore" in str(container.get("name", "")).lower()),
        None,
    )


def _uses_application_container(
    view: ManifestView,
) -> bool:
    if view.archetype in CONTAINER_ARCHETYPES:
        return True
    return re.search(
        r"(?:^|[;\s])packaging\s*=\s*container(?:$|[;\s])",
        view.runtime,
        re.I,
    ) is not None


def _resolve_asset(
    value: str,
    manifest_path: Path,
) -> Path:
    candidate = Path(value).expanduser()
    if candidate.is_absolute():
        return candidate.resolve()
    return (manifest_path.parent / candidate).resolve()


def _is_within(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


def _platforms(container: dict[str, Any], field: str, validation: Validation) -> set[str]:
    value = container.get("platform")
    if not isinstance(value, str):
        validation.failed(f"Manifest {field}.platform must be a string")
        return set()
    platforms = set(re.findall(r"linux/(?:amd64|arm64)", value.lower()))
    if not platforms:
        validation.failed(
            f"Manifest {field}.platform must explicitly select linux/amd64 or linux/arm64"
        )
    return platforms


def _check_manifest_platforms(
    view: ManifestView,
    validation: Validation,
) -> set[str]:
    required_platforms: set[str] = set()
    application = _application_container(view)
    if _uses_application_container(view):
        if application is None:
            validation.failed(
                f"{view.archetype} requires an application containers[] entry"
            )
        else:
            app_platforms = _platforms(
                application, "containers[application]", validation
            )
            required_platforms.update(app_platforms)
            if app_platforms and app_platforms != {"linux/amd64"}:
                validation.failed(
                    "The selected CDK application-container path requires linux/amd64"
                )
            if application.get("non_root") is not True:
                validation.failed("Application container must declare non_root=true")

    if view.agentcore_enabled:
        agent_container = _agentcore_container(view)
        if agent_container is None:
            validation.failed("Enabled AgentCore requires a dedicated containers[] asset")
        else:
            agent_platforms = _platforms(
                agent_container, "containers[agentcore]", validation
            )
            required_platforms.update(agent_platforms)
            if agent_platforms and agent_platforms != {"linux/arm64"}:
                validation.failed("AgentCore container must target linux/arm64")
            if agent_container.get("non_root") is not True:
                validation.failed("AgentCore container must declare non_root=true")
    return required_platforms


def _check_selected_assets(
    view: ManifestView,
    target: Path,
    validation: Validation,
) -> None:
    application = _application_container(view)
    uses_application_container = _uses_application_container(view)
    asset_value: str | None = None
    if view.archetype == "static-web" and view.source_paths:
        asset_value = view.source_paths[0]
    elif application is not None and isinstance(application.get("source_path"), str):
        asset_value = application["source_path"]
    elif view.source_paths:
        asset_value = view.source_paths[0]

    if view.archetype in ASSET_ARCHETYPES:
        if not asset_value:
            validation.failed(f"{view.archetype} requires a selected application asset path")
        else:
            asset = _resolve_asset(asset_value, view.path)
            if not asset.exists():
                validation.failed(f"Selected application asset does not exist: {asset_value}")
            else:
                validation.passed(f"Selected {view.archetype} application asset exists")
                if not _is_within(asset, target):
                    validation.failed("Selected application asset must be contained by --target")
                if view.archetype == "static-web" and not (asset / "index.html").is_file():
                    validation.failed("Static-web asset must contain index.html")
                if uses_application_container and not (asset / "Dockerfile").is_file():
                    validation.failed("Container application asset must contain Dockerfile")

    if view.agentcore_enabled:
        agent_container = _agentcore_container(view)
        if agent_container is not None:
            value = agent_container.get("source_path")
            if not isinstance(value, str):
                validation.failed("AgentCore container source_path is required")
            else:
                asset = _resolve_asset(value, view.path)
                if not asset.exists() or not (asset / "Dockerfile").is_file():
                    validation.failed("AgentCore asset must exist and contain Dockerfile")
                elif not _is_within(asset, target):
                    validation.failed("AgentCore asset must be contained by --target")
                else:
                    validation.passed("Enabled AgentCore container asset is present")


def _required_tools(
    view: ManifestView | None,
    target: Path,
) -> set[str]:
    tools = {"node", "npm"}
    runtime = view.runtime.lower() if view is not None else ""
    if "python" in runtime:
        tools.add("python3")
    if "java" in runtime or "jvm" in runtime:
        tools.add("java")
        if not (target / "mvnw").is_file() and not (target / "gradlew").is_file():
            tools.add("mvn")
    if "node" in runtime or "javascript" in runtime or "typescript" in runtime:
        tools.update({"node", "npm"})
    if "dotnet" in runtime or ".net" in runtime:
        tools.add("dotnet")
    if re.search(r"\bgo(?:lang)?\b", runtime):
        tools.add("go")
    if "rust" in runtime:
        tools.add("cargo")
    if view is not None:
        if _uses_application_container(view) or view.agentcore_enabled:
            tools.add("docker")
    if view is not None and view.archetype == "kubernetes":
        tools.add("kubectl")
    if (target / "package.json").is_file():
        tools.update({"node", "npm"})
    if (target / "pyproject.toml").is_file() or (target / "requirements.txt").is_file():
        tools.add("python3")
    return tools


def _check_tools_and_platforms(
    view: ManifestView | None,
    target: Path,
    required_platforms: set[str],
    validation: Validation,
) -> None:
    missing = [tool for tool in sorted(_required_tools(view, target)) if not shutil.which(tool)]
    if missing:
        validation.failed("Required local tools are unavailable: " + ", ".join(missing))
    else:
        validation.passed("Manifest-derived local tool requirements are available")

    if not required_platforms:
        return
    version = _run(["docker", "buildx", "version"])
    if version.returncode != 0:
        validation.failed("Docker Buildx is required for selected container assets")
        return
    inspection = _run(["docker", "buildx", "inspect"])
    platforms_text = inspection.stdout + inspection.stderr
    if inspection.returncode != 0:
        validation.failed("Docker Buildx builder cannot be inspected")
        return
    missing_platforms = sorted(
        platform for platform in required_platforms if platform not in platforms_text
    )
    if missing_platforms:
        validation.failed(
            "Docker Buildx is missing manifest-required platforms: "
            + ", ".join(missing_platforms)
        )
    else:
        validation.passed(
            "Docker Buildx supports manifest-required platforms: "
            + ", ".join(sorted(required_platforms))
        )


def _aws_command(
    command: Sequence[str],
    label: str,
    validation: Validation,
) -> None:
    result = _run(command, timeout=45)
    if result.returncode == 0:
        validation.passed(f"AWS read access: {label}")
    else:
        validation.failed(f"AWS read access failed: {label}")


def _service_requirements(view: ManifestView) -> tuple[list[tuple[str, list[str]]], set[str]]:
    region = view.region
    checks: dict[str, list[str]] = {}
    quota_codes: set[str] = set()

    def add(label: str, command: list[str], quota: str | None = None) -> None:
        checks.setdefault(label, command)
        if quota:
            quota_codes.add(quota)

    if view.archetype == "static-web":
        add("Amazon S3", ["aws", "s3api", "list-buckets", "--output", "json"], "s3")
        add(
            "Amazon CloudFront",
            ["aws", "cloudfront", "list-distributions", "--max-items", "1", "--output", "json"],
            "cloudfront",
        )
    elif view.archetype == "serverless-http":
        add("AWS Lambda", ["aws", "lambda", "list-functions", "--max-items", "1", "--region", region], "lambda")
        add("Amazon API Gateway", ["aws", "apigateway", "get-rest-apis", "--limit", "1", "--region", region], "apigateway")
    elif view.archetype == "public-web-container":
        add("AWS App Runner", ["aws", "apprunner", "list-services", "--max-results", "1", "--region", region], "apprunner")
        add("Amazon ECR", ["aws", "ecr", "describe-repositories", "--max-results", "1", "--region", region], "ecr")
    elif view.archetype == "private-container-service":
        add("Amazon ECS", ["aws", "ecs", "list-clusters", "--max-results", "1", "--region", region], "ecs")
        add("Elastic Load Balancing", ["aws", "elbv2", "describe-load-balancers", "--page-size", "1", "--region", region], "elasticloadbalancing")
        add("Amazon ECR", ["aws", "ecr", "describe-repositories", "--max-results", "1", "--region", region], "ecr")
    elif view.archetype == "event-worker":
        add("AWS Lambda", ["aws", "lambda", "list-functions", "--max-items", "1", "--region", region], "lambda")
        add("Amazon SQS", ["aws", "sqs", "list-queues", "--max-results", "1", "--region", region], "sqs")
    elif view.archetype == "kubernetes":
        add("Amazon EKS", ["aws", "eks", "list-clusters", "--max-results", "1", "--region", region], "eks")
        add("Amazon ECR", ["aws", "ecr", "describe-repositories", "--max-results", "1", "--region", region], "ecr")

    network = view.document.get("network", {})
    if isinstance(network, dict) and not re.match(
        r"^(none|not-required|no-vpc)$", str(network.get("vpc", "")), re.I
    ):
        add("Amazon VPC", ["aws", "ec2", "describe-vpcs", "--max-results", "5", "--region", region], "vpc")

    for item in view.data:
        service = str(item.get("service", "")).lower()
        if "rds" in service or "aurora" in service or "postgres" in service:
            add("Amazon RDS", ["aws", "rds", "describe-db-instances", "--max-records", "20", "--region", region], "rds")
        elif "dynamodb" in service:
            add("Amazon DynamoDB", ["aws", "dynamodb", "list-tables", "--limit", "1", "--region", region], "dynamodb")
        elif "documentdb" in service:
            add("Amazon DocumentDB", ["aws", "docdb", "describe-db-clusters", "--max-records", "20", "--region", region], "docdb")
        elif "elasticache" in service or "redis" in service:
            add("Amazon ElastiCache", ["aws", "elasticache", "describe-cache-clusters", "--max-records", "20", "--region", region], "elasticache")
        elif service == "s3" or "amazon s3" in service:
            add("Amazon S3", ["aws", "s3api", "list-buckets", "--output", "json"], "s3")

    for item in view.integrations:
        type_name = str(item.get("type", "")).lower()
        protocol = str(item.get("protocol", "")).lower()
        if type_name == "queue" or "sqs" in protocol:
            add("Amazon SQS", ["aws", "sqs", "list-queues", "--max-results", "1", "--region", region], "sqs")
        elif "sns" in protocol:
            add("Amazon SNS", ["aws", "sns", "list-topics", "--region", region], "sns")
        elif type_name in {"event", "schedule"} or "eventbridge" in protocol:
            add("Amazon EventBridge", ["aws", "events", "list-event-buses", "--limit", "1", "--region", region], "events")

    if any(item.get("source") in {"secrets-manager", "generated"} for item in view.secrets):
        add("AWS Secrets Manager", ["aws", "secretsmanager", "list-secrets", "--max-results", "1", "--region", region], "secretsmanager")
    if _requires_model(view):
        quota_codes.add("bedrock")
    if view.agentcore_enabled:
        add(
            "Amazon Bedrock AgentCore",
            ["aws", "bedrock-agentcore-control", "list-agent-runtimes", "--max-results", "1", "--region", region],
            "bedrock-agentcore",
        )
    return sorted(checks.items()), quota_codes


def _check_live_model(model: ModelDecision, validation: Validation) -> None:
    token = os.getenv("AWS_BEARER_TOKEN_BEDROCK") or os.getenv("OPENAI_API_KEY")
    if not token:
        validation.failed(
            "Set AWS_BEARER_TOKEN_BEDROCK or OPENAI_API_KEY in the terminal for the live model check"
        )
        return
    models_url = f"https://bedrock-mantle.{model.region}.api.aws/v1/models"
    request = urllib.request.Request(
        models_url,
        headers={"Authorization": f"Bearer {token}", "Accept": "application/json"},
    )
    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
        validation.failed(f"Bedrock Mantle model listing failed: {type(exc).__name__}")
        return
    items = payload.get("data", []) if isinstance(payload, dict) else []
    selected = next(
        (item for item in items if isinstance(item, dict) and item.get("id") == model.model_id),
        None,
    )
    if selected is None:
        validation.failed(f"{model.model_id} is not visible through Bedrock Mantle in {model.region}")
        return
    capability_values = " ".join(
        str(value).lower()
        for key, value in selected.items()
        if any(term in key.lower() for term in ("api", "capabil", "operation"))
    )
    if capability_values and "responses" not in capability_values:
        validation.failed(f"{model.model_id} listing does not advertise Responses compatibility")
    else:
        validation.passed(f"{model.model_id} is visible for the selected live tuple")
        if not capability_values:
            validation.warned(
                "The live model item did not expose API capability metadata; rely on the validated model decision for Responses compatibility"
            )


def _check_live_environment(
    view: ManifestView,
    model: ModelDecision | None,
    validation: Validation,
) -> None:
    if not shutil.which("aws"):
        validation.failed("AWS CLI is required for --live")
        return
    version = _run(["aws", "--version"])
    if version.returncode != 0 or "aws-cli/2" not in (version.stdout + version.stderr):
        validation.failed("AWS CLI v2 is required for --live")
        return
    identity = _run(["aws", "sts", "get-caller-identity", "--output", "json"])
    if identity.returncode != 0:
        validation.failed("AWS caller identity is invalid, expired, or not readable")
        return
    validation.passed("AWS caller identity is valid")

    configured_region = (
        os.getenv("AWS_REGION")
        or os.getenv("AWS_DEFAULT_REGION")
        or _run(["aws", "configure", "get", "region"]).stdout.strip()
    )
    if configured_region != view.region:
        validation.failed(
            f"AWS configured Region must be {view.region}, found {configured_region or 'unset'}"
        )
    else:
        validation.passed(f"AWS configured Region matches manifest: {view.region}")

    checks, quota_codes = _service_requirements(view)
    for label, command in checks:
        _aws_command(command, label, validation)

    quota_services = _run(["aws", "service-quotas", "list-services", "--output", "json"])
    available_codes: set[str] = set()
    if quota_services.returncode != 0:
        validation.failed("AWS Service Quotas catalog is not readable")
    else:
        try:
            payload = json.loads(quota_services.stdout)
            available_codes = {
                item.get("ServiceCode")
                for item in payload.get("Services", [])
                if isinstance(item, dict) and isinstance(item.get("ServiceCode"), str)
            }
        except json.JSONDecodeError:
            validation.failed("AWS Service Quotas catalog returned invalid JSON")
    for code in sorted(quota_codes):
        if code not in available_codes:
            validation.warned(f"AWS Service Quotas does not expose service code {code!r}")
            continue
        result = _run(
            [
                "aws",
                "service-quotas",
                "list-service-quotas",
                "--service-code",
                code,
                "--max-results",
                "1",
                "--region",
                view.region,
                "--output",
                "json",
            ]
        )
        if result.returncode == 0:
            validation.passed(f"AWS quota visibility: {code}")
        else:
            validation.failed(f"AWS quota visibility failed: {code}")
    if quota_codes:
        validation.warned(
            "Quota APIs expose limits but do not prove headroom; compare selected resources and current usage before DEPLOY"
        )
    if model is not None:
        _check_live_model(model, validation)


def main() -> None:
    repo_root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(
        description="Validate manifest-driven AWS deployment readiness without deploying resources."
    )
    parser.add_argument(
        "--manifest",
        type=Path,
        default=Path("deployment-manifest.json"),
        help="Validated deployment manifest (default: ./deployment-manifest.json).",
    )
    parser.add_argument(
        "--target",
        type=Path,
        default=repo_root / "apps" / "aws-target-app",
    )
    parser.add_argument(
        "--model-decision",
        type=Path,
        help="Explicit model-api-decision.json path; overrides manifest evidence discovery.",
    )
    parser.add_argument(
        "--cdk-dir",
        type=Path,
        default=repo_root / "deploy" / "aws-cdk",
    )
    parser.add_argument("--expect-empty-target", action="store_true")
    parser.add_argument("--contract-only", action="store_true")
    parser.add_argument(
        "--live",
        action="store_true",
        help="Run read-only AWS identity, Region, model, quota, and selected-service checks.",
    )
    args = parser.parse_args()

    validation = Validation()
    manifest_path = args.manifest.expanduser().resolve()
    target = args.target.expanduser().resolve()
    cdk_dir = args.cdk_dir.expanduser().resolve()
    explicit_model_path = (
        args.model_decision.expanduser().resolve() if args.model_decision else None
    )
    manifest_document: dict[str, Any] | None = None
    view: ManifestView | None = None
    model: ModelDecision | None = None
    model_path: Path | None = None

    if manifest_path.is_file():
        manifest_document = _load_json(manifest_path, "Deployment manifest", validation)
        if manifest_document is not None:
            view = _manifest_view(manifest_path, manifest_document, validation)
            if view is not None:
                model, model_path, _ = _model_decision(
                    view, repo_root, validation, explicit_model_path
                )
            schema_documents = [manifest_path]
            if model_path is not None:
                schema_documents.append(model_path)
            _run_schema_validator(schema_documents, repo_root, validation)
    elif args.expect_empty_target and not args.live:
        validation.warned(
            f"Deployment manifest is absent in public-starter mode: {manifest_path}"
        )
    else:
        validation.failed(f"Deployment manifest is missing: {manifest_path}")

    if view is not None:
        if args.contract_only:
            if view.status in {"blocked", "retired"}:
                validation.failed(f"Manifest status {view.status!r} cannot be validated")
            elif view.status == "draft":
                validation.warned("Contract-only validation is using a draft manifest")
        elif view.status not in {"ready", "deployed"}:
            validation.failed(
                f"Deployment readiness requires manifest status ready or deployed, found {view.status!r}"
            )
        if not args.contract_only:
            unresolved_approvals = [
                str(item.get("id", "unnamed"))
                for item in view.approvals
                if item.get("status") not in {"approved", "not-required"}
            ]
            if unresolved_approvals:
                validation.failed(
                    "Deployment readiness has unresolved approvals: "
                    + ", ".join(unresolved_approvals)
                )
            unresolved_gates = [
                str(item.get("id", "unnamed"))
                for item in view.validation_gates
                if item.get("status") not in {"passed", "waived"}
            ]
            if unresolved_gates:
                validation.failed(
                    "Deployment readiness has unresolved validation gates: "
                    + ", ".join(unresolved_gates)
                )
        if model is not None and not args.contract_only and model.status != "accepted":
            validation.failed(
                f"Deployment readiness requires an accepted model/API decision, found {model.status!r}"
            )

    _check_cdk_scaffold(cdk_dir, view, validation)

    required_platforms = (
        _check_manifest_platforms(view, validation) if view is not None else set()
    )
    if args.expect_empty_target:
        _check_empty_target(target, validation)
        if target.exists():
            _scan_public_safety(target, validation)
    elif args.contract_only:
        if target.exists():
            _scan_public_safety(target, validation)
        validation.passed("Contract-only mode does not require generated target assets")
    else:
        _check_nonempty_target(target, validation)
        _scan_public_safety(target, validation)
        if view is not None:
            _check_selected_assets(view, target, validation)

    _check_tools_and_platforms(view, target, required_platforms, validation)

    if args.live:
        if view is None:
            validation.failed("--live requires a valid deployment manifest")
        elif _requires_model(view) and model is None:
            validation.failed("--live requires a valid model/API decision for the selected model capability")
        else:
            _check_live_environment(view, model, validation)

    if validation.warnings:
        print(f"\nWarnings: {len(validation.warnings)}")
    if validation.failures:
        print(f"\nDeployment readiness failed with {len(validation.failures)} blocker(s).")
        raise SystemExit(1)
    print("\nDeployment readiness checks passed. No deployment actions were run.")


if __name__ == "__main__":
    main()
