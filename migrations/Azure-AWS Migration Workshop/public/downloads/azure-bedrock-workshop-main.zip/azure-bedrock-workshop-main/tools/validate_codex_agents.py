from __future__ import annotations

import argparse
import re
import sys
import tomllib
from pathlib import Path
from typing import Any


REQUIRED_FIELDS = ("name", "description", "developer_instructions")
NAME_PATTERN = re.compile(r"^[a-z][a-z0-9-]*$")
NICKNAME_PATTERN = re.compile(r"^[A-Za-z0-9 _-]+$")
EXPECTED_AGENTS = {
    "migration-discovery.toml": {
        "name": "migration-discovery",
        "terms": (
            "migration-context.json",
            "source-profile.json",
            "source-profile.schema.json",
            "Azure OpenAI",
            "must not choose AWS",
        ),
    },
    "migration-architect.toml": {
        "name": "migration-architect",
        "terms": (
            "architecture-decision.json",
            "model-api-decision.json",
            "migration-guide.md",
            "Chat Completions",
            "Responses",
            "APPROVE MIGRATION",
        ),
    },
    "migration-validation.toml": {
        "name": "migration-validation",
        "terms": (
            "migration-context.json",
            "expected-versus-observed",
            "browser",
            "must not deploy",
            "pass or blocker",
        ),
    },
    "aws-deployment-engineer.toml": {
        "name": "aws-deployment-engineer",
        "terms": (
            "deployment-manifest.json",
            "deployment-manifest.schema.json",
            "CDK",
            "aws-preflight.md",
            "DEPLOY",
            "DESTROY",
        ),
    },
}
SHARED_TERMS = (
    "/tmp/workshop-artifacts",
    "docs/architecture.md",
    "repository evidence",
    "credentials",
    "blocker",
    "openai.gpt-5.4",
    "openai.gpt-5.5",
    "no silent fallback",
)


def _load_toml(path: Path) -> tuple[dict[str, Any] | None, list[str]]:
    try:
        with path.open("rb") as handle:
            return tomllib.load(handle), []
    except tomllib.TOMLDecodeError as exc:
        return None, [f"invalid TOML: {exc}"]


def validate_agent(path: Path) -> list[str]:
    data, errors = _load_toml(path)
    if data is None:
        return errors

    for field in REQUIRED_FIELDS:
        value = data.get(field)
        if not isinstance(value, str) or not value.strip():
            errors.append(f"missing or empty required string field `{field}`")

    name = data.get("name")
    if isinstance(name, str) and not NAME_PATTERN.match(name):
        errors.append("`name` should use lowercase letters, digits, and hyphens, and start with a letter")

    instructions = data.get("developer_instructions", "")
    if isinstance(instructions, str):
        if len(instructions.strip().split()) < 120:
            errors.append("`developer_instructions` is too short to implement the complete agent contract")

        expected = EXPECTED_AGENTS.get(path.name)
        if expected is None:
            errors.append(f"unexpected agent definition `{path.name}`")
        else:
            if data.get("name") != expected["name"]:
                errors.append(f"`name` must be `{expected['name']}` for `{path.name}`")
            for term in (*SHARED_TERMS, *expected["terms"]):
                if term.casefold() not in instructions.casefold():
                    errors.append(f"`developer_instructions` must include the contract term `{term}`")

    nicknames = data.get("nickname_candidates")
    if nicknames is not None:
        if not isinstance(nicknames, list) or not nicknames:
            errors.append("`nickname_candidates` must be a non-empty list when present")
        else:
            seen: set[str] = set()
            for nickname in nicknames:
                if not isinstance(nickname, str) or not nickname.strip():
                    errors.append("each nickname must be a non-empty string")
                    continue
                if nickname in seen:
                    errors.append(f"duplicate nickname `{nickname}`")
                seen.add(nickname)
                if not NICKNAME_PATTERN.match(nickname):
                    errors.append(f"nickname `{nickname}` should use ASCII letters, digits, spaces, hyphens, or underscores")

    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate project-scoped Codex custom agent TOML files.")
    parser.add_argument("--agents-dir", type=Path, default=Path(".codex/agents"))
    args = parser.parse_args()

    agents_dir = args.agents_dir
    if not agents_dir.exists():
        print(f"Agent directory not found: {agents_dir}", file=sys.stderr)
        return 1

    files = sorted(agents_dir.glob("*.toml"))
    if not files:
        print(f"No agent TOML files found in {agents_dir}", file=sys.stderr)
        return 1

    discovered = {path.name for path in files}
    expected = set(EXPECTED_AGENTS)
    missing = sorted(expected - discovered)
    unexpected = sorted(discovered - expected)
    if missing:
        print(f"Missing agent definitions: {', '.join(missing)}", file=sys.stderr)
    if unexpected:
        print(f"Unexpected agent definitions: {', '.join(unexpected)}", file=sys.stderr)

    failures = int(bool(missing or unexpected))
    for path in files:
        errors = validate_agent(path)
        if errors:
            failures += 1
            print(f"FAIL {path}")
            for error in errors:
                print(f"  - {error}")
        else:
            print(f"OK   {path}")

    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
