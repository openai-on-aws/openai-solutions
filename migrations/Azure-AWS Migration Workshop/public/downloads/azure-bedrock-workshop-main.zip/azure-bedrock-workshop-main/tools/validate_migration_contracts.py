from __future__ import annotations

import argparse
import json
import re
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable
from urllib.parse import urlparse


EXPECTED_SCHEMAS = {
    "migration-context": "migration-context.schema.json",
    "source-profile": "source-profile.schema.json",
    "architecture-decision": "architecture-decision.schema.json",
    "model-api-decision": "model-api-decision.schema.json",
    "deployment-manifest": "deployment-manifest.schema.json",
}
MODEL_REGIONS = {
    "openai.gpt-5.4": {"us-east-1", "us-east-2", "us-west-2"},
    "openai.gpt-5.5": {"us-east-1", "us-east-2"},
}


class ContractValidationError(ValueError):
    pass


def _json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ContractValidationError(f"{path}: invalid JSON: {exc}") from exc


def _pointer(root: dict[str, Any], ref: str) -> dict[str, Any]:
    if not ref.startswith("#/"):
        raise ContractValidationError(f"unsupported non-local $ref: {ref}")
    value: Any = root
    for token in ref[2:].split("/"):
        token = token.replace("~1", "/").replace("~0", "~")
        if not isinstance(value, dict) or token not in value:
            raise ContractValidationError(f"unresolved $ref: {ref}")
        value = value[token]
    if not isinstance(value, dict):
        raise ContractValidationError(f"$ref does not resolve to a schema object: {ref}")
    return value


def _is_type(value: Any, expected: str) -> bool:
    if expected == "object":
        return isinstance(value, dict)
    if expected == "array":
        return isinstance(value, list)
    if expected == "string":
        return isinstance(value, str)
    if expected == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    if expected == "number":
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    if expected == "boolean":
        return isinstance(value, bool)
    if expected == "null":
        return value is None
    return True


def _format_valid(value: str, format_name: str) -> bool:
    if format_name == "uri":
        parsed = urlparse(value)
        if parsed.scheme in {"http", "https"}:
            return bool(parsed.netloc)
        return bool(parsed.scheme)
    if format_name == "date-time":
        try:
            datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            return False
    return True


def _probe(instance: Any, schema: dict[str, Any], root: dict[str, Any]) -> bool:
    errors: list[str] = []
    _validate(instance, schema, root, "$", errors)
    return not errors


def _validate(
    instance: Any,
    schema: dict[str, Any],
    root: dict[str, Any],
    location: str,
    errors: list[str],
) -> None:
    if "$ref" in schema:
        _validate(instance, _pointer(root, str(schema["$ref"])), root, location, errors)
        schema = {key: value for key, value in schema.items() if key != "$ref"}

    for subschema in schema.get("allOf", []):
        _validate(instance, subschema, root, location, errors)
    if "anyOf" in schema and not any(_probe(instance, candidate, root) for candidate in schema["anyOf"]):
        errors.append(f"{location}: does not match any allowed schema")
        return
    if "oneOf" in schema:
        matches = sum(1 for candidate in schema["oneOf"] if _probe(instance, candidate, root))
        if matches != 1:
            errors.append(f"{location}: must match exactly one schema, matched {matches}")
            return
    if "not" in schema and _probe(instance, schema["not"], root):
        errors.append(f"{location}: matches a forbidden schema")
    if "if" in schema and _probe(instance, schema["if"], root):
        if "then" in schema:
            _validate(instance, schema["then"], root, location, errors)
    elif "else" in schema:
        _validate(instance, schema["else"], root, location, errors)

    expected_type = schema.get("type")
    if expected_type:
        allowed = expected_type if isinstance(expected_type, list) else [expected_type]
        if not any(_is_type(instance, item) for item in allowed):
            errors.append(f"{location}: expected type {' or '.join(allowed)}, got {type(instance).__name__}")
            return
    if "const" in schema and instance != schema["const"]:
        errors.append(f"{location}: expected constant {schema['const']!r}")
    if "enum" in schema and instance not in schema["enum"]:
        errors.append(f"{location}: {instance!r} is not one of {schema['enum']!r}")

    if isinstance(instance, dict):
        required = schema.get("required", [])
        for name in required:
            if name not in instance:
                errors.append(f"{location}: missing required property {name!r}")
        properties = schema.get("properties", {})
        for name, value in instance.items():
            if name in properties:
                _validate(value, properties[name], root, f"{location}.{name}", errors)
            elif schema.get("additionalProperties") is False:
                errors.append(f"{location}: unexpected property {name!r}")
            elif isinstance(schema.get("additionalProperties"), dict):
                _validate(value, schema["additionalProperties"], root, f"{location}.{name}", errors)
    elif isinstance(instance, list):
        if "minItems" in schema and len(instance) < schema["minItems"]:
            errors.append(f"{location}: expected at least {schema['minItems']} items")
        if "maxItems" in schema and len(instance) > schema["maxItems"]:
            errors.append(f"{location}: expected at most {schema['maxItems']} items")
        if schema.get("uniqueItems"):
            encoded = [json.dumps(value, sort_keys=True) for value in instance]
            if len(encoded) != len(set(encoded)):
                errors.append(f"{location}: items must be unique")
        item_schema = schema.get("items")
        if isinstance(item_schema, dict):
            for index, value in enumerate(instance):
                _validate(value, item_schema, root, f"{location}[{index}]", errors)
        contains_schema = schema.get("contains")
        if isinstance(contains_schema, dict):
            matches = sum(1 for value in instance if _probe(value, contains_schema, root))
            minimum = schema.get("minContains", 1)
            maximum = schema.get("maxContains")
            if matches < minimum:
                errors.append(f"{location}: expected at least {minimum} items matching contains, found {matches}")
            if maximum is not None and matches > maximum:
                errors.append(f"{location}: expected at most {maximum} items matching contains, found {matches}")
    elif isinstance(instance, str):
        if "minLength" in schema and len(instance) < schema["minLength"]:
            errors.append(f"{location}: must contain at least {schema['minLength']} characters")
        if "pattern" in schema and re.search(schema["pattern"], instance) is None:
            errors.append(f"{location}: does not match pattern {schema['pattern']!r}")
        if "format" in schema and not _format_valid(instance, schema["format"]):
            errors.append(f"{location}: is not a valid {schema['format']}")
    elif isinstance(instance, (int, float)) and not isinstance(instance, bool):
        if "minimum" in schema and instance < schema["minimum"]:
            errors.append(f"{location}: must be >= {schema['minimum']}")
        if "maximum" in schema and instance > schema["maximum"]:
            errors.append(f"{location}: must be <= {schema['maximum']}")


def _semantic_errors(document: dict[str, Any]) -> list[str]:
    kind = document.get("kind")
    errors: list[str] = []
    if kind == "migration-context":
        selected = document.get("selection", {}).get("selected_paths", [])
        source_root = document.get("source_root")
        if source_root and source_root not in selected:
            errors.append("$.selection.selected_paths: must include source_root")
    elif kind == "source-profile":
        evidence_paths: list[tuple[str, str]] = []
        for field in ("environment_variables", "calls_by_file"):
            evidence_paths.extend((f"$.{field}", path) for path in document.get(field, {}))
        for field in ("api_signals", "deployment_signals"):
            for paths in document.get(field, {}).values():
                evidence_paths.extend((f"$.{field}", path) for path in paths)
        for field in ("languages", "endpoints", "azure_services", "data_stores", "identity", "networking", "modalities", "parameters", "tools"):
            for item in document.get(field, []):
                evidence_paths.extend((f"$.{field}", path) for path in item.get("files", []))
        for field in ("streaming", "structured_output", "state"):
            evidence_paths.extend((f"$.{field}", path) for path in document.get(field, {}).get("files", []))
        evidence_paths.extend(("$.manifests", item.get("path", "")) for item in document.get("manifests", []))
        evidence_paths.extend(("$.dependencies", item.get("manifest", "")) for item in document.get("dependencies", []))
        evidence_paths.extend(("$.assets", path) for path in document.get("assets", []))
        for field in ("build_commands", "run_commands"):
            evidence_paths.extend((f"$.{field}", item.get("source_file", "")) for item in document.get(field, []))
        for location, path in evidence_paths:
            parsed = urlparse(path)
            if path and (Path(path).is_absolute() or parsed.scheme or ".." in Path(path).parts):
                errors.append(f"{location}: evidence path must be repository-relative: {path!r}")
                continue
    elif kind == "architecture-decision":
        candidates = document.get("ranked_candidates", [])
        ranks = [item.get("rank") for item in candidates]
        if ranks != list(range(1, len(candidates) + 1)):
            errors.append("$.ranked_candidates: ranks must be unique and sequential starting at 1")
        if document.get("status") == "accepted":
            if document.get("selected_archetype") == "undecided":
                errors.append("$.selected_archetype: accepted decisions cannot remain undecided")
            if candidates and document.get("selected_archetype") != candidates[0].get("archetype"):
                errors.append("$.selected_archetype: accepted selection must match rank 1")
            if document.get("blockers"):
                errors.append("$.blockers: accepted decisions cannot retain blockers")
    elif kind == "model-api-decision":
        decisions = document.get("parameter_decisions", [])
        omitted = document.get("omitted_parameters", [])
        omitted_names = [str(item.get("name", "")).lower() for item in omitted]
        if len(omitted_names) != len(set(omitted_names)):
            errors.append("$.omitted_parameters: parameter names must be unique")
        for index, decision in enumerate(decisions):
            action = decision.get("action")
            source_name = str(decision.get("source_name", "")).lower()
            if action in {"map", "transform"} and not decision.get("target_name"):
                errors.append(f"$.parameter_decisions[{index}].target_name: required for {action}")
            if source_name in omitted_names and action != "omit":
                errors.append(f"$.parameter_decisions[{index}]: omitted parameter {source_name!r} cannot also be {action}")
            if action == "omit" and source_name not in omitted_names:
                errors.append(f"$.parameter_decisions[{index}]: omit action for {source_name!r} requires an explicit omitted_parameters entry")
        decision_actions = {
            str(item.get("source_name", "")).lower(): item.get("action")
            for item in decisions
        }
        for index, name in enumerate(omitted_names):
            if decision_actions.get(name) != "omit":
                errors.append(f"$.omitted_parameters[{index}]: {name!r} requires a matching parameter decision with action 'omit'")
        selection = document.get("target", {}).get("model_selection", {})
        candidates = selection.get("candidates", [])
        candidate_ids = [item.get("model_id") for item in candidates]
        if set(candidate_ids) != set(MODEL_REGIONS) or len(candidate_ids) != len(MODEL_REGIONS):
            errors.append("$.target.model_selection.candidates: must list GPT-5.4 and GPT-5.5 exactly once")
        for index, candidate in enumerate(candidates):
            model_id = candidate.get("model_id")
            if model_id in MODEL_REGIONS and set(candidate.get("compatible_regions", [])) != MODEL_REGIONS[model_id]:
                errors.append(f"$.target.model_selection.candidates[{index}].compatible_regions: does not match the approved {model_id} model card")
        selected_model = selection.get("value")
        gate = document.get("availability_gate", {})
        if selected_model in MODEL_REGIONS:
            region = gate.get("region")
            if region not in MODEL_REGIONS[selected_model]:
                errors.append(f"$.availability_gate.region: {selected_model} is not compatible with {region!r}")
            expected_url = f"https://bedrock-mantle.{region}.api.aws/openai/v1/responses"
            if document.get("inference_url") != expected_url:
                errors.append("$.inference_url: must be the full authoritative Responses inference URL for the selected Region")
        elif selection.get("strategy") == "undecided":
            if selected_model is not None or document.get("inference_url") is not None:
                errors.append("$.target.model_selection: undecided selections require null value and null inference_url")
        if gate.get("verified") and not gate.get("live_models_evidence"):
            errors.append("$.availability_gate.live_models_evidence: verified availability requires redacted live /v1/models evidence")
        if document.get("status") == "accepted":
            if not gate.get("verified") or not gate.get("live_models_evidence"):
                errors.append("$.availability_gate: accepted decisions require live /v1/models evidence")
    elif kind == "deployment-manifest":
        agentcore = document.get("agentcore", {})
        if agentcore.get("enabled") and agentcore.get("status") == "not-selected":
            errors.append("$.agentcore.status: enabled AgentCore cannot be not-selected")
        orders = [item.get("deletion_order") for item in document.get("teardown_inventory", [])]
        if len(orders) != len(set(orders)):
            errors.append("$.teardown_inventory: deletion_order values must be unique")
        if document.get("status") in {"ready", "deployed"}:
            pending = [item.get("id") for item in document.get("approvals", []) if item.get("status") == "pending"]
            if pending:
                errors.append(f"$.approvals: ready/deployed manifest has pending approvals: {pending}")
    return errors


def load_schemas(schemas_dir: Path) -> tuple[dict[str, dict[str, Any]], list[str]]:
    schemas: dict[str, dict[str, Any]] = {}
    errors: list[str] = []
    ids: set[str] = set()
    for kind, filename in EXPECTED_SCHEMAS.items():
        path = schemas_dir / filename
        if not path.is_file():
            errors.append(f"missing schema: {path}")
            continue
        try:
            schema = _json(path)
        except ContractValidationError as exc:
            errors.append(str(exc))
            continue
        if not isinstance(schema, dict):
            errors.append(f"{path}: schema root must be an object")
            continue
        if schema.get("$schema") != "https://json-schema.org/draft/2020-12/schema":
            errors.append(f"{path}: must declare JSON Schema Draft 2020-12")
        schema_id = schema.get("$id")
        if not isinstance(schema_id, str) or not schema_id:
            errors.append(f"{path}: missing $id")
        elif schema_id in ids:
            errors.append(f"{path}: duplicate $id {schema_id}")
        else:
            ids.add(schema_id)
        expected_kind = schema.get("properties", {}).get("kind", {}).get("const")
        if expected_kind != kind:
            errors.append(f"{path}: kind const must be {kind!r}")
        schemas[kind] = schema
    return schemas, errors


def validate_contract(document: dict[str, Any], schema: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    _validate(document, schema, schema, "$", errors)
    errors.extend(_semantic_errors(document))
    return errors


def _documents(paths: Iterable[Path], artifact_dirs: Iterable[Path]) -> list[Path]:
    documents: set[Path] = set()
    for path in paths:
        if path.is_dir():
            documents.update(path.rglob("*.json"))
        else:
            documents.add(path)
    for directory in artifact_dirs:
        documents.update(directory.rglob("*.json"))
    return sorted(documents)


def main() -> None:
    default_schemas = Path(__file__).resolve().parent.parent / "schemas"
    parser = argparse.ArgumentParser(description="Validate Intelligent Azure OpenAI To AWS Migration Framework schemas and contract documents without external dependencies.")
    parser.add_argument("documents", nargs="*", type=Path, help="Contract JSON files or directories.")
    parser.add_argument("--schemas-dir", type=Path, default=default_schemas)
    parser.add_argument("--artifact-dir", "--contracts-dir", action="append", default=[], type=Path)
    parser.add_argument("--strict", action="store_true", help="Fail on JSON documents that do not declare a known contract kind.")
    args = parser.parse_args()

    schemas, errors = load_schemas(args.schemas_dir.resolve())
    for error in errors:
        print(f"ERROR {error}")
    if errors:
        raise SystemExit(1)
    for kind, filename in EXPECTED_SCHEMAS.items():
        print(f"OK    schema {kind}: {args.schemas_dir / filename}")

    failed = False
    for path in _documents(args.documents, args.artifact_dir):
        try:
            document = _json(path)
        except ContractValidationError as exc:
            print(f"ERROR {exc}")
            failed = True
            continue
        if not isinstance(document, dict):
            if args.strict:
                print(f"ERROR {path}: document root must be an object")
                failed = True
            continue
        kind = document.get("kind")
        if kind not in schemas:
            if args.strict:
                print(f"ERROR {path}: unknown or missing contract kind {kind!r}")
                failed = True
            continue
        document_errors = validate_contract(document, schemas[kind])
        if document_errors:
            failed = True
            for error in document_errors:
                print(f"ERROR {path}: {error}")
        else:
            print(f"OK    contract {kind}: {path}")
    raise SystemExit(1 if failed else 0)


if __name__ == "__main__":
    main()
