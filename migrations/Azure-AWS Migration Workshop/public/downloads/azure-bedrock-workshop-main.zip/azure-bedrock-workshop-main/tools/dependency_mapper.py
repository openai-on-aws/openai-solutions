from __future__ import annotations

import argparse
import ast
import json
import re
import tomllib
import xml.etree.ElementTree as ET
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable


REPOSITORY_ROOT = Path(__file__).resolve().parent.parent
IGNORE_DIRS = {
    ".git",
    ".gradle",
    ".idea",
    ".mvn",
    ".next",
    ".terraform",
    ".venv",
    ".vscode",
    "__pycache__",
    "bin",
    "build",
    "coverage",
    "dist",
    "node_modules",
    "obj",
    "target",
    "vendor",
}
IGNORE_FILES = {"env-config.js"}
ASSET_SUFFIXES = {".avif", ".gif", ".ico", ".jpeg", ".jpg", ".png", ".svg", ".webp", ".woff", ".woff2"}
LANGUAGE_SUFFIXES = {
    ".cs": "dotnet",
    ".fs": "dotnet",
    ".go": "go",
    ".java": "java",
    ".js": "javascript",
    ".jsx": "javascript",
    ".mjs": "javascript",
    ".py": "python",
    ".sh": "shell",
    ".ts": "typescript",
    ".tsx": "typescript",
}
ENV_PATTERNS = [
    re.compile(r"(?:os\.getenv|os\.environ\.get)\(\s*[\"']([A-Z][A-Z0-9_]*)[\"']"),
    re.compile(r"os\.environ\[\s*[\"']([A-Z][A-Z0-9_]*)[\"']\s*\]"),
    re.compile(r"(?:System\.)?getenv\(\s*[\"']([A-Z][A-Z0-9_]*)[\"']"),
    re.compile(r"Environment\.GetEnvironmentVariable\(\s*[\"']([A-Z][A-Z0-9_]*)[\"']"),
    re.compile(r"process\.env(?:\.([A-Z][A-Z0-9_]*)|\[[\"']([A-Z][A-Z0-9_]*)[\"']\])"),
    re.compile(r"os\.Getenv\(\s*[\"']([A-Z][A-Z0-9_]*)[\"']"),
    re.compile(r"\$\{\s*([A-Z][A-Z0-9_]*)(?::[^}]*)?\}"),
    re.compile(r"\b(REACT_APP_[A-Z0-9_]+|NEXT_PUBLIC_[A-Z0-9_]+|VITE_[A-Z0-9_]+)\b"),
]

AZURE_SERVICE_PATTERNS = {
    "azure-openai": [r"AzureOpenAI", r"OpenAIClientBuilder", r"Azure\.AI\.OpenAI", r"azure-ai-openai", r"@azure/openai", r"azopenai", r"AZURE_OPENAI_", r"Microsoft\.CognitiveServices/accounts"],
    "azure-functions": [r"Microsoft\.NET\.Sdk\.Functions", r"azure-functions", r"FunctionName\(", r"@app\.(?:function_name|route)"],
    "app-service": [r"Microsoft\.Web/sites", r"azure/webapps-deploy", r"azurerm_(?:linux|windows)_web_app"],
    "container-apps": [r"Microsoft\.App/containerApps", r"azurerm_container_app"],
    "aks": [r"Microsoft\.ContainerService/managedClusters", r"azurerm_kubernetes_cluster"],
    "key-vault": [r"Microsoft\.KeyVault/vaults", r"Azure\.Security\.KeyVault", r"azure-keyvault", r"azurerm_key_vault"],
    "storage": [r"Microsoft\.Storage/storageAccounts", r"Azure\.Storage\.", r"azure-storage", r"azurerm_storage_account"],
    "cosmos-db": [r"Microsoft\.DocumentDB/databaseAccounts", r"Azure\.Cosmos", r"azure-cosmos", r"azurerm_cosmosdb"],
    "service-bus": [r"Microsoft\.ServiceBus/namespaces", r"Azure\.Messaging\.ServiceBus", r"azure-servicebus", r"azurerm_servicebus"],
    "sql": [r"Microsoft\.Sql/servers", r"Azure\.Identity", r"azurerm_mssql"],
    "postgresql": [r"Microsoft\.DBforPostgreSQL", r"azurerm_postgresql"],
    "application-insights": [r"Microsoft\.Insights/components", r"APPLICATIONINSIGHTS_CONNECTION_STRING", r"applicationinsights", r"azurerm_application_insights"],
    "api-management": [r"Microsoft\.ApiManagement/service", r"azurerm_api_management"],
}

OPENAI_SIGNAL_PATTERNS = {
    "azure_openai_client": [r"AzureOpenAI", r"Azure\.AI\.OpenAI", r"OpenAIClientBuilder", r"azure-ai-openai", r"@azure/openai", r"azopenai"],
    "openai_client": [r"\bOpenAI\s*\(", r"OpenAIClient\s*\("],
    "chat_completions": [r"chat\.completions\.create", r"getChatCompletions", r"ChatCompletionsOptions", r"GetChatCompletions"],
    "responses_api": [r"responses\.create", r"/responses\b", r"CreateResponse"],
    "embeddings_api": [r"embeddings\.create", r"EmbeddingClient", r"getEmbeddings"],
    "azure_openai_configuration": [r"AZURE_OPENAI_", r"AzureOpenAI:"],
    "bedrock_openai_configuration": [r"BEDROCK_OPENAI_", r"OPENAI_BASE_URL", r"bedrock-mantle"],
    "chat_choice_parsing": [r"choices\s*\[\s*0\s*\]", r"getChoices\(\)", r"Choices\[0\]"],
    "responses_output_parsing": [r"output_text", r"outputText", r"output\[\]\.content\[\]\.text"],
}

DATA_STORE_PATTERNS = {
    "postgresql": ("relational", "unknown", [r"postgresql", r"jdbc:postgresql", r"npgsql", r"psycopg", r"pgx"]),
    "mysql": ("relational", "unknown", [r"\bmysql\b", r"jdbc:mysql", r"pymysql"]),
    "sql-server": ("relational", "unknown", [r"sqlserver", r"mssql", r"sqlclient", r"database\.windows\.net"]),
    "sqlite": ("embedded", "local-development", [r"sqlite"]),
    "h2": ("embedded", "local-development", [r"com\.h2database", r"jdbc:h2"]),
    "cosmos-db": ("document", "unknown", [r"cosmos", r"documents\.azure\.com"]),
    "mongodb": ("document", "unknown", [r"mongodb", r"pymongo"]),
    "redis": ("cache", "cache", [r"\bredis\b", r"stackexchange\.redis", r"lettuce"]),
    "blob-storage": ("object", "unknown", [r"blob\.core\.windows\.net", r"azure[.-]storage[.-]blob"]),
    "vector-store": ("vector", "unknown", [r"vectorstore", r"vector_store", r"pgvector", r"azure\.search\.documents"]),
}
IDENTITY_PATTERNS = {
    "managed-identity": [r"ManagedIdentity", r"DefaultAzureCredential", r"AZURE_CLIENT_ID"],
    "microsoft-identity": [r"Microsoft\.Identity", r"msal", r"login\.microsoftonline\.com"],
    "api-key": [r"AZURE_OPENAI_API_KEY", r"api[-_ ]?key"],
}
NETWORKING_PATTERNS = {
    "virtual-network": [r"virtualNetworks", r"azurerm_virtual_network", r"vnet"],
    "private-endpoint": [r"privateEndpoints", r"azurerm_private_endpoint", r"privatelink"],
    "public-endpoint": [r"azure\.com", r"azurewebsites\.net", r"openai\.azure\.com"],
}
MODALITY_PATTERNS = {
    "image": [r"input_image", r"image_url", r"images\.generate", r"ImageGeneration"],
    "audio": [r"input_audio", r"audio\.transcriptions", r"audio\.speech", r"AudioClient"],
    "video": [r"input_video", r"video_url"],
}
PARAMETER_PATTERNS = {
    "temperature": [r"\btemperature\b", r"setTemperature"],
    "top_p": [r"\btop[._-]p\b", r"\btopP\b", r"setTopP"],
    "max_tokens": [r"\bmax_tokens\b", r"\bmax-tokens\b", r"\bmaxTokens\b", r"setMaxTokens"],
    "max_output_tokens": [r"\bmax_output_tokens\b", r"\bmax-output-tokens\b", r"\bmaxOutputTokens\b"],
    "response_format": [r"\bresponse_format\b", r"\bresponse-format\b", r"\bresponseFormat\b"],
    "store": [r"[\"']store[\"']\s*[:=]", r"setStore"],
}
STREAMING_PATTERNS = [r"stream\s*[:=]\s*true", r"setStream\s*\(\s*true", r"streaming", r"server-sent events", r"text/event-stream"]
TOOL_PATTERNS = [r"tool_calls", r"function_call", r"FunctionDefinition", r"ChatCompletionsFunctionToolDefinition", r"\btools\s*[:=]"]
STRUCTURED_OUTPUT_PATTERNS = [r"response_format", r"json_schema", r"structured output"]
PROMPT_JSON_PATTERNS = [r"return only valid json", r"return only (?:a )?json", r"exact (?:json )?shape"]
MODEL_STATE_PATTERNS = [r"previous_response_id", r"conversation_id", r"thread_id", r"[\"']store[\"']\s*[:=]\s*true"]
MODEL_STATELESS_PATTERNS = [r"[\"']store[\"']\s*[:=]\s*false", r"setStore\s*\(\s*false"]
SESSION_STATE_PATTERNS = [r"HttpSession", r"sessionStorage", r"express-session", r"request\.session", r"flask\.session"]


class PythonSignalVisitor(ast.NodeVisitor):
    def __init__(self) -> None:
        self.imports: set[str] = set()
        self.calls: set[str] = set()

    def visit_Import(self, node: ast.Import) -> None:
        self.imports.update(alias.name for alias in node.names)
        self.generic_visit(node)

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        if node.module:
            self.imports.add(node.module)
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call) -> None:
        name = _call_name(node.func)
        if name:
            self.calls.add(name)
        self.generic_visit(node)


def _call_name(node: ast.AST) -> str:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        parent = _call_name(node.value)
        return f"{parent}.{node.attr}" if parent else node.attr
    return ""


def _is_ignored_path(path: Path) -> bool:
    if path.name in IGNORE_FILES:
        return True
    return any(part in IGNORE_DIRS or part.endswith(".egg-info") for part in path.parts)


def _iter_files(source: Path) -> list[Path]:
    return sorted(path for path in source.rglob("*") if path.is_file() and not _is_ignored_path(path))


def _read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except (UnicodeDecodeError, OSError):
        return ""


def _rel(path: Path, source: Path) -> str:
    try:
        return path.relative_to(REPOSITORY_ROOT).as_posix()
    except ValueError:
        return path.relative_to(source).as_posix()


def _display_path(path: Path) -> str:
    try:
        return path.relative_to(REPOSITORY_ROOT).as_posix()
    except ValueError:
        return path.as_posix()


def _slug(value: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    if not slug or not slug[0].isalpha():
        slug = f"source-{slug}".rstrip("-")
    return slug[:64]


def _dependency(name: str, ecosystem: str, manifest: str, version: str | None = None) -> dict[str, Any]:
    return {"name": name, "version": version or None, "ecosystem": ecosystem, "manifest": manifest}


def _xml_root(path: Path) -> ET.Element | None:
    try:
        return ET.fromstring(path.read_text(encoding="utf-8"))
    except (ET.ParseError, OSError, UnicodeDecodeError):
        return None


def _xml_local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def _child_text(element: ET.Element, name: str) -> str:
    for child in element:
        if _xml_local_name(child.tag) == name and child.text:
            return child.text.strip()
    return ""


def _maven_dependencies(path: Path, source: Path) -> list[dict[str, Any]]:
    root = _xml_root(path)
    if root is None:
        return []
    result = []
    for node in root.iter():
        if _xml_local_name(node.tag) != "dependency":
            continue
        group = _child_text(node, "groupId")
        artifact = _child_text(node, "artifactId")
        if group and artifact:
            result.append(_dependency(f"{group}:{artifact}", "maven", _rel(path, source), _child_text(node, "version")))
    return result


def _gradle_dependencies(path: Path, source: Path) -> list[dict[str, Any]]:
    text = _read_text(path)
    result = []
    pattern = re.compile(r"(?:implementation|api|compileOnly|runtimeOnly|testImplementation)\s*\(?\s*[\"']([^:\"']+):([^:\"']+)(?::([^\"']+))?[\"']")
    for group, artifact, version in pattern.findall(text):
        result.append(_dependency(f"{group}:{artifact}", "gradle", _rel(path, source), version))
    return result


def _nuget_dependencies(path: Path, source: Path) -> list[dict[str, Any]]:
    root = _xml_root(path)
    if root is None:
        return []
    result = []
    for node in root.iter():
        if _xml_local_name(node.tag) not in {"PackageReference", "package"}:
            continue
        name = node.attrib.get("Include") or node.attrib.get("Update") or node.attrib.get("id")
        version = node.attrib.get("Version") or node.attrib.get("version") or _child_text(node, "Version")
        if name:
            result.append(_dependency(name, "nuget", _rel(path, source), version))
    return result


def _npm_dependencies(path: Path, source: Path) -> list[dict[str, Any]]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError, UnicodeDecodeError):
        return []
    result = []
    for section in ("dependencies", "devDependencies", "peerDependencies", "optionalDependencies"):
        values = data.get(section, {})
        if isinstance(values, dict):
            result.extend(_dependency(name, "npm", _rel(path, source), str(version)) for name, version in values.items())
    return result


def _python_dependencies(path: Path, source: Path) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    if path.name == "pyproject.toml":
        try:
            with path.open("rb") as handle:
                data = tomllib.load(handle)
        except (tomllib.TOMLDecodeError, OSError):
            return []
        values: list[str] = list(data.get("project", {}).get("dependencies", []))
        for optional in data.get("project", {}).get("optional-dependencies", {}).values():
            values.extend(optional)
    else:
        values = [line.strip() for line in _read_text(path).splitlines() if line.strip() and not line.lstrip().startswith(("#", "-"))]
    for value in values:
        match = re.match(r"([A-Za-z0-9_.-]+)\s*(.*)", value)
        if match:
            result.append(_dependency(match.group(1), "pypi", _rel(path, source), match.group(2).strip() or None))
    return result


def _go_dependencies(path: Path, source: Path) -> list[dict[str, Any]]:
    result = []
    in_require = False
    for raw_line in _read_text(path).splitlines():
        line = raw_line.split("//", 1)[0].strip()
        if line == "require (":
            in_require = True
            continue
        if in_require and line == ")":
            in_require = False
            continue
        if line.startswith("require "):
            line = line.removeprefix("require ").strip()
        elif not in_require:
            continue
        parts = line.split()
        if parts:
            result.append(_dependency(parts[0], "go", _rel(path, source), parts[1] if len(parts) > 1 else None))
    return result


def _manifest_type(path: Path, text: str) -> str | None:
    lower = path.name.lower()
    if lower == "pom.xml":
        return "maven"
    if lower in {"build.gradle", "build.gradle.kts"}:
        return "gradle"
    if path.suffix.lower() in {".csproj", ".fsproj"} or lower == "packages.config":
        return "nuget"
    if lower == "package.json":
        return "npm"
    if lower in {"pyproject.toml", "requirements.txt", "requirements-dev.txt", "setup.cfg", "setup.py", "pipfile"}:
        return "python"
    if lower == "go.mod":
        return "go"
    if lower == "dockerfile" or lower.startswith("dockerfile."):
        return "docker"
    if lower in {"compose.yml", "compose.yaml", "docker-compose.yml", "docker-compose.yaml"}:
        return "compose"
    if lower in {"host.json", "function.json"}:
        return "azure-functions"
    if path.suffix.lower() in {".yaml", ".yml"} and re.search(r"(?m)^\s*apiVersion:\s*\S+", text) and re.search(r"(?m)^\s*kind:\s*\S+", text):
        return "kubernetes"
    if path.suffix.lower() == ".bicep":
        return "bicep"
    if path.suffix.lower() == ".json" and ("deploymentTemplate.json" in text or ('"contentVersion"' in text and '"resources"' in text)):
        return "arm"
    return None


def _manifest_dependencies(path: Path, source: Path, manifest_type: str) -> list[dict[str, Any]]:
    if manifest_type == "maven":
        return _maven_dependencies(path, source)
    if manifest_type == "gradle":
        return _gradle_dependencies(path, source)
    if manifest_type == "nuget":
        return _nuget_dependencies(path, source)
    if manifest_type == "npm":
        return _npm_dependencies(path, source)
    if manifest_type == "python" and path.name.lower() in {"pyproject.toml", "requirements.txt", "requirements-dev.txt"}:
        return _python_dependencies(path, source)
    if manifest_type == "go":
        return _go_dependencies(path, source)
    return []


def _extract_env_names(path: Path, text: str) -> set[str]:
    suffix = path.suffix.lower()
    code_or_config = suffix in {
        ".bash", ".cs", ".fs", ".go", ".java", ".js", ".jsx", ".mjs", ".properties",
        ".py", ".sh", ".ts", ".tsx", ".yaml", ".yml", ".zsh",
    } or path.name.lower().startswith("dockerfile")
    if not code_or_config and path.name.lower() != "local.settings.json":
        return set()
    names: set[str] = set()
    for index, pattern in enumerate(ENV_PATTERNS):
        if index == 6 and suffix not in {".java", ".properties", ".yaml", ".yml"}:
            continue
        if index == 7 and suffix not in {".js", ".jsx", ".mjs", ".ts", ".tsx"}:
            continue
        for match in pattern.findall(text):
            if isinstance(match, tuple):
                names.update(value for value in match if value)
            elif match:
                names.add(match)
    if path.name.lower() == "local.settings.json":
        try:
            values = json.loads(text).get("Values", {})
            if isinstance(values, dict):
                names.update(str(name) for name in values if re.fullmatch(r"[A-Z][A-Z0-9_]*", str(name)))
        except json.JSONDecodeError:
            pass
    return names


def _source_signals(path: Path, text: str) -> tuple[set[str], set[str]]:
    imports: set[str] = set()
    calls: set[str] = set()
    suffix = path.suffix.lower()
    if suffix == ".py":
        try:
            tree = ast.parse(text)
        except SyntaxError:
            return imports, calls
        visitor = PythonSignalVisitor()
        visitor.visit(tree)
        return visitor.imports, visitor.calls
    if suffix == ".java":
        imports.update(re.findall(r"(?m)^\s*import\s+([A-Za-z0-9_.*]+)\s*;", text))
        calls.update(re.findall(r"\.([A-Za-z_][A-Za-z0-9_]*)\s*\(", text))
        calls.update(re.findall(r"\bnew\s+([A-Z][A-Za-z0-9_]*)\s*\(", text))
    elif suffix in {".cs", ".fs"}:
        imports.update(re.findall(r"(?m)^\s*using\s+([A-Za-z0-9_.]+)\s*;", text))
        calls.update(re.findall(r"\.([A-Za-z_][A-Za-z0-9_]*)\s*\(", text))
    elif suffix in {".js", ".jsx", ".mjs", ".ts", ".tsx"}:
        imports.update(re.findall(r"(?:from\s+|require\(\s*)[\"']([^\"']+)", text))
        calls.update(re.findall(r"\b([A-Za-z_$][A-Za-z0-9_$.]*)\s*\(", text))
    elif suffix == ".go":
        imports.update(re.findall(r"[\"']([A-Za-z0-9_./-]+)[\"']", text))
        calls.update(re.findall(r"\b([A-Za-z_][A-Za-z0-9_.]*)\s*\(", text))
    return imports, calls


def _join_route(base: str, child: str) -> str:
    parts = [part.strip("/") for part in (base, child) if part and part != "/"]
    return "/" + "/".join(parts) if parts else "/"


def _extract_endpoints(path: Path, text: str) -> set[tuple[str, str]]:
    endpoints: set[tuple[str, str]] = set()
    patterns = [
        (re.compile(r"@(?:app|router)\.(get|post|put|patch|delete|options)\(\s*[\"']([^\"']+)[\"']", re.I), False),
        (re.compile(r"\b(?:app|router)\.(get|post|put|patch|delete|options)\(\s*[\"']([^\"']+)[\"']", re.I), False),
        (re.compile(r"\bMap(Get|Post|Put|Patch|Delete)\(\s*[\"']([^\"']+)[\"']", re.I), False),
        (re.compile(r"\bHandleFunc\(\s*[\"']([^\"']+)[\"']", re.I), True),
    ]
    for pattern, path_only in patterns:
        for match in pattern.findall(text):
            if path_only:
                endpoints.add(("ANY", match if isinstance(match, str) else match[0]))
            else:
                method, route = match
                endpoints.add((method.upper(), route))
    spring_base_match = re.search(
        r"@RequestMapping\(\s*(?:(?:value|path)\s*=\s*)?[\"']([^\"']+)[\"']",
        text,
        re.I,
    )
    spring_base = spring_base_match.group(1) if spring_base_match else ""
    spring_mapping = re.compile(
        r"@(Get|Post|Put|Patch|Delete)Mapping(?:\s*\(\s*(?:(?:value|path)\s*=\s*)?[\"']([^\"']*)[\"'][^)]*\))?",
        re.I,
    )
    for method, route in spring_mapping.findall(text):
        endpoints.add((method.upper(), _join_route(spring_base, route)))

    controller_name = re.sub(r"Controller$", "", path.stem, flags=re.I)
    dotnet_base_match = re.search(r"\[Route\(\s*[\"']([^\"']+)[\"']\s*\)\]", text, re.I)
    dotnet_base = dotnet_base_match.group(1) if dotnet_base_match else ""
    dotnet_base = re.sub(r"\[controller\]", controller_name, dotnet_base, flags=re.I)
    dotnet_mapping = re.compile(
        r"\[Http(Get|Post|Put|Patch|Delete)(?:\(\s*[\"']([^\"']*)[\"']\s*\))?\]",
        re.I,
    )
    for method, route in dotnet_mapping.findall(text):
        endpoints.add((method.upper(), _join_route(dotnet_base, route)))
    for route in re.findall(r"\broute\s*=\s*[\"']([^\"']+)[\"']", text):
        endpoints.add(("TRIGGER", route if route.startswith("/") else f"/{route}"))
    known_paths = {route for _, route in endpoints}
    for route in re.findall(r"[\"'](/api/[A-Za-z0-9_{}:./-]+)[\"']", text):
        if route not in known_paths:
            endpoints.add(("ANY", route))
    return endpoints


def _detect_frameworks(dependencies: Iterable[dict[str, Any]], files: list[Path]) -> list[str]:
    corpus = " ".join(dep["name"].lower() for dep in dependencies)
    names = {path.name.lower() for path in files}
    checks = {
        "ASP.NET Core": ["microsoft.aspnetcore", "microsoft.net.sdk.web"],
        "Azure Functions": ["azure-functions", "microsoft.net.sdk.functions", "@azure/functions"],
        "Django": ["django"],
        "Express": ["express"],
        "FastAPI": ["fastapi"],
        "Flask": ["flask"],
        "Gin": ["github.com/gin-gonic/gin"],
        "Next.js": ["next"],
        "React": ["react"],
        "Spring Boot": ["spring-boot"],
    }
    frameworks = {name for name, markers in checks.items() if any(marker in corpus for marker in markers)}
    if "host.json" in names or "function.json" in names:
        frameworks.add("Azure Functions")
    return sorted(frameworks)


def _dedupe_dependencies(dependencies: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    keyed = {
        (dep["ecosystem"], dep["name"], dep["version"], dep["manifest"]): dep
        for dep in dependencies
    }
    return [keyed[key] for key in sorted(keyed, key=lambda item: tuple(value or "" for value in item))]


def _command(
    command: str,
    manifest: str,
    confidence: str = "high",
) -> dict[str, str]:
    parent = Path(manifest).parent.as_posix()
    return {
        "command": command,
        "working_directory": parent if parent != "." else ".",
        "source_file": manifest,
        "confidence": confidence,
    }


def _commands(
    manifests: list[dict[str, str]],
    source: Path,
) -> tuple[list[dict[str, str]], list[dict[str, str]]]:
    build: list[dict[str, str]] = []
    run: list[dict[str, str]] = []
    for manifest in manifests:
        rel = manifest["path"]
        kind = manifest["type"]
        path = REPOSITORY_ROOT / rel if (REPOSITORY_ROOT / rel).is_file() else source / rel
        parent = Path(rel).parent.as_posix()
        prefix = "./mvnw" if (path.parent / "mvnw").is_file() else "mvn"
        if kind == "maven":
            build.append(_command(f"{prefix} package", rel))
            if "spring-boot" in _read_text(path).lower():
                run.append(_command(f"{prefix} spring-boot:run", rel))
        elif kind == "gradle":
            gradle = "./gradlew" if (path.parent / "gradlew").is_file() else "gradle"
            build.append(_command(f"{gradle} build", rel))
            if "spring-boot" in _read_text(path).lower():
                run.append(_command(f"{gradle} bootRun", rel))
        elif kind == "nuget" and path.suffix.lower() in {".csproj", ".fsproj"}:
            build.append(_command(f"dotnet build {path.name}", rel))
            run.append(_command(f"dotnet run --project {path.name}", rel, "medium"))
        elif kind == "npm":
            try:
                scripts = json.loads(path.read_text(encoding="utf-8")).get("scripts", {})
            except (json.JSONDecodeError, OSError, UnicodeDecodeError):
                scripts = {}
            if isinstance(scripts, dict):
                if "build" in scripts:
                    build.append(_command("npm run build", rel))
                for script in ("start", "dev", "serve"):
                    if script in scripts:
                        run.append(_command(f"npm run {script}", rel))
        elif kind == "go":
            build.append(_command("go build ./...", rel))
        elif kind == "docker":
            build.append(_command(f"docker build -f {path.name} .", rel, "medium"))
        elif kind == "compose":
            run.append(_command(f"docker compose -f {path.name} up", rel, "medium"))
    dedupe = lambda values: list({(item["command"], item["working_directory"], item["source_file"]): item for item in values}.values())
    return sorted(dedupe(build), key=lambda item: (item["working_directory"], item["command"])), sorted(
        dedupe(run), key=lambda item: (item["working_directory"], item["command"])
    )


def _pattern_evidence(
    files_text: dict[str, str],
    patterns: dict[str, list[str]],
) -> list[dict[str, Any]]:
    output: list[dict[str, Any]] = []
    for name, markers in patterns.items():
        files = sorted(
            rel for rel, text in files_text.items() if any(re.search(marker, text, re.I) for marker in markers)
        )
        if files:
            output.append({"name": name, "status": "detected", "files": files})
    return output


def _data_stores(files_text: dict[str, str]) -> list[dict[str, Any]]:
    stores: list[dict[str, Any]] = []
    for name, (category, role, patterns) in DATA_STORE_PATTERNS.items():
        files = sorted(
            rel for rel, text in files_text.items() if any(re.search(pattern, text, re.I) for pattern in patterns)
        )
        if files:
            stores.append({"name": name, "category": category, "state_role": role, "files": files})
    return stores


def _modalities(
    files_text: dict[str, str],
    api_signals: dict[str, set[str]],
) -> list[dict[str, Any]]:
    modalities: list[dict[str, Any]] = []
    text_files = sorted(
        set(api_signals.get("chat_completions", set())) | set(api_signals.get("responses_api", set()))
    )
    if text_files:
        modalities.append({"name": "text", "status": "supported", "files": text_files})
    embedding_files = sorted(api_signals.get("embeddings_api", set()))
    if embedding_files:
        modalities.append({"name": "embeddings", "status": "supported", "files": embedding_files})
    for name, patterns in MODALITY_PATTERNS.items():
        files = sorted(
            rel for rel, text in files_text.items() if any(re.search(pattern, text, re.I) for pattern in patterns)
        )
        if files:
            modalities.append({"name": name, "status": "supported", "files": files})
    return modalities or [{"name": "unknown", "status": "unknown", "files": []}]


def _parameters(
    files_text: dict[str, str],
    env_by_file: dict[str, list[str]],
) -> list[dict[str, Any]]:
    parameters: list[dict[str, Any]] = []
    for name, patterns in PARAMETER_PATTERNS.items():
        files = sorted(
            rel for rel, text in files_text.items() if any(re.search(pattern, text, re.I) for pattern in patterns)
        )
        if not files:
            continue
        config_names = sorted(
            {
                env_name
                for rel in files
                for env_name in env_by_file.get(rel, [])
                if name.replace("_", "") in env_name.lower().replace("_", "")
            }
        )
        parameters.append(
            {
                "name": name,
                "value_source": "configuration" if config_names else "unknown",
                "configuration_names": config_names,
                "files": files,
            }
        )
    return parameters


def _feature_state(files_text: dict[str, str], patterns: list[str]) -> dict[str, Any]:
    files = sorted(
        rel for rel, text in files_text.items() if any(re.search(pattern, text, re.I) for pattern in patterns)
    )
    return {"status": "supported" if files else "not-detected", "files": files}


def _structured_output(files_text: dict[str, str]) -> dict[str, Any]:
    files = sorted(
        rel
        for rel, text in files_text.items()
        if any(re.search(pattern, text, re.I) for pattern in STRUCTURED_OUTPUT_PATTERNS)
    )
    if files:
        return {"status": "supported", "files": files, "notes": "Structured-output API signals were discovered."}
    prompt_files = sorted(
        rel for rel, text in files_text.items() if any(re.search(pattern, text, re.I) for pattern in PROMPT_JSON_PATTERNS)
    )
    if prompt_files:
        return {"status": "prompt-directed", "files": prompt_files, "notes": "JSON output is requested by prompt; API-level enforcement was not detected."}
    return {"status": "not-detected", "files": [], "notes": "No structured-output evidence was discovered."}


def _state_profile(
    files_text: dict[str, str],
    stores: list[dict[str, Any]],
) -> dict[str, Any]:
    model_state_files = sorted(
        rel for rel, text in files_text.items() if any(re.search(pattern, text, re.I) for pattern in MODEL_STATE_PATTERNS)
    )
    model_stateless_files = sorted(
        rel for rel, text in files_text.items() if any(re.search(pattern, text, re.I) for pattern in MODEL_STATELESS_PATTERNS)
    )
    session_files = sorted(
        rel for rel, text in files_text.items() if any(re.search(pattern, text, re.I) for pattern in SESSION_STATE_PATTERNS)
    )
    evidence = sorted(
        set(model_state_files)
        | set(model_stateless_files)
        | set(session_files)
        | {path for store in stores for path in store["files"]}
    )
    model = "stateful" if model_state_files else "stateless" if model_stateless_files else "unknown"
    return {
        "application": "stateful" if stores else "unknown",
        "model": model,
        "session": "stateful" if session_files else "unknown",
        "files": evidence,
    }


def _migration_hints(profile: dict[str, Any]) -> list[str]:
    hints: list[str] = []
    signals = profile["api_signals"]
    if signals.get("azure_openai_client"):
        hints.append("Replace only the Azure OpenAI provider adapter; preserve application-facing contracts discovered from source evidence.")
    if signals.get("chat_completions"):
        hints.append("Translate Chat Completions messages and choice parsing to Responses input items and output_text fallback parsing.")
    if profile["openai_usage"]["configuration"]:
        hints.append("Map provider configuration by purpose and keep credential values outside source and generated artifacts.")
    if profile["endpoints"]:
        hints.append("Treat discovered HTTP routes and function triggers as preservation candidates until an owner explicitly retires them.")
    if profile["assets"]:
        hints.append("Package discovered local static assets with the target application and verify their stable paths.")
    if any(profile["deployment_signals"].values()):
        hints.append("Review container, function, Kubernetes, and infrastructure evidence independently before selecting AWS deployment services.")
    if signals.get("chat_completions") and not signals.get("responses_api"):
        hints.append("Record an explicit target model/API decision for request construction, retention, parameter handling, and response parsing.")
    if not hints:
        hints.append("No Azure OpenAI binding was confirmed; validate discovery evidence before planning a provider migration.")
    return hints


def build_dependency_map(source: Path) -> dict[str, Any]:
    source = source.resolve()
    if not source.is_dir():
        raise ValueError(f"source directory not found: {source}")
    files = _iter_files(source)
    language_files: dict[str, list[str]] = defaultdict(list)
    imports: set[str] = set()
    calls_by_file: dict[str, list[str]] = {}
    env_by_file: dict[str, list[str]] = {}
    api_signals: dict[str, set[str]] = defaultdict(set)
    service_files: dict[str, set[str]] = defaultdict(set)
    endpoint_files: dict[tuple[str, str], set[str]] = defaultdict(set)
    deployment_signals: dict[str, set[str]] = {key: set() for key in ("containers", "azure_functions", "kubernetes", "bicep", "arm")}
    manifests: list[dict[str, str]] = []
    dependencies: list[dict[str, Any]] = []
    assets: list[str] = []
    files_text: dict[str, str] = {}

    for path in files:
        rel = _rel(path, source)
        suffix = path.suffix.lower()
        if suffix in ASSET_SUFFIXES:
            assets.append(rel)
        language = LANGUAGE_SUFFIXES.get(suffix)
        if language:
            language_files[language].append(rel)

        text = _read_text(path)
        if text:
            files_text[rel] = text
        manifest_type = _manifest_type(path, text)
        if manifest_type:
            manifests.append({"path": rel, "type": manifest_type})
            dependencies.extend(_manifest_dependencies(path, source, manifest_type))
            if manifest_type in {"docker", "compose"}:
                deployment_signals["containers"].add(rel)
            elif manifest_type == "azure-functions":
                deployment_signals["azure_functions"].add(rel)
            elif manifest_type == "kubernetes":
                deployment_signals["kubernetes"].add(rel)
            elif manifest_type == "bicep":
                deployment_signals["bicep"].add(rel)
            elif manifest_type == "arm":
                deployment_signals["arm"].add(rel)

        if not text:
            continue
        env_names = _extract_env_names(path, text)
        if env_names:
            env_by_file[rel] = sorted(env_names)

        file_imports, file_calls = _source_signals(path, text)
        imports.update(file_imports)
        if file_calls:
            calls_by_file[rel] = sorted(file_calls)

        for signal, patterns in OPENAI_SIGNAL_PATTERNS.items():
            if any(re.search(pattern, text, re.I) for pattern in patterns):
                api_signals[signal].add(rel)
        for service, patterns in AZURE_SERVICE_PATTERNS.items():
            if any(re.search(pattern, text, re.I) for pattern in patterns):
                service_files[service].add(rel)
        for endpoint in _extract_endpoints(path, text):
            endpoint_files[endpoint].add(rel)
        if re.search(r"FunctionName\(|@app\.(?:function_name|route)|Microsoft\.NET\.Sdk\.Functions|azure-functions", text, re.I):
            deployment_signals["azure_functions"].add(rel)

    dependencies = _dedupe_dependencies(dependencies)
    declared_dependencies = sorted(
        f"{dep['name']}@{dep['version']}" if dep["version"] else dep["name"] for dep in dependencies
    )
    endpoints = [
        {"method": method, "path": route, "files": sorted(paths)}
        for (method, route), paths in sorted(endpoint_files.items())
    ]
    api_signal_output = {name: sorted(paths) for name, paths in sorted(api_signals.items())}
    build_commands, run_commands = _commands(manifests, source)
    data_stores = _data_stores(files_text)
    identity = _pattern_evidence(files_text, IDENTITY_PATTERNS)
    networking = _pattern_evidence(files_text, NETWORKING_PATTERNS)
    parameters = _parameters(files_text, env_by_file)
    streaming = _feature_state(files_text, STREAMING_PATTERNS)
    tool_feature = _feature_state(files_text, TOOL_PATTERNS)
    tools = (
        [{"name": "model-tools-or-function-calling", "status": "supported", "files": tool_feature["files"]}]
        if tool_feature["status"] == "supported"
        else []
    )
    structured_output = _structured_output(files_text)
    state = _state_profile(files_text, data_stores)

    providers = []
    if api_signals.get("azure_openai_client") or api_signals.get("azure_openai_configuration"):
        providers.append("azure-openai")
    if api_signals.get("bedrock_openai_configuration"):
        providers.append("amazon-bedrock-openai-compatible")
    apis = []
    for signal, api in (("chat_completions", "chat-completions"), ("responses_api", "responses"), ("embeddings_api", "embeddings")):
        if api_signals.get(signal):
            apis.append(api)
    if providers and not apis:
        apis.append("unknown")

    profile: dict[str, Any] = {
        "$schema": "urn:intelligent-azure-openai-to-aws:schema:source-profile:1.0",
        "schema_version": "1.0",
        "kind": "source-profile",
        "id": _slug(source.name),
        "generated_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "source": _display_path(source),
        "file_count": len(files),
        "languages": [
            {"name": name, "file_count": len(paths), "files": sorted(paths)}
            for name, paths in sorted(language_files.items())
        ],
        "frameworks": _detect_frameworks(dependencies, files),
        "manifests": sorted(manifests, key=lambda item: (item["path"], item["type"])),
        "dependencies": dependencies,
        "declared_dependencies": declared_dependencies,
        "imports": sorted(imports),
        "environment_variables": dict(sorted(env_by_file.items())),
        "calls_by_file": dict(sorted(calls_by_file.items())),
        "endpoints": endpoints,
        "api_signals": api_signal_output,
        "deployment_signals": {name: sorted(paths) for name, paths in deployment_signals.items()},
        "azure_services": [
            {"service": service, "files": sorted(paths)}
            for service, paths in sorted(service_files.items())
        ],
        "openai_usage": {
            "providers": providers,
            "apis": apis,
            "configuration": sorted(set().union(*env_by_file.values()) if env_by_file else set()),
            "response_parsing": sorted(
                signal for signal in ("chat_choice_parsing", "responses_output_parsing") if api_signals.get(signal)
            ),
        },
        "assets": sorted(assets),
        "build_commands": build_commands,
        "run_commands": run_commands,
        "data_stores": data_stores,
        "identity": identity,
        "networking": networking,
        "modalities": _modalities(files_text, api_signals),
        "parameters": parameters,
        "streaming": streaming,
        "tools": tools,
        "structured_output": structured_output,
        "state": state,
        "migration_hints": [],
    }
    profile["migration_hints"] = _migration_hints(profile)
    return profile


def main() -> int:
    parser = argparse.ArgumentParser(description="Discover application, Azure OpenAI, and deployment dependencies.")
    parser.add_argument("--source", required=True, type=Path, help="Source repository or application directory to inspect.")
    parser.add_argument("--out", type=Path, help="Optional source-profile JSON output path.")
    args = parser.parse_args()

    try:
        profile = build_dependency_map(args.source)
    except ValueError as exc:
        parser.error(str(exc))
    payload = json.dumps(profile, indent=2) + "\n"
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(payload, encoding="utf-8")
    print(payload, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
