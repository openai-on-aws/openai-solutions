from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any


SUPPORTED_MODEL_REGIONS = {
    "openai.gpt-5.4": {"us-east-1", "us-east-2", "us-west-2"},
    "openai.gpt-5.5": {"us-east-1", "us-east-2"},
}
AWS_MODEL_EVIDENCE = {
    "openai.gpt-5.4": "https://docs.aws.amazon.com/bedrock/latest/userguide/model-card-openai-gpt-54.html",
    "openai.gpt-5.5": "https://docs.aws.amazon.com/bedrock/latest/userguide/model-card-openai-gpt-55.html",
}
SERVICE_MAPPINGS = {
    "azure-openai": ("AI inference", "Amazon Bedrock Mantle OpenAI-compatible Responses API"),
    "azure-functions": ("Functions", "AWS Lambda"),
    "app-service": ("Managed web application", "AWS App Runner or Amazon ECS"),
    "container-apps": ("Managed containers", "Amazon ECS on AWS Fargate"),
    "aks": ("Kubernetes", "Amazon EKS"),
    "key-vault": ("Secrets", "AWS Secrets Manager"),
    "storage": ("Object and file storage", "Amazon S3 or an evidence-appropriate AWS storage service"),
    "cosmos-db": ("NoSQL data", "Amazon DynamoDB or an evidence-appropriate AWS database"),
    "service-bus": ("Messaging", "Amazon SQS and Amazon SNS"),
    "sql": ("Relational data", "Amazon RDS"),
    "postgresql": ("PostgreSQL data", "Amazon RDS for PostgreSQL or Amazon Aurora PostgreSQL-Compatible"),
    "application-insights": ("Observability", "Amazon CloudWatch and AWS X-Ray"),
    "api-management": ("API management", "Amazon API Gateway"),
}


def _load_json(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as exc:
        raise ValueError(f"cannot load {path}: {exc}") from exc
    if not isinstance(data, dict):
        raise ValueError(f"{path} must contain a JSON object")
    return data


def _write_json(path: Path, data: dict[str, Any]) -> None:
    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def _write_text(path: Path, lines: list[str]) -> None:
    path.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")


def _slug(value: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    if not slug or not slug[0].isalpha():
        slug = f"migration-{slug}".rstrip("-")
    return slug[:64]


def _validate_profile(profile: dict[str, Any]) -> None:
    required = {
        "schema_version", "kind", "id", "source", "file_count", "languages", "endpoints",
        "api_signals", "deployment_signals", "azure_services", "assets", "build_commands",
        "run_commands", "data_stores", "identity", "networking", "modalities", "parameters",
        "streaming", "tools", "structured_output", "state",
    }
    missing = sorted(required - profile.keys())
    if missing:
        raise ValueError(f"source profile is missing required fields: {', '.join(missing)}")
    if profile.get("schema_version") != "1.0" or profile.get("kind") != "source-profile":
        raise ValueError("source profile must declare schema_version 1.0 and kind source-profile")


def _inference_url(region: str) -> str:
    return f"https://bedrock-mantle.{region}.api.aws/openai/v1/responses"


def _models_url(region: str) -> str:
    return f"https://bedrock-mantle.{region}.api.aws/v1/models"


def _name_reason(value: str, option: str) -> tuple[str, str]:
    name, separator, reason = value.partition("=")
    if not separator or not name.strip() or not reason.strip():
        raise ValueError(f"{option} must use NAME=REASON")
    return name.strip(), reason.strip()


def _preservation_requirements(profile: dict[str, Any]) -> list[str]:
    requirements = [
        f"Preserve {item['method']} {item['path']} and its externally visible request and response behavior."
        for item in profile.get("endpoints", [])
    ]
    if profile.get("assets"):
        requirements.append("Preserve local static assets and the application paths that reference them.")
    if profile.get("openai_usage", {}).get("providers"):
        requirements.append("Change the provider adapter without changing unrelated application behavior.")
    return requirements or ["Preserve source behavior confirmed by repository evidence and local smoke checks."]


def _evidence(profile: dict[str, Any]) -> list[dict[str, Any]]:
    evidence: list[dict[str, Any]] = []
    for manifest in profile.get("manifests", []):
        evidence.append({"path": manifest["path"], "kind": "manifest", "signals": [manifest["type"]]})
    for signal, paths in profile.get("api_signals", {}).items():
        for path in paths:
            evidence.append({"path": path, "kind": "source", "signals": [signal]})
    for category, paths in profile.get("deployment_signals", {}).items():
        for path in paths:
            evidence.append({"path": path, "kind": "configuration", "signals": [category]})
    merged: dict[tuple[str, str], set[str]] = {}
    for item in evidence:
        merged.setdefault((item["path"], item["kind"]), set()).update(item["signals"])
    return [
        {"path": path, "kind": kind, "note": f"Discovered signals: {', '.join(sorted(signals))}."}
        for (path, kind), signals in sorted(merged.items())
    ]


def _service_mappings(profile: dict[str, Any]) -> list[dict[str, Any]]:
    mappings = []
    for item in profile.get("azure_services", []):
        service = item["service"]
        capability, aws = SERVICE_MAPPINGS.get(
            service,
            (service.replace("-", " ").title(), "Select an AWS service after architecture review"),
        )
        mappings.append(
            {
                "capability": capability,
                "source_service": service,
                "target_service": aws,
                "status": "proposed",
                "rationale": "Proposed from discovered source-service evidence; architecture-owner validation is required.",
                "evidence_files": item["files"],
            }
        )
    return mappings


def _contracts(
    profile: dict[str, Any],
    out_dir: Path,
    migration_id: str,
    objective: str,
    model_id: str | None,
    region: str | None,
    target_root: str,
    selection_type: str,
    permitted_regions: list[str],
    participant_constraints: list[tuple[str, str]],
    explicit_omissions: list[tuple[str, str]],
) -> dict[str, dict[str, Any]]:
    mappings = _service_mappings(profile)
    contract_evidence = _evidence(profile)
    evidence_paths = sorted({item["path"] for item in contract_evidence})
    preservation = _preservation_requirements(profile)
    deployment = profile.get("deployment_signals", {})
    source_env = sorted(
        {
            name
            for names in profile.get("environment_variables", {}).values()
            for name in names
            if name.startswith("AZURE_OPENAI_")
        }
    )
    source_api = "chat-completions" if "chat-completions" in profile.get("openai_usage", {}).get("apis", []) else "unknown"
    source_endpoints = profile.get("endpoints", [])
    backend_languages = {
        item["name"]
        for item in profile.get("languages", [])
        if item["name"] in {"java", "dotnet", "python", "go"}
    }
    primary_archetype = "public-web-container"
    primary_summary = "Preserve the discovered application runtime in one public web container."
    azure_service_names = {item["service"] for item in profile.get("azure_services", [])}
    if deployment.get("kubernetes"):
        primary_archetype = "kubernetes"
        primary_summary = "Retain Kubernetes deployment semantics while reviewing manifests for Amazon EKS compatibility."
    elif deployment.get("azure_functions") and not deployment.get("containers"):
        if azure_service_names & {"service-bus", "event-grid"} and not source_endpoints:
            primary_archetype = "event-worker"
            primary_summary = "Translate discovered event-driven Azure Functions bindings to Lambda or ECS with managed AWS events."
        else:
            primary_archetype = "serverless-http"
            primary_summary = "Translate discovered Azure Functions triggers and bindings to an approved AWS Lambda design."
    elif deployment.get("containers"):
        primary_archetype = "public-web-container"
        primary_summary = "Reuse discovered container packaging with an approved managed AWS container service."
    elif (
        not backend_languages
        and not source_endpoints
        and "Next.js" not in profile.get("frameworks", [])
        and (
            "React" in profile.get("frameworks", [])
            or any(item["type"] == "npm" for item in profile.get("manifests", []))
        )
    ):
        primary_archetype = "static-web"
        primary_summary = "Deploy the discovered static web assets without adding a server runtime."
    elif source_endpoints:
        primary_archetype = "serverless-http"
        primary_summary = "Package bounded stateless HTTP handlers only when state and runtime evidence permit it."
    candidate_evidence = evidence_paths[:20]
    candidate_specs = [
        (primary_archetype, primary_summary, "high", ["Preserves discovered runtime assumptions", "Requires service-specific review"], candidate_evidence),
    ]
    for archetype, summary, fit, tradeoffs, files in [
        ("public-web-container", "Package one public web workload for AWS App Runner after runtime review.", "medium", ["Portable packaging", "Public managed endpoint"], deployment.get("containers", [])),
        ("serverless-http", "Translate bounded stateless HTTP handlers to Lambda and API Gateway.", "unassessed", ["Elastic operations", "State and runtime limits require review"], sorted({path for item in profile.get("endpoints", []) for path in item["files"]})),
        ("private-container-service", "Use ECS Fargate and an ALB when private networking or deeper container control is required.", "unassessed", ["Network control", "Higher operational surface"], deployment.get("containers", [])),
        ("event-worker", "Use Lambda or ECS with SQS, SNS, or EventBridge for event-driven work.", "unassessed", ["Decoupled processing", "Requires event-contract evidence"], deployment.get("azure_functions", [])),
        ("kubernetes", "Retain Kubernetes semantics with Amazon EKS only when Kubernetes-specific requirements are proven.", "medium", ["Preserves Kubernetes control", "Higher operational complexity"], deployment.get("kubernetes", [])),
        ("static-web", "Deploy static assets through S3 and CloudFront when no server runtime is required.", "unassessed", ["Small operational footprint", "Cannot host server behavior"], profile.get("assets", [])),
    ]:
        if archetype != primary_archetype and len(candidate_specs) < 3:
            candidate_specs.append((archetype, summary, fit, tradeoffs, files))
    ranked_candidates = [
        {"rank": index, "archetype": archetype, "summary": summary, "fit": fit, "tradeoffs": tradeoffs, "evidence_files": files}
        for index, (archetype, summary, fit, tradeoffs, files) in enumerate(candidate_specs, start=1)
    ]
    model_selected = model_id is not None and region is not None
    model_label = model_id or "an approved target model"
    region_label = region or "an approved AWS Region"
    model_inference_url = _inference_url(region) if region else None
    model_documentation = AWS_MODEL_EVIDENCE.get(model_id) if model_id else None

    context = {
        "$schema": "urn:intelligent-azure-openai-to-aws:schema:migration-context:1.0",
        "schema_version": "1.0",
        "kind": "migration-context",
        "id": migration_id,
        "title": "Azure OpenAI to Amazon Bedrock migration",
        "status": "decisioning",
        "source_profile": "source-profile.json",
        "source_root": profile["source"],
        "target_root": target_root,
        "selection": {
            "type": selection_type,
            "selected_paths": [profile["source"]],
            "reason": "Caller-selected source profile boundary.",
        },
        "objective": objective,
        "scope": {
            "included_paths": [profile["source"]],
            "excluded_paths": ["generated dependencies", "build outputs", "credential values"],
            "preserve_contracts": preservation,
        },
        "participant_constraints": [
            {"id": "no-secrets", "category": "security", "statement": "Do not place secrets or credential values in source or generated artifacts.", "priority": "must", "source": "workshop instructions"},
            {"id": "generic-discovery", "category": "delivery", "statement": "Use repository evidence and never hardcode fixture-specific behavior.", "priority": "must", "source": "workshop instructions"},
            {"id": "approved-model-api", "category": "model-api", "statement": "The model and Region selection requires model-card compatibility and live /v1/models evidence.", "priority": "must", "source": "approved framework"},
        ] + [
            {"id": f"participant-{index}", "category": "other", "statement": statement, "priority": "must", "source": source}
            for index, (source, statement) in enumerate(participant_constraints, start=1)
        ],
        "permitted_aws_regions": permitted_regions,
        "principles": [
            "Preserve confirmed application contracts.",
            "Separate observed evidence from proposed target decisions.",
            "Keep local validation separate from credential-bound live validation.",
        ],
        "assumptions": ["The caller-selected source tree is complete for the intended migration boundary."],
        "open_questions": ["Which proposed AWS service mappings will the architecture owner accept?"],
        "evidence": contract_evidence,
    }
    architecture = {
        "$schema": "urn:intelligent-azure-openai-to-aws:schema:architecture-decision:1.0",
        "schema_version": "1.0",
        "kind": "architecture-decision",
        "id": f"{migration_id}.architecture",
        "title": "Preserve application contracts and replace the provider adapter",
        "status": "proposed",
        "context": f"The source profile records {profile['file_count']} files, {len(profile.get('dependencies', []))} dependency records, and {len(profile.get('endpoints', []))} route or trigger candidates.",
        "ranked_candidates": ranked_candidates,
        "selected_archetype": "undecided",
        "confidence": "low",
        "rationale": "Discovery ranks candidates but does not select an architecture. The migration architect must accept a candidate after workload, participant, and AWS service constraints are validated.",
        "rejected_alternatives": [],
        "required_transformations": [
            {"id": "replace-provider-adapter", "area": "model-api", "description": "Replace Azure OpenAI request, authentication, and response parsing with Amazon Bedrock Mantle Responses.", "status": "required", "evidence_files": sorted(set(profile.get("api_signals", {}).get("azure_openai_client", []) + profile.get("api_signals", {}).get("chat_completions", [])))},
            {"id": "map-runtime-configuration", "area": "configuration", "description": "Map configuration by purpose without copying credential values.", "status": "planned", "evidence_files": sorted(profile.get("environment_variables", {}))},
            {"id": "preserve-public-contracts", "area": "application", "description": "Retain confirmed routes, triggers, static assets, validation, and response behavior.", "status": "planned", "evidence_files": sorted({path for item in profile.get("endpoints", []) for path in item["files"]})},
        ],
        "service_mappings": mappings,
        "risks": [
            {"id": "contract-regression", "statement": "Provider migration can change externally visible behavior.", "severity": "high", "mitigation": "Freeze source behavior and repeat contract smoke checks against the generated target."},
            {"id": "service-overreach", "statement": "Inferred AWS mappings may exceed the approved migration scope.", "severity": "medium", "mitigation": "Require architecture-owner acceptance for every proposed service mapping."},
        ],
        "blockers": [
            {"id": "architecture-selection", "statement": "No target architecture has been selected by generated discovery.", "owner": "migration-architect", "resolution": "Review ranked candidates, service mappings, workload constraints, and required transformations."},
            {"id": "model-availability", "statement": f"Live availability of {model_label} in {region_label} is not established.", "owner": "migration-validation", "resolution": "Select a model/Region through the architect workflow and validate the authoritative /v1/models listing with user-managed credentials."},
        ] + (
            [
                {
                    "id": "static-inference-identity",
                    "statement": "A static browser application cannot safely hold Amazon Bedrock credentials.",
                    "owner": "migration-architect",
                    "resolution": "Propose the smallest approved server-side inference facade and re-rank static-web with serverless-http.",
                }
            ]
            if primary_archetype == "static-web" and "azure-openai" in azure_service_names
            else []
        ),
        "owners": ["migration-architect"],
        "related_contracts": ["migration-context.json", "model-api-decision.json", "deployment-manifest.json"],
        "evidence": contract_evidence,
    }
    api_evidence = sorted(set(profile.get("api_signals", {}).get("chat_completions", []) + profile.get("api_signals", {}).get("responses_api", [])))
    capabilities: list[dict[str, Any]] = []
    for item in profile.get("modalities", []):
        capabilities.append(
            {
                "name": item["name"],
                "source_support": "supported" if item.get("status") == "supported" else "unknown",
                "target_support": "unknown",
                "decision": "review-required",
                "evidence_files": item.get("files", []),
            }
        )
    for field, name in [("streaming", "streaming"), ("structured_output", "structured-output")]:
        feature = profile.get(field, {})
        capabilities.append(
            {
                "name": name,
                "source_support": "supported" if feature.get("status") in {"supported", "prompt-directed"} else "unknown",
                "target_support": "unknown",
                "decision": "review-required",
                "evidence_files": feature.get("files", []),
            }
        )
    for item in profile.get("tools", []):
        capabilities.append(
            {
                "name": f"tool:{item['name']}",
                "source_support": "supported" if item.get("status") == "supported" else "unknown",
                "target_support": "unknown",
                "decision": "review-required",
                "evidence_files": item.get("files", []),
            }
        )
    if not capabilities:
        capabilities.append(
            {
                "name": "text-generation",
                "source_support": "unknown",
                "target_support": "unknown",
                "decision": "review-required",
                "evidence_files": api_evidence,
            }
        )
    omission_reasons = dict(explicit_omissions)
    parameter_evidence = {item["name"]: item.get("files", []) for item in profile.get("parameters", [])}
    parameter_names = sorted(set(parameter_evidence) | set(omission_reasons))
    parameter_decisions = [
        {
            "source_name": name,
            "action": "omit" if name in omission_reasons else "review-required",
            "reason": omission_reasons.get(name, "No target mapping is accepted until model and API compatibility are reviewed."),
            "evidence_files": parameter_evidence.get(name, []),
        }
        for name in parameter_names
    ]
    omitted_parameters = [
        {
            "name": name,
            "reason": reason,
            "decision_source": "participant-constraint",
            "evidence_files": parameter_evidence.get(name, []),
        }
        for name, reason in explicit_omissions
    ]
    target_selection: dict[str, Any] = {
        "strategy": "model-id" if model_selected else "undecided",
        "value": model_id if model_selected else None,
        "configuration_name": "BEDROCK_OPENAI_MODEL_ID",
        "candidates": [
            {
                "model_id": candidate_model,
                "compatible_regions": sorted(candidate_regions),
                "model_card": AWS_MODEL_EVIDENCE[candidate_model],
            }
            for candidate_model, candidate_regions in sorted(SUPPORTED_MODEL_REGIONS.items())
        ],
    }
    availability_gate: dict[str, Any] = {
        "strategy": "list-models",
        "failure_behavior": "block",
        "required_capabilities": ["responses"],
        "verified": False,
        "live_models_evidence": [],
    }
    if region:
        availability_gate["region"] = region
    model_evidence = [
        {
            "path": "https://docs.aws.amazon.com/bedrock/latest/userguide/bedrock-mantle.html",
            "kind": "documentation",
            "note": "Authoritative Responses and model-listing behavior; live account evidence is still required.",
        }
    ]
    if model_documentation:
        model_evidence.insert(
            0,
            {
                "path": model_documentation,
                "kind": "documentation",
                "note": "Authoritative model-card evidence for model ID, compatible Regions, and Responses endpoint shape.",
            },
        )
    model_api = {
        "$schema": "urn:intelligent-azure-openai-to-aws:schema:model-api-decision:1.0",
        "schema_version": "1.0",
        "kind": "model-api-decision",
        "id": f"{migration_id}.model-api",
        "status": "proposed",
        "source": {"provider": "microsoft", "service": "azure-openai", "api_family": source_api, "model_selection": {"strategy": "deployment-name", "configuration_name": next((name for name in source_env if "DEPLOYMENT" in name), "AZURE_OPENAI_DEPLOYMENT")}, "configuration": source_env},
        "target": {"provider": "aws", "service": "amazon-bedrock-mantle", "api_family": "responses", "model_selection": target_selection, "configuration": ["OPENAI_BASE_URL", "OPENAI_API_KEY", "BEDROCK_OPENAI_MODEL_ID"]},
        "inference_url": model_inference_url,
        "supported_capabilities": capabilities,
        "operation_mappings": [
            {"source_operation": source_api, "target_operation": "POST /openai/v1/responses", "input_strategy": "Review source payload evidence and record an explicit Responses input transformation.", "output_strategy": "Review source response parsing and record an explicit Responses output transformation."}
        ],
        "parameter_decisions": parameter_decisions,
        "omitted_parameters": omitted_parameters,
        "response_contracts": [
            {"name": f"{item['method']} {item['path']}", "preservation": "exact", "notes": "Preserve the externally visible contract while replacing provider parsing.", "evidence_files": item["files"]}
            for item in profile.get("endpoints", [])
        ],
        "availability_gate": availability_gate,
        "security": {"source_auth": "Azure OpenAI credential or managed identity discovered from runtime configuration", "target_auth": "Amazon Bedrock API key or AWS credentials supplied at runtime", "secret_handling": ["Store only environment or secret references.", "Never write credential values to generated contracts or logs."]},
        "risks": ["Model access and Region availability are account-specific.", "Source request parameters may not have one-to-one Responses equivalents."],
        "blockers": [
            (
                f"Confirm {model_id} is listed and Responses-compatible in {region}; stop without substitution if unavailable."
                if model_selected
                else "The migration architect must select a model and compatible Region from current model cards before live /v1/models validation."
            ),
            "Record redacted live /v1/models evidence before changing this decision to accepted.",
        ],
        "evidence": model_evidence,
    }
    runtime_names = ", ".join(item["name"] for item in profile.get("languages", [])) or "runtime to be confirmed"
    compute_service = "Undecided; accept an architecture-decision candidate before deployment generation"
    data_target_by_source = {
        mapping["source_service"]: mapping["target_service"]
        for mapping in mappings
        if mapping["source_service"] in {"storage", "cosmos-db", "sql", "postgresql"}
    }
    data_services = [
        {
            "id": f"data-{index}",
            "service": data_target_by_source.get(store["name"], f"Undecided target for discovered {store['name']} store"),
            "data_class": f"{store['category']} / {store['state_role']}",
            "migration_strategy": "Preserve source data behavior; validate schema, consistency, and cutover requirements before selecting a target.",
            "backup_strategy": "Define recovery point and restore validation before deployment.",
            "encryption": "Confirm source requirements and select an approved AWS encryption design.",
        }
        for index, store in enumerate(profile.get("data_stores", []), start=1)
    ]
    public_interfaces = [
        {"name": f"{item['method']} {item['path']}", "type": "http" if item["method"] != "TRIGGER" else "event", "location": item["path"], "authentication": "Preserve source behavior unless an approved decision changes it.", "contract_status": "review-required"}
        for item in profile.get("endpoints", [])
    ]
    containers = [
        {"name": f"container-{index}", "source_path": path, "registry": "Undecided", "platform": "Unknown; confirm source and target CPU architecture", "non_root": "unknown"}
        for index, path in enumerate(deployment.get("containers", []), start=1)
    ]
    all_configuration_names = sorted(
        {
            name
            for names in profile.get("environment_variables", {}).values()
            for name in names
        }
    )
    secret_names = [
        name
        for name in all_configuration_names
        if re.search(r"(?:KEY|SECRET|TOKEN|PASSWORD|CONNECTION_STRING|CREDENTIAL)", name, re.IGNORECASE)
    ]
    secrets = [
        {
            "name": name,
            "classification": "secret",
            "source": "undecided",
            "consumers": ["application-runtime"],
            "rotation": "Confirm source rotation and select a target secret store; never copy values into artifacts.",
        }
        for name in secret_names
    ]
    health_checks = [
        {
            "component": "application-runtime",
            "protocol": "http",
            "path_or_command": item["path"],
            "expected_result": "Confirm the source status code and response contract, then preserve it in the target.",
        }
        for item in profile.get("endpoints", [])
        if re.search(r"(?:health|ready|live)", item["path"], re.IGNORECASE)
    ]
    model_destination = model_inference_url or "unresolved:model-api-decision"
    model_egress = (
        [f"Allow HTTPS to bedrock-mantle.{region}.api.aws after model and Region approval."]
        if region
        else ["Model API egress is unresolved until model and Region approval."]
    )
    deployment = {
        "$schema": "urn:intelligent-azure-openai-to-aws:schema:deployment-manifest:1.0",
        "schema_version": "1.0",
        "kind": "deployment-manifest",
        "id": f"{migration_id}.deployment",
        "status": "draft",
        "target_cloud": "aws",
        "environments": [{"name": "workshop", "regions": permitted_regions, "account_boundary": "Participant-owned AWS account; no account identifiers stored in artifacts."}],
        "compute": [{"id": "application-runtime", "service": compute_service, "runtime": runtime_names, "source_paths": [profile["source"]], "scaling": "Define from workload evidence before deployment.", "identity": "Use a least-privilege AWS runtime role."}],
        "data": data_services,
        "integration": [{"id": "bedrock-responses", "type": "model-api", "source": "application-runtime", "destination": model_destination, "protocol": "HTTPS Responses API", "authentication": "Undecided; select an approved runtime authentication mechanism without embedding values."}],
        "network": {"vpc": "Decision pending workload and selected service requirements.", "ingress": ["Preserve approved public interfaces only."], "egress": model_egress, "private_connectivity": ["Review after target services are accepted."], "dns": ["Define only for approved public endpoints."], "tls": ["Require TLS for public and model API traffic."]},
        "secrets": secrets,
        "observability": {"logs": ["Application and platform logs in Amazon CloudWatch."], "metrics": ["Latency, errors, request count, and model usage."], "traces": ["Propagate request correlation without prompt or credential leakage."], "alarms": ["Define availability and error-rate alarms before production."], "redaction": ["Redact authorization headers, API keys, prompts, and sensitive response content."]},
        "containers": containers,
        "health_checks": health_checks,
        "public_interfaces": public_interfaces,
        "agentcore": {"enabled": False, "reason": "AgentCore is not selected automatically by generic discovery.", "runtime": "not-applicable", "interfaces": [], "identity": "not-applicable", "status": "not-selected"},
        "approvals": [
            {"id": "architecture-approval", "scope": "Accept target archetype and service mappings.", "required_from": "migration-architect", "status": "pending", "evidence": ["architecture-decision.json"]},
            {"id": "model-access-approval", "scope": f"Select and verify {model_label} in {region_label}.", "required_from": "migration-validation", "status": "pending", "evidence": ["model-api-decision.json"]},
        ],
        "teardown_inventory": [{"resource_type": "all generated workshop resources", "identifier_source": "deployment outputs and tags", "deletion_order": 1, "retention": "review-required", "verification": "Confirm each generated resource is deleted or explicitly retained."}],
        "validation_gates": [
            {"id": "source-baseline", "description": "Record source contract behavior.", "status": "pending", "evidence": []},
            {"id": "target-local", "description": "Repeat preserved contract checks against the generated target.", "status": "pending", "evidence": []},
            {"id": "model-availability", "description": f"Select and verify {model_label} and Responses in {region_label}.", "status": "pending", "evidence": []},
            {"id": "secret-review", "description": "Confirm source, artifacts, deployment, and logs contain no credential values.", "status": "pending", "evidence": []},
        ],
        "evidence": contract_evidence,
    }
    return {
        "migration-context.json": context,
        "architecture-decision.json": architecture,
        "model-api-decision.json": model_api,
        "deployment-manifest.json": deployment,
    }


def _format_paths(paths: list[str]) -> str:
    return ", ".join(f"`{path}`" for path in paths) if paths else "No direct source evidence"


def _markdown_artifacts(
    profile: dict[str, Any],
    contracts: dict[str, dict[str, Any]],
    out_dir: Path,
) -> None:
    model = contracts["model-api-decision.json"]
    architecture = contracts["architecture-decision.json"]
    context = contracts["migration-context.json"]
    model_id = model["target"]["model_selection"].get("value") or "unresolved"
    region = model["availability_gate"].get("region") or "unresolved"
    inference_url = model.get("inference_url") or "unresolved"
    models_url = _models_url(region) if region != "unresolved" else "unresolved"
    language_summary = ", ".join(f"{item['name']} ({item['file_count']})" for item in profile.get("languages", [])) or "none detected"
    frameworks = ", ".join(profile.get("frameworks", [])) or "none detected"

    discovery = [
        "# Source Discovery Summary",
        "",
        "Generated from repository evidence. Validate inferred signals before target generation.",
        "",
        "## Inventory",
        "",
        f"- Source: `{profile['source']}`",
        f"- Files inspected: `{profile['file_count']}`",
        f"- Languages: {language_summary}",
        f"- Frameworks: {frameworks}",
        f"- Dependency records: `{len(profile.get('dependencies', []))}`",
        f"- Local assets: `{len(profile.get('assets', []))}`",
        f"- Build commands: `{len(profile.get('build_commands', []))}`",
        f"- Run commands: `{len(profile.get('run_commands', []))}`",
        f"- Data stores: `{len(profile.get('data_stores', []))}`",
        f"- Identity signals: `{len(profile.get('identity', []))}`",
        f"- Networking signals: `{len(profile.get('networking', []))}`",
        f"- Modalities: `{len(profile.get('modalities', []))}`",
        f"- Model parameters: `{len(profile.get('parameters', []))}`",
        f"- Streaming: `{profile.get('streaming', {}).get('status', 'unknown')}`",
        f"- Tools: `{len(profile.get('tools', []))}`",
        f"- Structured output: `{profile.get('structured_output', {}).get('status', 'unknown')}`",
        f"- Application state: `{profile.get('state', {}).get('application', 'unknown')}`",
        "",
        "## Azure Services",
        "",
    ]
    if profile.get("azure_services"):
        discovery.extend(f"- `{item['service']}`: {_format_paths(item['files'])}" for item in profile["azure_services"])
    else:
        discovery.append("- No Azure service binding was confirmed.")
    discovery.extend(["", "## API And Model Signals", ""])
    if profile.get("api_signals"):
        discovery.extend(f"- `{signal}`: {_format_paths(paths)}" for signal, paths in profile["api_signals"].items())
    else:
        discovery.append("- No OpenAI API signal was confirmed.")
    discovery.extend(["", "## Routes And Triggers", ""])
    if profile.get("endpoints"):
        discovery.extend(f"- `{item['method']} {item['path']}`: {_format_paths(item['files'])}" for item in profile["endpoints"])
    else:
        discovery.append("- No routes or triggers were discovered; manual contract discovery is required.")
    _write_text(out_dir / "source-discovery-summary.md", discovery)

    plan = [
        "# Migration Plan",
        "",
        f"Objective: {context['objective']}",
        "",
        "## Required Moves",
        "",
        "1. Validate the source profile and mark false positives or missing runtime evidence.",
        "2. Freeze public routes, triggers, static assets, and response shapes that must remain stable.",
        "3. Replace the Azure OpenAI adapter with Amazon Bedrock Mantle Responses request and response handling.",
        f"4. Gate live work on `{model_id}` availability in `{region}`.",
        "5. Review every proposed Azure-to-AWS service mapping before generating deployment infrastructure.",
        "6. Run local source and target contract smoke checks before credential-bound live validation.",
        "",
        "## Model Contract",
        "",
        f"- API: `{model['target']['api_family']}`",
        f"- Model: `{model_id}`",
        f"- Full inference URL: `{inference_url}`",
        f"- Model discovery URL: `{models_url}`",
        "- Explicitly omitted parameters: "
        + (
            ", ".join(f"`{item['name']}`" for item in model["omitted_parameters"])
            if model["omitted_parameters"]
            else "none accepted yet; parameter mapping remains under architecture review"
        ),
        "",
        "## Discovery Hints",
        "",
    ]
    plan.extend(f"- {hint}" for hint in profile.get("migration_hints", []))
    _write_text(out_dir / "migration-plan.md", plan)

    matrix = [
        "# Migration Matrix Seed",
        "",
        "This is an evidence-derived seed. Architecture, validation, and deployment owners must review proposed target choices.",
        "",
        "| Concern | Source evidence | Proposed target | Confidence |",
        "|---|---|---|---|",
    ]
    for mapping in architecture["service_mappings"]:
        matrix.append(f"| {mapping['capability']} | `{mapping['source_service']}` in {_format_paths(mapping.get('evidence_files', []))} | {mapping['target_service']} | {mapping['status']} |")
    for endpoint in profile.get("endpoints", []):
        matrix.append(f"| Public contract | `{endpoint['method']} {endpoint['path']}` in {_format_paths(endpoint['files'])} | Preserve request, response, and validation behavior | observed |")
    if profile.get("assets"):
        matrix.append(f"| Static assets | `{len(profile['assets'])}` local assets | Package with owning target component and verify paths | observed |")
    matrix.append(f"| Model API | Azure/OpenAI evidence in source profile | `{model_id}` via Responses at `{inference_url}` | {model['status']} |")
    _write_text(out_dir / "migration-matrix.seed.md", matrix)
    _write_text(out_dir / "migration-matrix.md", [line.replace("Migration Matrix Seed", "Migration Matrix", 1) for line in matrix])

    architecture_summary = [
        "# Architecture Summary",
        "",
        f"Decision status: `{architecture['status']}`.",
        "",
        architecture["rationale"],
        "",
        "## Service Mappings",
        "",
    ]
    if architecture["service_mappings"]:
        architecture_summary.extend(f"- `{item['source_service']}` -> {item['target_service']} ({item['status']})" for item in architecture["service_mappings"])
    else:
        architecture_summary.append("- No non-model Azure service mapping is justified by current evidence.")
    _write_text(out_dir / "architecture-summary.md", architecture_summary)

    smoke = [
        "# Smoke Check Checklist",
        "",
        "- [ ] Validate all five JSON contracts with `tools/validate_migration_contracts.py`.",
        "- [ ] Start the source locally without cloud credentials when a mock or local mode exists.",
    ]
    smoke.extend(f"- [ ] Record the source baseline for `{item['method']} {item['path']}`." for item in profile.get("endpoints", []))
    if profile.get("assets"):
        smoke.append("- [ ] Verify representative local assets return the expected content type and bytes.")
    smoke.extend(
        [
            "- [ ] Generate the target and repeat every confirmed source contract check locally.",
            f"- [ ] Confirm `{model_id}` is available in `{region}` before live inference.",
            "- [ ] Confirm the live request uses Responses and matches every explicit parameter decision and omission.",
            "- [ ] Confirm logs and generated evidence contain no credential values.",
        ]
    )
    _write_text(out_dir / "smoke-checklist.md", smoke)

    release = [
        "# Artifact Safety Checklist",
        "",
        "- [ ] Generated files are in the caller-selected output directory.",
        "- [ ] JSON contracts validate and use canonical cross-contract references.",
        "- [ ] No API key, token, connection string, or secret value appears in generated artifacts.",
        "- [ ] Source evidence paths are relative or intentionally documented.",
        "- [ ] Proposed AWS mappings are not described as deployed or live-validated.",
        "- [ ] Live validation remains blocked until model access and credentials are user-configured.",
    ]
    _write_text(out_dir / "release-checklist.md", release)

    handoff = [
        "# Migration Handoff",
        "",
        f"Migration id: `{context['id']}`",
        "",
        "## Contract Files",
        "",
        "- `migration-context.json`",
        "- `source-profile.json`",
        "- `architecture-decision.json`",
        "- `model-api-decision.json`",
        "- `deployment-manifest.json`",
        "",
        "## Required Owner Reviews",
        "",
        "1. Discovery owner confirms language, framework, endpoint, asset, Azure service, and model API evidence.",
        "2. Architecture owner accepts or revises proposed AWS service mappings.",
        "3. Validation owner records source and generated-target behavior evidence.",
        "4. Deployment owner confirms packaging, runtime configuration references, model access, IAM, logging, rollback, and teardown.",
        "",
        "## Current Blockers",
        "",
    ]
    handoff.extend(f"- {blocker}" for blocker in model["blockers"])
    handoff.extend(f"- {blocker['statement']}" for blocker in architecture["blockers"])
    _write_text(out_dir / "migration-handoff.md", handoff)


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate generic Azure OpenAI to AWS migration contracts and handoff artifacts.")
    parser.add_argument("--dependency-map", "--source-profile", dest="source_profile", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument(
        "--model-id",
        choices=sorted(SUPPORTED_MODEL_REGIONS),
        help="Optional provisional architect-selected model; requires --aws-region and live availability remains a separate gate.",
    )
    parser.add_argument(
        "--aws-region",
        help="Optional provisional Region; requires --model-id and must be supported by that model card.",
    )
    parser.add_argument("--migration-id")
    parser.add_argument("--target-root", default="apps/aws-target-app")
    parser.add_argument(
        "--selection-type",
        choices=["repository", "application", "monorepo-component", "explicit-paths"],
        default="application",
    )
    parser.add_argument(
        "--permitted-aws-region",
        action="append",
        default=[],
        choices=sorted(set().union(*SUPPORTED_MODEL_REGIONS.values())),
    )
    parser.add_argument(
        "--participant-constraint",
        action="append",
        default=[],
        metavar="SOURCE=STATEMENT",
    )
    parser.add_argument(
        "--omit-parameter",
        action="append",
        default=[],
        metavar="NAME=EVIDENCE_BACKED_REASON",
        help="Record an explicit architect-approved target omission; may be repeated.",
    )
    parser.add_argument("--objective", default="Migrate the discovered Azure OpenAI integration to Amazon Bedrock while preserving confirmed application contracts.")
    args = parser.parse_args()

    if (args.model_id is None) != (args.aws_region is None):
        parser.error("--model-id and --aws-region must be supplied together for a provisional model decision")
    if args.model_id and args.aws_region not in SUPPORTED_MODEL_REGIONS[args.model_id]:
        parser.error(f"{args.model_id} is supported by this framework only in: {', '.join(sorted(SUPPORTED_MODEL_REGIONS[args.model_id]))}")
    try:
        profile = _load_json(args.source_profile)
        _validate_profile(profile)
        constraints = [_name_reason(value, "--participant-constraint") for value in args.participant_constraint]
        omissions = [_name_reason(value, "--omit-parameter") for value in args.omit_parameter]
        omission_names = [name.lower() for name, _ in omissions]
        if len(omission_names) != len(set(omission_names)):
            raise ValueError("--omit-parameter names must be unique")
    except ValueError as exc:
        parser.error(str(exc))

    migration_id = _slug(args.migration_id or f"{profile['id']}-to-aws")
    out_dir = args.out
    out_dir.mkdir(parents=True, exist_ok=True)
    permitted_regions = sorted(set(args.permitted_aws_region) | ({args.aws_region} if args.aws_region else set()))
    contracts = _contracts(
        profile,
        out_dir,
        migration_id,
        args.objective,
        args.model_id,
        args.aws_region,
        args.target_root,
        args.selection_type,
        permitted_regions,
        constraints,
        omissions,
    )

    _write_json(out_dir / "source-profile.json", profile)
    _write_json(out_dir / "dependency-map.json", profile)
    for name, contract in contracts.items():
        _write_json(out_dir / name, contract)
    _markdown_artifacts(profile, contracts, out_dir)
    print(f"Generated migration contracts and workshop artifacts in {out_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
