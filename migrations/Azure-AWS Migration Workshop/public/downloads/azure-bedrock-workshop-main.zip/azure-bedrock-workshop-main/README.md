# Intelligent Azure OpenAI To AWS Migration Workshop

This participant workspace uses Codex Desktop agents to inspect an Azure OpenAI Chat Completions application, design an evidence-backed AWS target, migrate inference to Amazon Bedrock OpenAI Responses, validate the target locally, and deploy it only after explicit approval.

Hosted workshop hub: https://azure-bedrock-migration-workshop-psh99abs7.vercel.app/preview

The bundled Azure AI Shopping Cart is the known-good reference application. You can instead select another local application root or a Git repository. Discovery, architecture, model selection, validation, and deployment decisions are derived from the selected source.

## Workspace Contents

- `apps/azure-ai-shopping-cart-app/` - curated MIT-licensed reference source.
- `apps/aws-target-app/` - intentionally empty until Codex generates the approved target.
- `schemas/` - JSON contracts for source, architecture, model/API, and deployment decisions.
- `tools/` - generic discovery, artifact generation, contract validation, and readiness helpers.
- `deploy/aws-cdk/` - manifest-driven AWS CDK archetype factory.
- `docs/` and `rules/` - migration, security, approval, and deployment guidance.

The starter contains no preconfigured migration agents, generated target, generated manifests, credentials, or build output. The hosted task cards create the agents and orchestrate them one invocation at a time.

The penultimate task packages the validated method as a reusable `azure-bedrock-migration` Codex plugin before the final teardown. The generated plugin accepts an application folder and carries the workshop's orchestration, specialist contracts, schemas, validators, AWS guidance, deployment archetypes, and approval gates without including the bundled sample implementation or participant data.

## Start The Reference Source

The reference app uses a Spring Boot service, React frontend, local H2 database, and deterministic mock inference. This proves the baseline without Azure credentials.

```bash
cd apps/azure-ai-shopping-cart-app/src/ai-shopping-cart-service
SPRING_PROFILES_ACTIVE=local SHOPPING_CART_AI_MOCK=true ./mvnw spring-boot:run
```

In another terminal:

```bash
cd apps/azure-ai-shopping-cart-app/src/frontend
npm ci
REACT_APP_API_URL=http://localhost:8080 npm start
```

The task cards ask Codex to discover and run the equivalent commands when a different source is selected. Do not assume Maven, Spring, React, H2, or these API routes for another application.

## Migration Contracts

Codex writes working artifacts to `/tmp/workshop-artifacts` and validates them against:

- `migration-context.schema.json`
- `source-profile.schema.json`
- `architecture-decision.schema.json`
- `model-api-decision.schema.json`
- `deployment-manifest.schema.json`

`model-api-decision.json` stores the complete, authoritative inference URL. The workflow never assumes every supported model can be called by appending `/responses` to a generic base URL.

The supported target models are limited to available Amazon Bedrock OpenAI models `openai.gpt-5.4` and `openai.gpt-5.5`, using the Responses API. Model and Region selection must be supported by the model card, API compatibility documentation, and the participant account's live model listing.

## AWS Architecture Selection

The architect ranks two or three compatible options and selects the simplest evidence-backed archetype:

| Archetype | Typical AWS services |
|---|---|
| `static-web` | Amazon S3 and Amazon CloudFront |
| `serverless-http` | AWS Lambda and Amazon API Gateway |
| `public-web-container` | AWS App Runner |
| `private-container-service` | Amazon ECS on Fargate and Application Load Balancer |
| `event-worker` | Lambda or ECS with SQS, SNS, or EventBridge |
| `kubernetes` | Amazon EKS when Kubernetes-specific requirements are proven |

Data, messaging, secrets, networking, and observability modules are conditional. Amazon Bedrock AgentCore is selected only when the source has genuine agent, tool, session, or orchestration requirements.

## Approval Gates

The main Codex session must stop at three explicit gates:

- `APPROVE MIGRATION` authorizes behavior-preserving source and target changes after the migration contract is presented.
- `DEPLOY` authorizes AWS resource creation after read-only account, model, quota, permission, cost, and CDK-diff preflight.
- `DESTROY` authorizes teardown after the deployed application has been validated.

No gate may be inferred from an earlier message. Production data is never moved by this workshop; Codex may generate schemas, sandbox seed data, and a separate production data migration plan.

## Security And Model Guidance

- Keep all credentials in the terminal or an approved secret store.
- `OPENAI_API_KEY` is an Amazon Bedrock API key, not an OpenAI Platform key.
- Model discovery uses `https://bedrock-mantle.{region}.api.aws/v1/models`.
- Inference uses the exact URL recorded in `model-api-decision.json`, for example the model-card path ending in `/openai/v1/responses` for supported GPT-5.4 or GPT-5.5 tuples.
- Responses requests set `store: false` unless the approved source contract requires supported stateful behavior.
- Azure source parameters are evidence. Do not automatically map `temperature`, `top_p`, roles, tools, streaming, structured output, or state semantics without compatibility evidence.
- Stop with a factual blocker when neither supported Bedrock OpenAI model can preserve required behavior.

## Public Starter Rules

- Keep `apps/aws-target-app/` empty except for `.gitkeep` in the starter.
- Keep generated artifacts under `/tmp/workshop-artifacts`.
- Do not commit `.env` files, cloud credentials, generated manifests, build output, or local paths.
- Use the hosted task cards in order; each card contains one prompt for the main Codex Desktop session.
