# Upstream Attribution

This workshop vendors a curated snapshot of the official Azure Samples AI Shopping Cart application.

- Upstream repository: https://github.com/Azure-Samples/app-templates-java-openai-springapps
- Snapshot commit: `d3061b97ba58d1e04aceaa0d6e86d2ef2bf448e5`
- Upstream license: MIT

## Workshop Modifications

- Added a local Spring profile backed by H2 so the source service can run without PostgreSQL.
- Added `SHOPPING_CART_AI_MOCK=true` mode for deterministic local source validation without live Azure OpenAI credentials.
- Split the AI recommendation provider behind `ShoppingCartAiRecommendations` so Codex agents can discover the Azure OpenAI Chat Completions seam.
- Kept the live Azure OpenAI path using `OpenAIClientBuilder`, `ChatCompletionsOptions`, and `getChatCompletions`.
- Made the Azure OpenAI deployment name configurable; participants provide a deployment that supports the source adapter's Chat Completions API and request parameters.
- Removed unused frontend quality-runner dependencies and setup file from the vendored public package.
- Replaced the unmaintained Create React App package wrapper with Vite while preserving the React source shape and `REACT_APP_API_URL` runtime configuration.
- Removed upstream Azure deployment infrastructure from this starter package; the workshop focuses on local migration and GitHub/Vercel publication.
