# AI Shopping Cart Azure Source App

This is the public workshop source app. It is a curated snapshot of the official Azure Samples AI Shopping Cart application, adapted so participants can run it locally while preserving the Azure OpenAI Chat Completions migration seam.

## Upstream Source

- Repository: https://github.com/Azure-Samples/app-templates-java-openai-springapps
- Snapshot commit: `d3061b97ba58d1e04aceaa0d6e86d2ef2bf448e5`
- License: MIT

Workshop-specific changes are documented in `UPSTREAM.md`.

## Run The Source Service Locally

Use local mode for the workshop baseline. It uses H2 for cart state and deterministic mock Azure OpenAI responses.

```bash
cd src/ai-shopping-cart-service
SPRING_PROFILES_ACTIVE=local SHOPPING_CART_AI_MOCK=true ./mvnw spring-boot:run
```

The service listens on `http://localhost:8080`.

## Run The Source Frontend Locally

```bash
cd src/frontend
npm install
REACT_APP_API_URL=http://localhost:8080 npm start
```

The frontend listens on `http://localhost:3000`.

## Source Smoke Checks

```bash
curl -s -X DELETE http://localhost:8080/api/cart-items
curl -s -X POST http://localhost:8080/api/cart-items \
  -H 'content-type: application/json' \
  -d '{"name":"spinach","category":"produce","quantity":2}'
curl -s -X POST http://localhost:8080/api/cart-items \
  -H 'content-type: application/json' \
  -d '{"name":"salmon","category":"protein","quantity":1}'
curl -s http://localhost:8080/api/cart-items
curl -s http://localhost:8080/api/cart-items/ai-nutrition-analysis
curl -s http://localhost:8080/api/cart-items/top-3-recipes
```

## Live Azure OpenAI Source Mode

To run against Azure OpenAI instead of mock mode, provide a real Azure OpenAI deployment name. `AZURE_OPENAI_DEPLOYMENT_ID` is the deployment name you chose in Azure, and that deployment must support the Chat Completions API and request parameters used by this source app.

```bash
cd src/ai-shopping-cart-service
read -s AZURE_OPENAI_API_KEY
export AZURE_OPENAI_API_KEY
SPRING_PROFILES_ACTIVE=local \
SHOPPING_CART_AI_MOCK=false \
AZURE_OPENAI_ENDPOINT=https://YOUR-RESOURCE.openai.azure.com \
AZURE_OPENAI_DEPLOYMENT_ID=your-chat-completions-deployment \
AZURE_OPENAI_ADD_JSON_POSTFIX=false \
./mvnw spring-boot:run
```

`AZURE_OPENAI_TEMPERATURE` and `AZURE_OPENAI_TOP_P` are source-only Chat Completions evidence. The migration architect must verify parameter compatibility for the selected Amazon Bedrock OpenAI Responses tuple rather than copying them automatically.
