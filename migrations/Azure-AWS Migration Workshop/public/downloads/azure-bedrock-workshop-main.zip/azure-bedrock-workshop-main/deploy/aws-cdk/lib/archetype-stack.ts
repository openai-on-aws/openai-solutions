import {
  CfnOutput,
  Stack,
  StackProps,
  Tags,
} from "aws-cdk-lib";
import * as ec2 from "aws-cdk-lib/aws-ec2";
import * as kms from "aws-cdk-lib/aws-kms";
import { Construct } from "constructs";
import { createWorkload } from "./archetype-factory";
import { createCapabilities } from "./capabilities";
import { DeploymentManifest } from "./manifest";

export interface ArchetypeStackProps extends StackProps {
  readonly manifest: DeploymentManifest;
}

function outputId(value: string): string {
  const normalized = value.replace(/[^A-Za-z0-9]/g, "");
  return normalized.length > 0 ? normalized.charAt(0).toUpperCase() + normalized.slice(1) : "Output";
}

function createVpc(scope: Construct, manifest: DeploymentManifest): ec2.IVpc | undefined {
  if (!manifest.network.enabled) {
    return undefined;
  }
  return new ec2.Vpc(scope, "Vpc", {
    maxAzs: manifest.network.maxAzs,
    natGateways: manifest.network.natGateways,
    restrictDefaultSecurityGroup: true,
    subnetConfiguration: [
      {
        name: "public",
        subnetType: ec2.SubnetType.PUBLIC,
        cidrMask: 24,
      },
      {
        name: "application",
        subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS,
        cidrMask: 24,
      },
      {
        name: "data",
        subnetType: ec2.SubnetType.PRIVATE_ISOLATED,
        cidrMask: 24,
      },
    ],
  });
}

export class ArchetypeStack extends Stack {
  constructor(scope: Construct, id: string, props: ArchetypeStackProps) {
    super(scope, id, {
      ...props,
      description: `Manifest-driven ${props.manifest.archetype} deployment (${props.manifest.manifestId})`,
    });

    const { manifest } = props;
    const vpc = createVpc(this, manifest);
    const encryptionKey = manifest.secrets.customerManagedKey
      ? new kms.Key(this, "ApplicationKey", {
        enableKeyRotation: true,
        description: `Customer-managed key for ${manifest.manifestId}`,
      })
      : undefined;

    const workload = createWorkload(this, {
      manifest,
      vpc,
      encryptionKey,
    });
    const capabilities = createCapabilities(this, {
      manifest,
      workload,
      vpc,
      encryptionKey,
    });
    workload.finalize?.();

    const outputs = {
      ...workload.outputs,
      ...capabilities.outputs,
      manifestId: manifest.manifestId,
      architectureDecisionId: manifest.architectureDecisionId,
      modelApiDecisionId: manifest.modelApiDecisionId,
      deploymentArchetype: manifest.archetype,
    };
    for (const [name, value] of Object.entries(outputs)) {
      new CfnOutput(this, outputId(name), { value });
    }

    Tags.of(this).add("MigrationId", manifest.manifestId);
    Tags.of(this).add("ManifestId", manifest.manifestId);
    Tags.of(this).add("Archetype", manifest.archetype);
    Tags.of(this).add("ContractOnly", String(manifest.contractOnly));
    for (const [key, value] of Object.entries(manifest.tags)) {
      Tags.of(this).add(key, value);
    }
  }
}
