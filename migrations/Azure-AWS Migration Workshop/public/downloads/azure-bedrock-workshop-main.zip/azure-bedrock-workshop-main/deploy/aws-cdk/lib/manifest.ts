import * as fs from "node:fs";
import * as path from "node:path";
import Ajv2020 from "ajv/dist/2020";

export const ARCHETYPES = [
  "static-web",
  "serverless-http",
  "public-web-container",
  "private-container-service",
  "event-worker",
  "kubernetes",
] as const;

export const DATA_SERVICES = [
  "aurora-postgresql",
  "rds-postgresql",
  "dynamodb",
  "documentdb",
  "s3",
  "elasticache-redis",
] as const;

export type Archetype = (typeof ARCHETYPES)[number];
export type DataService = (typeof DATA_SERVICES)[number];
export type QueueMode = "producer" | "consumer";

export interface ComputeManifest {
  readonly assetPath?: string;
  readonly handler: string;
  readonly lambdaRuntime: string;
  readonly lambdaPackaging: "zip" | "container";
  readonly port: number;
  readonly cpu: number;
  readonly memoryMiB: number;
  readonly desiredCount: number;
  readonly kubernetesVersion: string;
  readonly kubernetesNodeInstanceTypes: readonly string[];
  readonly kubernetesMinNodes: number;
  readonly kubernetesMaxNodes: number;
}

export interface NetworkManifest {
  readonly enabled: boolean;
  readonly maxAzs: number;
  readonly natGateways: number;
  readonly kubernetesPublicEndpoint: boolean;
}

export interface DataResourceManifest {
  readonly name: string;
  readonly service: DataService;
  readonly retain: boolean;
  readonly engineVersion?: string;
  readonly instanceType?: string;
  readonly databaseName?: string;
}

export interface QueueIntegrationManifest {
  readonly name: string;
  readonly mode: QueueMode;
}

export interface NamedIntegrationManifest {
  readonly name: string;
}

export interface IntegrationManifest {
  readonly queues: readonly QueueIntegrationManifest[];
  readonly topics: readonly NamedIntegrationManifest[];
  readonly eventBuses: readonly NamedIntegrationManifest[];
}

export interface GeneratedSecretManifest {
  readonly name: string;
  readonly environmentName: string;
  readonly retain: boolean;
}

export interface SecretsManifest {
  readonly customerManagedKey: boolean;
  readonly generated: readonly GeneratedSecretManifest[];
}

export interface AgentCoreManifest {
  readonly enabled: boolean;
  readonly assetPath?: string;
  readonly modelId?: string;
  readonly inferenceUrl?: string;
  readonly tracing: boolean;
  readonly evidence: readonly string[];
  readonly approved: boolean;
}

export interface SecurityManifest {
  readonly waf: boolean;
}

export interface ObservabilityManifest {
  readonly logs: boolean;
  readonly tracing: boolean;
  readonly alarms: boolean;
  readonly dashboard: boolean;
  readonly logRetentionDays: number;
}

export interface HealthCheckManifest {
  readonly protocol: "HTTP" | "HTTPS" | "TCP";
  readonly path: string;
}

export interface PublicInterfaceManifest {
  readonly name: string;
  readonly type: string;
  readonly location: string;
}

export interface DeploymentManifest {
  readonly contractVersion: "1.0";
  readonly manifestId: string;
  readonly status: "draft" | "ready" | "deployed" | "blocked" | "retired";
  readonly architectureDecisionId: string;
  readonly modelApiDecisionId: string;
  readonly name: string;
  readonly stackName: string;
  readonly archetype: Archetype;
  readonly contractOnly: boolean;
  readonly region: string;
  readonly manifestDirectory: string;
  readonly compute: ComputeManifest;
  readonly network: NetworkManifest;
  readonly dataResources: readonly DataResourceManifest[];
  readonly integrations: IntegrationManifest;
  readonly secrets: SecretsManifest;
  readonly agentCore: AgentCoreManifest;
  readonly security: SecurityManifest;
  readonly observability: ObservabilityManifest;
  readonly healthChecks: readonly HealthCheckManifest[];
  readonly publicInterfaces: readonly PublicInterfaceManifest[];
  readonly teardownInventory: readonly string[];
  readonly tags: Readonly<Record<string, string>>;
}

type JsonObject = Record<string, unknown>;

const VPC_ARCHETYPES = new Set<Archetype>(["private-container-service", "kubernetes"]);
const LAMBDA_ARCHETYPES = new Set<Archetype>(["serverless-http", "event-worker"]);
const ASSET_ARCHETYPES = new Set<Archetype>([
  "serverless-http",
  "public-web-container",
  "private-container-service",
  "event-worker",
]);
const WAF_ARCHETYPES = new Set<Archetype>([
  "serverless-http",
  "public-web-container",
  "private-container-service",
]);
const AGENTCORE_CLIENT_ARCHETYPES = new Set<Archetype>([
  "serverless-http",
  "public-web-container",
  "private-container-service",
  "event-worker",
]);
const NETWORK_DATA_SERVICES = new Set<DataService>([
  "aurora-postgresql",
  "rds-postgresql",
  "documentdb",
  "elasticache-redis",
]);
const SUPPORTED_RETENTION_DAYS = new Set([
  1, 3, 5, 7, 14, 30, 60, 90, 120, 150, 180, 365, 400, 545, 731, 1096, 1827,
  2192, 2557, 2922, 3288, 3653,
]);

function object(value: unknown, field: string): JsonObject {
  if (value === undefined || value === null || typeof value !== "object" || Array.isArray(value)) {
    throw new Error(`Manifest field '${field}' must be an object.`);
  }
  return value as JsonObject;
}

function objectArray(value: unknown, field: string): JsonObject[] {
  if (!Array.isArray(value)) {
    throw new Error(`Manifest field '${field}' must be an array.`);
  }
  return value.map((entry, index) => object(entry, `${field}[${index}]`));
}

function stringValue(value: unknown, field: string): string {
  if (typeof value !== "string" || value.trim() === "") {
    throw new Error(`Manifest field '${field}' must be a non-empty string.`);
  }
  return value;
}

function optionalString(value: unknown, field: string): string | undefined {
  return value === undefined ? undefined : stringValue(value, field);
}

function booleanValue(value: unknown, fallback: boolean, field: string): boolean {
  const result = value === undefined ? fallback : value;
  if (typeof result !== "boolean") {
    throw new Error(`Manifest field '${field}' must be a boolean.`);
  }
  return result;
}

function integerValue(value: unknown, fallback: number, field: string, minimum: number): number {
  const result = value === undefined ? fallback : value;
  if (typeof result !== "number" || !Number.isInteger(result) || result < minimum) {
    throw new Error(`Manifest field '${field}' must be an integer >= ${minimum}.`);
  }
  return result;
}

function stringArray(value: unknown, field: string): readonly string[] {
  if (!Array.isArray(value) || value.some((entry) => typeof entry !== "string" || entry === "")) {
    throw new Error(`Manifest field '${field}' must be an array of non-empty strings.`);
  }
  return value;
}

function enumValue<T extends string>(value: unknown, allowed: readonly T[], field: string): T {
  if (typeof value !== "string" || !allowed.includes(value as T)) {
    throw new Error(`Manifest field '${field}' must be one of: ${allowed.join(", ")}.`);
  }
  return value as T;
}

function identifier(value: unknown, field: string): string {
  const result = stringValue(value, field);
  if (!/^[a-z0-9][a-z0-9._-]*$/.test(result)) {
    throw new Error(`Manifest field '${field}' is not a public-schema identifier.`);
  }
  return result;
}

function cdkName(value: string): string {
  const normalized = value.toLowerCase().replace(/[^a-z0-9-]+/g, "-").replace(/^-+|-+$/g, "");
  if (!/^[a-z][a-z0-9-]{2,47}$/.test(normalized)) {
    throw new Error(`Manifest id '${value}' cannot be normalized to a safe CDK name.`);
  }
  return normalized;
}

function option(source: string, name: string): string | undefined {
  const match = source.match(new RegExp(`(?:^|[;,\\s])${name}=([^;,\\s]+)`, "i"));
  return match?.[1];
}

function optionInteger(source: string, name: string, fallback: number, minimum: number): number {
  const candidate = option(source, name);
  return candidate === undefined
    ? fallback
    : integerValue(Number(candidate), fallback, name, minimum);
}

function mapArchetype(service: string): Archetype {
  const normalized = service.toLowerCase().replace(/[\s_/]+/g, "-");
  const aliases: Readonly<Record<string, Archetype>> = {
    "static-web": "static-web",
    "s3-cloudfront": "static-web",
    "amazon-s3-amazon-cloudfront": "static-web",
    "serverless-http": "serverless-http",
    "lambda-api-gateway": "serverless-http",
    "aws-lambda-amazon-api-gateway": "serverless-http",
    "public-web-container": "public-web-container",
    "app-runner": "public-web-container",
    "aws-app-runner": "public-web-container",
    "private-container-service": "private-container-service",
    "ecs-fargate": "private-container-service",
    "amazon-ecs-on-aws-fargate": "private-container-service",
    "event-worker": "event-worker",
    "lambda-event-worker": "event-worker",
    "kubernetes": "kubernetes",
    "eks": "kubernetes",
    "amazon-eks": "kubernetes",
  };
  const archetype = aliases[normalized];
  if (!archetype) {
    throw new Error(`compute[0].service '${service}' does not select a supported archetype.`);
  }
  return archetype;
}

function mapDataService(service: string): { service: DataService; version?: string } {
  const normalized = service.toLowerCase();
  if (normalized.includes("aurora") && normalized.includes("postgres")) {
    return { service: "aurora-postgresql", version: normalized.match(/\b\d+\.\d+\b/)?.[0] };
  }
  if ((normalized.includes("rds") || normalized.includes("postgres")) && normalized.includes("postgres")) {
    return { service: "rds-postgresql", version: normalized.match(/\b\d+\.\d+\b/)?.[0] };
  }
  if (normalized.includes("dynamodb")) {
    return { service: "dynamodb" };
  }
  if (normalized.includes("documentdb")) {
    return { service: "documentdb", version: normalized.match(/\b\d+\.\d+(?:\.\d+)?\b/)?.[0] };
  }
  if (normalized === "s3" || normalized.includes("amazon s3")) {
    return { service: "s3" };
  }
  if (normalized.includes("elasticache") || normalized.includes("redis")) {
    return { service: "elasticache-redis", version: normalized.match(/\b\d+\.\d+(?:\.\d+)?\b/)?.[0] };
  }
  throw new Error(`Unsupported data[].service '${service}'.`);
}

function normalizeData(raw: JsonObject[], contractOnly: boolean): DataResourceManifest[] {
  return raw.map((entry, index) => {
    const mapped = mapDataService(stringValue(entry.service, `data[${index}].service`));
    const migrationStrategy = stringValue(entry.migration_strategy, `data[${index}].migration_strategy`);
    const backupStrategy = stringValue(entry.backup_strategy, `data[${index}].backup_strategy`);
    return {
      name: cdkName(identifier(entry.id, `data[${index}].id`)),
      service: mapped.service,
      retain: !contractOnly && !/delete|none|ephemeral/i.test(backupStrategy),
      engineVersion: mapped.version,
      instanceType: option(migrationStrategy, "instance_type"),
      databaseName: option(migrationStrategy, "database_name"),
    };
  });
}

function normalizeIntegrations(raw: JsonObject[]): IntegrationManifest {
  const queues: QueueIntegrationManifest[] = [];
  const topics: NamedIntegrationManifest[] = [];
  const eventBuses: NamedIntegrationManifest[] = [];
  for (const [index, entry] of raw.entries()) {
    const type = stringValue(entry.type, `integration[${index}].type`);
    const protocol = stringValue(entry.protocol, `integration[${index}].protocol`).toLowerCase();
    if (type === "model-api" || type === "database" || type === "http") {
      continue;
    }
    const name = cdkName(identifier(entry.id, `integration[${index}].id`));
    if (type === "queue" || protocol.includes("sqs")) {
      const source = stringValue(entry.source, `integration[${index}].source`).toLowerCase();
      queues.push({ name, mode: source.includes("sqs") || source.includes("queue") ? "consumer" : "producer" });
    } else if (protocol.includes("sns")) {
      topics.push({ name });
    } else if (type === "event" || type === "schedule" || protocol.includes("eventbridge")) {
      eventBuses.push({ name });
    } else {
      throw new Error(`integration[${index}] is not an implemented SQS, SNS, or EventBridge integration.`);
    }
  }
  return { queues, topics, eventBuses };
}

function findContainer(containers: JsonObject[], pattern: RegExp): JsonObject | undefined {
  return containers.find((entry) => pattern.test(String(entry.name ?? "")));
}

function interfaceValue(interfaces: readonly string[], key: string): string | undefined {
  const prefix = `${key}=`;
  return interfaces.find((entry) => entry.startsWith(prefix))?.slice(prefix.length);
}

function teardownRetains(teardown: JsonObject[], resourceName: string): boolean {
  const entry = teardown.find((candidate) =>
    String(candidate.resource_type ?? "").toLowerCase().includes(resourceName.toLowerCase()));
  return entry?.retention === "retain" || entry?.retention === "snapshot";
}

function normalize(raw: JsonObject, manifestPath: string, forceContractOnly: boolean): DeploymentManifest {
  enumValue(raw.schema_version, ["1.0"] as const, "schema_version");
  enumValue(raw.kind, ["deployment-manifest"] as const, "kind");
  enumValue(raw.target_cloud, ["aws"] as const, "target_cloud");

  const manifestId = identifier(raw.id, "id");
  const name = cdkName(manifestId);
  const status = enumValue(
    raw.status,
    ["draft", "ready", "deployed", "blocked", "retired"] as const,
    "status",
  );
  const environments = objectArray(raw.environments, "environments");
  if (environments.length !== 1) {
    throw new Error("The CDK factory requires exactly one environments[] entry per synth.");
  }
  const regions = stringArray(environments[0]!.regions, "environments[0].regions");
  if (regions.length !== 1) {
    throw new Error("The CDK factory requires exactly one environments[0].regions entry per synth.");
  }
  const region = regions[0]!;

  const computeResources = objectArray(raw.compute, "compute");
  if (computeResources.length !== 1) {
    throw new Error("The archetype factory requires exactly one primary compute[] entry.");
  }
  const primaryCompute = computeResources[0]!;
  const archetype = mapArchetype(stringValue(primaryCompute.service, "compute[0].service"));
  const runtime = stringValue(primaryCompute.runtime, "compute[0].runtime");
  const scaling = stringValue(primaryCompute.scaling, "compute[0].scaling");
  const sourcePaths = stringArray(primaryCompute.source_paths, "compute[0].source_paths");
  const containers = objectArray(raw.containers, "containers");
  const applicationContainer = findContainer(containers, /^(application|app|web|worker)$/i) ?? containers[0];
  const lambdaPackaging = (option(runtime, "packaging") ?? (applicationContainer ? "container" : "zip")).toLowerCase();
  if (lambdaPackaging !== "zip" && lambdaPackaging !== "container") {
    throw new Error("compute[0].runtime packaging must be 'zip' or 'container'.");
  }

  const approvals = objectArray(raw.approvals, "approvals");
  const teardown = objectArray(raw.teardown_inventory, "teardown_inventory");
  const contractOnly = forceContractOnly;
  const dataEntries = objectArray(raw.data, "data");
  const dataResources = normalizeData(dataEntries, contractOnly);

  const network = object(raw.network, "network");
  const vpcDescription = stringValue(network.vpc, "network.vpc");
  const egress = stringArray(network.egress, "network.egress");
  const ingress = stringArray(network.ingress, "network.ingress");
  const privateConnectivity = stringArray(network.private_connectivity, "network.private_connectivity");
  const networkRequired = VPC_ARCHETYPES.has(archetype) || dataResources.some((data) => NETWORK_DATA_SERVICES.has(data.service));
  const networkEnabled = !/^(none|not-required|no-vpc)$/i.test(vpcDescription) || networkRequired;

  const secretEntries = objectArray(raw.secrets, "secrets");
  const customerManagedKey = dataEntries.some((entry) =>
    /customer-managed|cmk/i.test(stringValue(entry.encryption, "data[].encryption"))) ||
    secretEntries.some((entry) => /kms|encryption-key/i.test(String(entry.name ?? "")) && entry.source === "generated");
  const generatedSecrets: GeneratedSecretManifest[] = secretEntries
    .filter((entry) => entry.source === "generated" && !/kms|encryption-key/i.test(String(entry.name ?? "")))
    .map((entry, index) => {
      const secretName = cdkName(String(entry.name).toLowerCase().replace(/[^a-z0-9-]+/g, "-"));
      return {
        name: secretName,
        environmentName: secretName.toUpperCase().replace(/-/g, "_"),
        retain: !contractOnly && teardownRetains(teardown, String(entry.name ?? `secret-${index + 1}`)),
      };
    });

  const observability = object(raw.observability, "observability");
  const logs = stringArray(observability.logs, "observability.logs");
  const metrics = stringArray(observability.metrics, "observability.metrics");
  const traces = stringArray(observability.traces, "observability.traces");
  const alarms = stringArray(observability.alarms, "observability.alarms");
  const retentionEntry = logs.find((entry) => /retention_days=/i.test(entry));

  const healthChecks = objectArray(raw.health_checks, "health_checks");
  const publicInterfaces = objectArray(raw.public_interfaces, "public_interfaces");
  const agentCore = object(raw.agentcore, "agentcore");
  const agentCoreEnabled = booleanValue(agentCore.enabled, false, "agentcore.enabled");
  const agentCoreInterfaces = stringArray(agentCore.interfaces, "agentcore.interfaces");
  const agentCoreContainer = findContainer(containers, /agentcore/i);
  const agentCoreApproval = approvals.find((entry) =>
    /agentcore/i.test(String(entry.scope ?? "")) && entry.status === "approved");
  const architectureApproval = approvals.find((entry) => /architecture|migration/i.test(String(entry.scope ?? "")));
  const modelApproval = approvals.find((entry) => /model|api/i.test(String(entry.scope ?? "")));

  const manifest: DeploymentManifest = {
    contractVersion: "1.0",
    manifestId,
    status,
    architectureDecisionId: architectureApproval ? identifier(architectureApproval.id, "approvals[].id") : "not-recorded",
    modelApiDecisionId: modelApproval ? identifier(modelApproval.id, "approvals[].id") : "not-recorded",
    name,
    stackName: `${name}-stack`,
    archetype,
    contractOnly,
    region,
    manifestDirectory: path.dirname(manifestPath),
    compute: {
      assetPath: archetype === "static-web"
        ? sourcePaths[0]
        : applicationContainer
          ? stringValue(applicationContainer.source_path, "containers[].source_path")
          : sourcePaths[0],
      handler: option(runtime, "handler") ?? (contractOnly ? "index.handler" : ""),
      lambdaRuntime: option(runtime, "runtime") ?? runtime.split(/[;,]/, 1)[0]!.trim(),
      lambdaPackaging,
      port: optionInteger(runtime, "port", 8080, 1),
      cpu: optionInteger(scaling, "cpu", 512, 256),
      memoryMiB: optionInteger(scaling, "memory_mib", 1024, 512),
      desiredCount: optionInteger(scaling, "desired_count", 1, 1),
      kubernetesVersion: option(runtime, "kubernetes_version") ?? "1.32",
      kubernetesNodeInstanceTypes: (option(scaling, "node_instance_types") ?? "t3.medium").split("|") ,
      kubernetesMinNodes: optionInteger(scaling, "min_nodes", 1, 1),
      kubernetesMaxNodes: optionInteger(scaling, "max_nodes", 2, 1),
    },
    network: {
      enabled: networkEnabled,
      maxAzs: optionInteger(vpcDescription, "max_azs", 2, 2),
      natGateways: optionInteger(egress.join(";"), "nat_gateways", networkEnabled ? 1 : 0, 0),
      kubernetesPublicEndpoint: privateConnectivity.some((entry) => /kubernetes_public_endpoint=true/i.test(entry)),
    },
    dataResources,
    integrations: normalizeIntegrations(objectArray(raw.integration, "integration")),
    secrets: {
      customerManagedKey,
      generated: generatedSecrets,
    },
    agentCore: {
      enabled: agentCoreEnabled,
      assetPath: agentCoreContainer
        ? stringValue(agentCoreContainer.source_path, "containers[agentcore].source_path")
        : undefined,
      modelId: interfaceValue(agentCoreInterfaces, "model_id"),
      inferenceUrl: interfaceValue(agentCoreInterfaces, "inference_url"),
      tracing: traces.some((entry) => /agentcore/i.test(entry)),
      evidence: [stringValue(agentCore.reason, "agentcore.reason")],
      approved: agentCoreApproval !== undefined && agentCore.status === "approved",
    },
    security: {
      waf: ingress.some((entry) => /\bwaf\b/i.test(entry)),
    },
    observability: {
      logs: logs.length > 0,
      tracing: traces.length > 0,
      alarms: alarms.length > 0,
      dashboard: metrics.some((entry) => /dashboard/i.test(entry)),
      logRetentionDays: optionInteger(retentionEntry ?? "", "retention_days", 7, 1),
    },
    healthChecks: healthChecks.map((entry, index) => {
      const protocol = stringValue(entry.protocol, `health_checks[${index}].protocol`).toLowerCase();
      return {
        protocol: protocol === "tcp" ? "TCP" : "HTTP",
        path: stringValue(entry.path_or_command, `health_checks[${index}].path_or_command`),
      };
    }),
    publicInterfaces: publicInterfaces.map((entry, index) => ({
      name: stringValue(entry.name, `public_interfaces[${index}].name`),
      type: stringValue(entry.type, `public_interfaces[${index}].type`),
      location: stringValue(entry.location, `public_interfaces[${index}].location`),
    })),
    teardownInventory: teardown.map((entry, index) =>
      stringValue(entry.resource_type, `teardown_inventory[${index}].resource_type`)),
    tags: {
      Workshop: "azure-bedrock-migration",
      ManifestStatus: status,
    },
  };

  validateCombinations(manifest);
  return manifest;
}

function validateCombinations(manifest: DeploymentManifest): void {
  if (manifest.status === "blocked" || manifest.status === "retired") {
    throw new Error(`A manifest with status '${manifest.status}' cannot be synthesized.`);
  }
  if (VPC_ARCHETYPES.has(manifest.archetype) && !manifest.network.enabled) {
    throw new Error(`${manifest.archetype} requires a VPC in network.vpc.`);
  }
  if (manifest.network.enabled && manifest.network.natGateways < 1) {
    throw new Error("This archetype factory requires nat_gateways>=1 for VPC workload image and AWS API egress.");
  }
  for (const data of manifest.dataResources) {
    if (NETWORK_DATA_SERVICES.has(data.service) && !manifest.network.enabled) {
      throw new Error(`${data.service} requires a VPC in network.vpc.`);
    }
    if (NETWORK_DATA_SERVICES.has(data.service) && ["static-web", "kubernetes"].includes(manifest.archetype)) {
      throw new Error(`${data.service} is not implemented for ${manifest.archetype}.`);
    }
    if (data.service === "rds-postgresql" && data.engineVersion !== "17.9") {
      throw new Error("RDS PostgreSQL requires service text containing the approved version 17.9.");
    }
    if (data.service === "aurora-postgresql" && !data.engineVersion) {
      throw new Error("Aurora PostgreSQL requires an explicit engine version in data[].service.");
    }
  }
  if (manifest.security.waf && !WAF_ARCHETYPES.has(manifest.archetype)) {
    throw new Error(`WAF association is not supported by ${manifest.archetype}.`);
  }
  if (manifest.agentCore.enabled && !AGENTCORE_CLIENT_ARCHETYPES.has(manifest.archetype)) {
    throw new Error(`AgentCore invocation is not supported by ${manifest.archetype}.`);
  }
  if (!manifest.contractOnly && (ASSET_ARCHETYPES.has(manifest.archetype) || manifest.archetype === "static-web" || manifest.archetype === "kubernetes") && !manifest.compute.assetPath) {
    throw new Error(`${manifest.archetype} requires a selected source_paths or containers[].source_path outside contract-only mode.`);
  }
  if (
    !manifest.contractOnly &&
    LAMBDA_ARCHETYPES.has(manifest.archetype) &&
    manifest.compute.lambdaPackaging === "zip" &&
    !manifest.compute.handler
  ) {
    throw new Error(`${manifest.archetype} zip packaging requires handler= in compute[].runtime.`);
  }
  if (LAMBDA_ARCHETYPES.has(manifest.archetype)) {
    const supportedRuntimes = new Set([
      "nodejs20.x",
      "nodejs22.x",
      "python3.12",
      "python3.13",
      "java21",
      "dotnet8",
      "provided.al2023",
    ]);
    if (manifest.compute.lambdaPackaging === "zip" && !supportedRuntimes.has(manifest.compute.lambdaRuntime)) {
      throw new Error(`Unsupported Lambda runtime '${manifest.compute.lambdaRuntime}'.`);
    }
  }
  if (manifest.agentCore.enabled) {
    if (!manifest.agentCore.approved) {
      throw new Error("Enabled AgentCore requires agentcore.status=approved and an approved AgentCore approval entry.");
    }
    if (!manifest.contractOnly && !manifest.agentCore.assetPath) {
      throw new Error("Enabled AgentCore requires an AgentCore containers[].source_path outside contract-only mode.");
    }
    if (!manifest.agentCore.modelId || !manifest.agentCore.inferenceUrl) {
      throw new Error("Enabled AgentCore requires model_id= and inference_url= entries in agentcore.interfaces.");
    }
    if (!["openai.gpt-5.4", "openai.gpt-5.5"].includes(manifest.agentCore.modelId)) {
      throw new Error("AgentCore model_id must be an approved openai.gpt-5.4 or openai.gpt-5.5 tuple.");
    }
    const expectedUrl = `https://bedrock-mantle.${manifest.region}.api.aws/openai/v1/responses`;
    if (manifest.agentCore.inferenceUrl !== expectedUrl) {
      throw new Error(`AgentCore inference_url must be the authoritative regional Responses URL: ${expectedUrl}`);
    }
  }
  if (LAMBDA_ARCHETYPES.has(manifest.archetype) && manifest.compute.memoryMiB > 10240) {
    throw new Error("Lambda memory_mib cannot exceed 10240.");
  }
  if (manifest.compute.kubernetesMinNodes > manifest.compute.kubernetesMaxNodes) {
    throw new Error("compute scaling min_nodes cannot exceed max_nodes.");
  }
  if (manifest.archetype === "kubernetes" && manifest.compute.kubernetesVersion !== "1.32") {
    throw new Error("The pinned kubectl layer currently supports kubernetes_version=1.32.");
  }
  if (!SUPPORTED_RETENTION_DAYS.has(manifest.observability.logRetentionDays)) {
    throw new Error("CloudWatch retention_days must be a supported Logs retention value.");
  }
  if (manifest.archetype === "public-web-container") {
    const allowedCpu = new Set([256, 512, 1024, 2048, 4096]);
    const allowedMemory = new Set([512, 1024, 2048, 3072, 4096, 6144, 8192, 10240, 12288]);
    if (!allowedCpu.has(manifest.compute.cpu) || !allowedMemory.has(manifest.compute.memoryMiB)) {
      throw new Error("App Runner scaling cpu or memory_mib is outside supported values.");
    }
  }
  if (manifest.teardownInventory.length === 0) {
    throw new Error("teardown_inventory must enumerate the resources selected by the plan.");
  }
  validateTeardownInventory(manifest);
}

function validateTeardownInventory(manifest: DeploymentManifest): void {
  const inventory = manifest.teardownInventory.join(" ").toLowerCase();
  const required: string[][] = [];
  const byArchetype: Readonly<Record<Archetype, string[][]>> = {
    "static-web": [["cloudfront"], ["s3"]],
    "serverless-http": [["lambda"], ["api gateway", "apigateway"]],
    "public-web-container": [["app runner", "apprunner"]],
    "private-container-service": [["ecs"], ["load balancer", "alb"]],
    "event-worker": [["lambda"], ["sqs"]],
    kubernetes: [["eks", "kubernetes"]],
  };
  required.push(...byArchetype[manifest.archetype]);
  const byData: Readonly<Record<DataService, string[]>> = {
    "aurora-postgresql": ["aurora"],
    "rds-postgresql": ["rds", "postgresql"],
    dynamodb: ["dynamodb"],
    documentdb: ["documentdb"],
    s3: ["s3"],
    "elasticache-redis": ["elasticache", "redis"],
  };
  for (const data of manifest.dataResources) {
    required.push(byData[data.service]);
  }
  if (manifest.integrations.queues.length > 0) required.push(["sqs"]);
  if (manifest.integrations.topics.length > 0) required.push(["sns"]);
  if (manifest.integrations.eventBuses.length > 0) required.push(["eventbridge"]);
  if (manifest.agentCore.enabled) required.push(["agentcore"]);
  if (manifest.secrets.customerManagedKey) required.push(["kms"]);
  if (manifest.secrets.generated.length > 0) required.push(["secret"]);

  for (const alternatives of required) {
    if (!alternatives.some((candidate) => inventory.includes(candidate))) {
      throw new Error(`teardown_inventory is missing selected resource type '${alternatives.join(" or ")}'.`);
    }
  }
}

export function resolveManifestPath(manifest: DeploymentManifest, candidate: string): string {
  return path.resolve(manifest.manifestDirectory, candidate);
}

export function loadManifest(manifestPath: string, forceContractOnly = false): DeploymentManifest {
  let parsed: unknown;
  try {
    parsed = JSON.parse(fs.readFileSync(manifestPath, "utf8"));
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    throw new Error(`Unable to read manifest '${manifestPath}': ${message}`);
  }
  const schemaPath = path.resolve(__dirname, "../../../schemas/deployment-manifest.schema.json");
  const schema = JSON.parse(fs.readFileSync(schemaPath, "utf8")) as JsonObject;
  const validator = new Ajv2020({ allErrors: true, strict: true }).compile(schema);
  if (!validator(parsed)) {
    const details = validator.errors?.map((error) => `${error.instancePath || "/"} ${error.message}`).join("; ");
    throw new Error(`Manifest '${manifestPath}' does not match the public deployment schema: ${details}`);
  }
  return normalize(object(parsed, "root"), manifestPath, forceContractOnly);
}
