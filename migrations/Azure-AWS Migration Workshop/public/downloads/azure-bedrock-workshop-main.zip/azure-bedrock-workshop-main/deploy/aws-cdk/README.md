# Manifest-driven AWS CDK archetypes

This package reads the public `schemas/deployment-manifest.schema.json` contract and synthesizes one AWS stack. It does not deploy resources. The default context is contract-only and never reads target application paths.

## Supported compute selections

Set `compute[0].service` to one of these canonical archetypes (documented AWS aliases are accepted by the parser):

| Archetype | Primary constructs |
|---|---|
| `static-web` | S3, CloudFront, origin access control |
| `serverless-http` | Lambda, API Gateway |
| `public-web-container` | App Runner, ECR reference or Docker asset |
| `private-container-service` | ECS on Fargate, internal ALB |
| `event-worker` | Lambda, SQS, DLQ |
| `kubernetes` | EKS, managed node group, generated Deployment and Service |

The public schema intentionally keeps `runtime` and `scaling` descriptive. The factory recognizes semicolon-separated operational selections within those strings:

```text
runtime: nodejs22.x;runtime=nodejs22.x;packaging=zip;handler=index.handler;port=8080
scaling: cpu=512;memory_mib=1024;desired_count=1;min_nodes=1;max_nodes=2
```

Lambda zip runtimes are `nodejs20.x`, `nodejs22.x`, `python3.12`, `python3.13`, `java21`, `dotnet8`, and `provided.al2023` (for Go/custom runtimes). `packaging=container` uses the application entry in `containers[]` instead. Non-contract static sites copy `compute[0].source_paths[0]` into the origin bucket. Non-contract EKS builds the selected application container and deploys generated Kubernetes resources that reference its immutable CDK asset URI.

## Conditional modules

- `data[]`: Aurora PostgreSQL, RDS PostgreSQL 17.9, DynamoDB, DocumentDB, S3, and ElastiCache for Redis.
- `integration[]`: SQS, SNS, and EventBridge selected from `type` and `protocol`.
- `secrets[]`: generated Secrets Manager values; a generated KMS-named entry or customer-managed data encryption selects a rotating KMS key.
- `network`: VPC, NAT, private workload subnets, and isolated data subnets only when selected or required.
- `observability`: CloudWatch logs, metrics, dashboards, alarms, and X-Ray only when listed.
- `network.ingress`: an entry containing `WAF` enables a regional web ACL for supported HTTP archetypes.

AgentCore is absent unless `agentcore.enabled` is true. The enabled branch must also have `agentcore.status=approved`, a matching approved entry in `approvals[]`, an AgentCore container for non-contract mode, and these exact values in `agentcore.interfaces[]`:

```text
model_id=openai.gpt-5.4
inference_url=https://bedrock-mantle.us-west-2.api.aws/openai/v1/responses
```

The model and full inference URL have no defaults. The URL is injected exactly as recorded; the factory does not append `/responses` to a base URL.

## Validation

```bash
npm ci --ignore-scripts
npm run build
npm run validate:contracts
npm run synth
```

`validate:contracts` validates every `manifests/contract-*.json` against the worker-owned public schema and synthesizes each into `cdk.out/contracts/`. Contract fixtures may name nonexistent target paths because contract mode uses placeholder S3/ECR references, pinned public container references, and generated Kubernetes resources without reading those paths.

To synthesize an approved target package after its artifacts exist:

```bash
npx cdk synth \
  -c manifest=/absolute/path/to/deployment-manifest.json \
  -c contractOnly=false
```

Synthesis is not deployment approval. This package intentionally defines no deploy script. A deployment workflow must stop for the explicit `DEPLOY` gate after read-only preflight; teardown must separately stop for the explicit `DESTROY` gate after presenting the inventory. Neither gate is inferred from the manifest or an earlier approval.

## Sandbox tradeoffs

The generated VPC uses one NAT gateway by default, and contract data examples use single-node or single-instance configurations with deletion-oriented teardown entries. These choices keep workshop topology understandable but are not a production HA baseline. The manifest must explicitly select retention, backups, scaling, private connectivity, and teardown appropriate to the approved plan.
