#!/usr/bin/env node

const fs = require("node:fs");
const path = require("node:path");
const { spawnSync } = require("node:child_process");
const Ajv2020 = require("ajv/dist/2020").default;

const root = path.resolve(__dirname, "..");
const schemaPath = path.resolve(root, "../../schemas/deployment-manifest.schema.json");
const manifestDirectory = path.join(root, "manifests");
const manifests = fs.readdirSync(manifestDirectory)
  .filter((name) => /^contract-.*\.json$/.test(name))
  .sort();

if (manifests.length === 0) {
  throw new Error("No contract manifests were found.");
}

const schema = JSON.parse(fs.readFileSync(schemaPath, "utf8"));
const ajv = new Ajv2020({ allErrors: true, strict: true });
const validate = ajv.compile(schema);
const cdk = path.join(root, "node_modules", "aws-cdk", "bin", "cdk");

for (const name of manifests) {
  const absoluteManifest = path.join(manifestDirectory, name);
  const document = JSON.parse(fs.readFileSync(absoluteManifest, "utf8"));
  if (!validate(document)) {
    const details = ajv.errorsText(validate.errors, { separator: "\n" });
    throw new Error(`${name} does not match deployment-manifest.schema.json:\n${details}`);
  }

  const output = path.join(root, "cdk.out", "contracts", path.basename(name, ".json"));
  fs.rmSync(output, { recursive: true, force: true });
  const result = spawnSync(process.execPath, [
    cdk,
    "synth",
    "--quiet",
    "--output",
    output,
    "-c",
    `manifest=manifests/${name}`,
    "-c",
    "contractOnly=true",
  ], {
    cwd: root,
    encoding: "utf8",
    env: { ...process.env, CDK_DISABLE_VERSION_CHECK: "1" },
  });
  if (result.status !== 0) {
    process.stderr.write(result.stdout ?? "");
    process.stderr.write(result.stderr ?? "");
    throw new Error(`CDK synth failed for ${name}.`);
  }
  process.stdout.write(`validated ${name}\n`);
}
