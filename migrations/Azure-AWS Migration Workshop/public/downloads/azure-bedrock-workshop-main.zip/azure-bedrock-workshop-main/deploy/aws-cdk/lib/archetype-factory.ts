import {
  Duration,
  RemovalPolicy,
} from "aws-cdk-lib";
import { KubectlV32Layer } from "@aws-cdk/lambda-layer-kubectl-v32";
import * as apigateway from "aws-cdk-lib/aws-apigateway";
import * as apprunner from "aws-cdk-lib/aws-apprunner";
import * as cloudfront from "aws-cdk-lib/aws-cloudfront";
import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
import * as ec2 from "aws-cdk-lib/aws-ec2";
import * as ecr from "aws-cdk-lib/aws-ecr";
import * as ecrAssets from "aws-cdk-lib/aws-ecr-assets";
import * as ecs from "aws-cdk-lib/aws-ecs";
import * as ecsPatterns from "aws-cdk-lib/aws-ecs-patterns";
import * as eks from "aws-cdk-lib/aws-eks";
import * as iam from "aws-cdk-lib/aws-iam";
import * as kms from "aws-cdk-lib/aws-kms";
import * as lambda from "aws-cdk-lib/aws-lambda";
import * as lambdaEventSources from "aws-cdk-lib/aws-lambda-event-sources";
import * as logs from "aws-cdk-lib/aws-logs";
import * as s3 from "aws-cdk-lib/aws-s3";
import * as s3deploy from "aws-cdk-lib/aws-s3-deployment";
import * as origins from "aws-cdk-lib/aws-cloudfront-origins";
import * as sqs from "aws-cdk-lib/aws-sqs";
import * as secretsmanager from "aws-cdk-lib/aws-secretsmanager";
import { Construct } from "constructs";
import { DeploymentManifest, resolveManifestPath } from "./manifest";

export interface AlarmMetric {
  readonly id: string;
  readonly label: string;
  readonly metric: cloudwatch.IMetric;
  readonly threshold: number;
}

export interface WorkloadBindings {
  readonly grantPrincipal?: iam.IGrantable;
  readonly vpc?: ec2.IVpc;
  readonly securityGroups: readonly ec2.ISecurityGroup[];
  readonly outputs: Readonly<Record<string, string>>;
  readonly alarmMetrics: readonly AlarmMetric[];
  readonly wafResourceArn?: string;
  addEnvironment(name: string, value: string): void;
  addSecretEnvironment?(name: string, secret: secretsmanager.ISecret): void;
  finalize?(): void;
}

export interface WorkloadFactoryProps {
  readonly manifest: DeploymentManifest;
  readonly vpc?: ec2.IVpc;
  readonly encryptionKey?: kms.IKey;
}

const CONTRACT_CONTAINER_IMAGE = "public.ecr.aws/docker/library/nginx:1.27.4-alpine";

function removalPolicy(manifest: DeploymentManifest): RemovalPolicy {
  return manifest.contractOnly ? RemovalPolicy.DESTROY : RemovalPolicy.RETAIN;
}

function healthPath(manifest: DeploymentManifest): string {
  return manifest.healthChecks.find((check) => check.protocol !== "TCP")?.path ?? "/healthz";
}

function retention(manifest: DeploymentManifest): logs.RetentionDays {
  return manifest.observability.logRetentionDays as logs.RetentionDays;
}

function lambdaRuntime(name: string): lambda.Runtime {
  const runtimes: Readonly<Record<string, lambda.Runtime>> = {
    "nodejs20.x": lambda.Runtime.NODEJS_20_X,
    "nodejs22.x": lambda.Runtime.NODEJS_22_X,
    "python3.12": lambda.Runtime.PYTHON_3_12,
    "python3.13": lambda.Runtime.PYTHON_3_13,
    java21: lambda.Runtime.JAVA_21,
    dotnet8: lambda.Runtime.DOTNET_8,
    "provided.al2023": lambda.Runtime.PROVIDED_AL2023,
  };
  const runtime = runtimes[name];
  if (!runtime) {
    throw new Error(`Unsupported Lambda runtime '${name}'.`);
  }
  return runtime;
}

function createLambda(
  scope: Construct,
  id: string,
  manifest: DeploymentManifest,
  vpc?: ec2.IVpc,
  securityGroups?: ec2.ISecurityGroup[],
): lambda.Function | lambda.DockerImageFunction {
  const logGroup = manifest.observability.logs
    ? new logs.LogGroup(scope, `${id}LogGroup`, {
      retention: retention(manifest),
      removalPolicy: manifest.contractOnly ? RemovalPolicy.DESTROY : RemovalPolicy.RETAIN,
    })
    : undefined;
  const functionOptions = {
    memorySize: manifest.compute.memoryMiB,
    timeout: Duration.seconds(30),
    vpc,
    vpcSubnets: vpc ? { subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS } : undefined,
    securityGroups: vpc ? securityGroups : undefined,
    tracing: manifest.observability.tracing ? lambda.Tracing.ACTIVE : lambda.Tracing.PASS_THROUGH,
    logGroup,
    environment: {
      DEPLOYMENT_ARCHETYPE: manifest.archetype,
      CONTRACT_ONLY: String(manifest.contractOnly),
    },
  };
  if (manifest.compute.lambdaPackaging === "container") {
    let code: lambda.DockerImageCode;
    if (manifest.contractOnly) {
      const repository = new ecr.Repository(scope, `${id}ContractImageRepository`, {
        imageScanOnPush: true,
        removalPolicy: RemovalPolicy.DESTROY,
        emptyOnDelete: true,
      });
      code = lambda.DockerImageCode.fromEcr(repository, { tagOrDigest: "contract-only" });
    } else {
      code = lambda.DockerImageCode.fromImageAsset(
        resolveManifestPath(manifest, manifest.compute.assetPath!),
        { platform: ecrAssets.Platform.LINUX_AMD64 },
      );
    }
    return new lambda.DockerImageFunction(scope, id, {
      ...functionOptions,
      code,
    });
  }
  const code = manifest.contractOnly
    ? lambda.Code.fromBucket(
      s3.Bucket.fromBucketName(scope, `${id}ContractCodeBucket`, "contract-only-lambda-assets"),
      "contract-only.zip",
      "contract-only",
    )
    : lambda.Code.fromAsset(resolveManifestPath(manifest, manifest.compute.assetPath!));
  return new lambda.Function(scope, id, {
    ...functionOptions,
    runtime: lambdaRuntime(manifest.compute.lambdaRuntime),
    handler: manifest.compute.handler,
    code,
  });
}

function createStaticWeb(
  scope: Construct,
  props: WorkloadFactoryProps,
): WorkloadBindings {
  const { manifest, encryptionKey } = props;
  const bucket = new s3.Bucket(scope, "SiteBucket", {
    blockPublicAccess: s3.BlockPublicAccess.BLOCK_ALL,
    enforceSSL: true,
    encryption: encryptionKey ? s3.BucketEncryption.KMS : s3.BucketEncryption.S3_MANAGED,
    encryptionKey,
    removalPolicy: removalPolicy(manifest),
    autoDeleteObjects: manifest.contractOnly,
  });
  const distribution = new cloudfront.Distribution(scope, "Distribution", {
    defaultRootObject: "index.html",
    minimumProtocolVersion: cloudfront.SecurityPolicyProtocol.TLS_V1_2_2021,
    defaultBehavior: {
      origin: origins.S3BucketOrigin.withOriginAccessControl(bucket),
      viewerProtocolPolicy: cloudfront.ViewerProtocolPolicy.REDIRECT_TO_HTTPS,
      allowedMethods: cloudfront.AllowedMethods.ALLOW_GET_HEAD_OPTIONS,
      cachePolicy: cloudfront.CachePolicy.CACHING_OPTIMIZED,
    },
  });
  if (!manifest.contractOnly) {
    new s3deploy.BucketDeployment(scope, "StaticAssets", {
      sources: [s3deploy.Source.asset(resolveManifestPath(manifest, manifest.compute.assetPath!))],
      destinationBucket: bucket,
      distribution,
      distributionPaths: ["/*"],
      prune: true,
    });
  }

  return {
    securityGroups: [],
    outputs: {
      siteBucketName: bucket.bucketName,
      siteUrl: `https://${distribution.distributionDomainName}`,
    },
    alarmMetrics: [{
      id: "StaticWeb5xx",
      label: "CloudFront 5xx error rate",
      metric: distribution.metric5xxErrorRate(),
      threshold: 5,
    }],
    addEnvironment: () => undefined,
  };
}

function createServerlessHttp(
  scope: Construct,
  props: WorkloadFactoryProps,
): WorkloadBindings {
  const securityGroups: ec2.ISecurityGroup[] = [];
  if (props.vpc) {
    securityGroups.push(new ec2.SecurityGroup(scope, "HandlerSecurityGroup", {
      vpc: props.vpc,
      allowAllOutbound: true,
    }));
  }
  const fn = createLambda(scope, "Handler", props.manifest, props.vpc, securityGroups);
  const api = new apigateway.RestApi(scope, "Api", {
    endpointTypes: [apigateway.EndpointType.REGIONAL],
    deployOptions: {
      metricsEnabled: props.manifest.observability.alarms || props.manifest.observability.dashboard,
      tracingEnabled: props.manifest.observability.tracing,
      loggingLevel: props.manifest.observability.logs
        ? apigateway.MethodLoggingLevel.ERROR
        : apigateway.MethodLoggingLevel.OFF,
      dataTraceEnabled: false,
    },
  });
  const integration = new apigateway.LambdaIntegration(fn, { proxy: true });
  api.root.addMethod("ANY", integration);
  api.root.addProxy({ defaultIntegration: integration, anyMethod: true });

  return {
    grantPrincipal: fn,
    vpc: props.vpc,
    securityGroups,
    wafResourceArn: api.deploymentStage.stageArn,
    outputs: {
      apiUrl: api.url,
      functionName: fn.functionName,
    },
    alarmMetrics: [
      {
        id: "ServerlessErrors",
        label: "Lambda errors",
        metric: fn.metricErrors(),
        threshold: 1,
      },
      {
        id: "ServerlessLatency",
        label: "API Gateway p99 latency",
        metric: api.metricLatency({ statistic: "p99" }),
        threshold: 5000,
      },
    ],
    addEnvironment: (name, value) => fn.addEnvironment(name, value),
  };
}

function createAppRunner(
  scope: Construct,
  props: WorkloadFactoryProps,
): WorkloadBindings {
  const { manifest, vpc } = props;
  const runtimeRole = new iam.Role(scope, "AppRunnerRuntimeRole", {
    assumedBy: new iam.ServicePrincipal("tasks.apprunner.amazonaws.com"),
  });
  const accessRole = new iam.Role(scope, "AppRunnerAccessRole", {
    assumedBy: new iam.ServicePrincipal("build.apprunner.amazonaws.com"),
  });
  const runtimeEnvironmentVariables: apprunner.CfnService.KeyValuePairProperty[] = [
    { name: "PORT", value: String(manifest.compute.port) },
    { name: "DEPLOYMENT_ARCHETYPE", value: manifest.archetype },
    { name: "CONTRACT_ONLY", value: String(manifest.contractOnly) },
  ];
  const runtimeEnvironmentSecrets: apprunner.CfnService.KeyValuePairProperty[] = [];

  let imageIdentifier: string;
  if (manifest.contractOnly) {
    const repository = new ecr.Repository(scope, "ContractImageRepository", {
      imageScanOnPush: true,
      removalPolicy: RemovalPolicy.DESTROY,
      emptyOnDelete: true,
    });
    repository.grantPull(accessRole);
    imageIdentifier = `${repository.repositoryUri}:contract-only`;
  } else {
    const image = new ecrAssets.DockerImageAsset(scope, "ApplicationImage", {
      directory: resolveManifestPath(manifest, manifest.compute.assetPath!),
      platform: ecrAssets.Platform.LINUX_AMD64,
    });
    image.repository.grantPull(accessRole);
    imageIdentifier = image.imageUri;
  }

  let egressConfiguration: apprunner.CfnService.EgressConfigurationProperty = {
    egressType: "DEFAULT",
  };
  const securityGroups: ec2.ISecurityGroup[] = [];
  if (vpc) {
    const connectorSecurityGroup = new ec2.SecurityGroup(scope, "AppRunnerConnectorSecurityGroup", {
      vpc,
      allowAllOutbound: true,
      description: "Egress from App Runner into the workload VPC",
    });
    securityGroups.push(connectorSecurityGroup);
    const connector = new apprunner.CfnVpcConnector(scope, "AppRunnerVpcConnector", {
      subnets: vpc.selectSubnets({ subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS }).subnetIds,
      securityGroups: [connectorSecurityGroup.securityGroupId],
    });
    egressConfiguration = {
      egressType: "VPC",
      vpcConnectorArn: connector.attrVpcConnectorArn,
    };
  }

  const service = new apprunner.CfnService(scope, "Service", {
    instanceConfiguration: {
      cpu: `${manifest.compute.cpu / 1024} vCPU`,
      memory: `${manifest.compute.memoryMiB / 1024} GB`,
      instanceRoleArn: runtimeRole.roleArn,
    },
    healthCheckConfiguration: {
      protocol: "HTTP",
      path: healthPath(manifest),
    },
    networkConfiguration: { egressConfiguration },
    sourceConfiguration: {
      autoDeploymentsEnabled: false,
      authenticationConfiguration: { accessRoleArn: accessRole.roleArn },
      imageRepository: {
        imageIdentifier,
        imageRepositoryType: "ECR",
        imageConfiguration: {
          port: String(manifest.compute.port),
          runtimeEnvironmentVariables,
          runtimeEnvironmentSecrets,
        },
      },
    },
  });

  return {
    grantPrincipal: runtimeRole,
    vpc,
    securityGroups,
    wafResourceArn: service.attrServiceArn,
    outputs: {
      serviceArn: service.attrServiceArn,
      serviceUrl: `https://${service.attrServiceUrl}`,
    },
    alarmMetrics: [{
      id: "AppRunner5xx",
      label: "App Runner 5xx responses",
      metric: new cloudwatch.Metric({
        namespace: "AWS/AppRunner",
        metricName: "5xxStatusResponses",
        dimensionsMap: { ServiceID: service.attrServiceId },
        statistic: "Sum",
        period: Duration.minutes(5),
      }),
      threshold: 1,
    }],
    addEnvironment: (name, value) => {
      runtimeEnvironmentVariables.push({ name, value });
    },
    addSecretEnvironment: (name, secret) => {
      secret.grantRead(runtimeRole);
      runtimeEnvironmentSecrets.push({ name, value: secret.secretArn });
    },
  };
}

function createPrivateContainer(
  scope: Construct,
  props: WorkloadFactoryProps,
): WorkloadBindings {
  const { manifest, vpc } = props;
  if (!vpc) {
    throw new Error("private-container-service requires a VPC.");
  }
  const cluster = new ecs.Cluster(scope, "Cluster", { vpc });
  const taskDefinition = new ecs.FargateTaskDefinition(scope, "TaskDefinition", {
    cpu: manifest.compute.cpu,
    memoryLimitMiB: manifest.compute.memoryMiB,
  });
  const image = manifest.contractOnly
    ? ecs.ContainerImage.fromRegistry(CONTRACT_CONTAINER_IMAGE)
    : ecs.ContainerImage.fromAsset(resolveManifestPath(manifest, manifest.compute.assetPath!), {
      platform: ecrAssets.Platform.LINUX_AMD64,
    });
  const container = taskDefinition.addContainer("Application", {
    image,
    environment: {
      PORT: String(manifest.compute.port),
      DEPLOYMENT_ARCHETYPE: manifest.archetype,
      CONTRACT_ONLY: String(manifest.contractOnly),
    },
    logging: manifest.observability.logs
      ? ecs.LogDrivers.awsLogs({
        streamPrefix: manifest.name,
        logRetention: retention(manifest),
      })
      : undefined,
  });
  container.addPortMappings({ containerPort: manifest.compute.port });

  const service = new ecsPatterns.ApplicationLoadBalancedFargateService(scope, "Service", {
    cluster,
    taskDefinition,
    desiredCount: manifest.compute.desiredCount,
    publicLoadBalancer: false,
    assignPublicIp: false,
    taskSubnets: { subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS },
    healthCheckGracePeriod: Duration.seconds(60),
  });
  service.targetGroup.configureHealthCheck({
    path: healthPath(manifest),
    healthyHttpCodes: "200-399",
  });

  return {
    grantPrincipal: taskDefinition.taskRole,
    vpc,
    securityGroups: [service.service.connections.securityGroups[0]!],
    wafResourceArn: service.loadBalancer.loadBalancerArn,
    outputs: {
      clusterName: cluster.clusterName,
      serviceName: service.service.serviceName,
      internalLoadBalancerDnsName: service.loadBalancer.loadBalancerDnsName,
    },
    alarmMetrics: [{
      id: "ContainerCpu",
      label: "ECS CPU utilization",
      metric: service.service.metricCpuUtilization(),
      threshold: 80,
    }],
    addEnvironment: (name, value) => container.addEnvironment(name, value),
    addSecretEnvironment: (name, secret) => {
      secret.grantRead(taskDefinition.taskRole);
      container.addSecret(name, ecs.Secret.fromSecretsManager(secret));
    },
  };
}

function createEventWorker(
  scope: Construct,
  props: WorkloadFactoryProps,
): WorkloadBindings {
  const { manifest, encryptionKey } = props;
  const deadLetterQueue = new sqs.Queue(scope, "DeadLetterQueue", {
    encryption: encryptionKey ? sqs.QueueEncryption.KMS : sqs.QueueEncryption.SQS_MANAGED,
    encryptionMasterKey: encryptionKey,
    retentionPeriod: Duration.days(14),
  });
  const queue = new sqs.Queue(scope, "WorkQueue", {
    encryption: encryptionKey ? sqs.QueueEncryption.KMS : sqs.QueueEncryption.SQS_MANAGED,
    encryptionMasterKey: encryptionKey,
    visibilityTimeout: Duration.seconds(180),
    deadLetterQueue: { queue: deadLetterQueue, maxReceiveCount: 5 },
  });
  const securityGroups: ec2.ISecurityGroup[] = [];
  if (props.vpc) {
    securityGroups.push(new ec2.SecurityGroup(scope, "WorkerSecurityGroup", {
      vpc: props.vpc,
      allowAllOutbound: true,
    }));
  }
  const fn = createLambda(scope, "Worker", manifest, props.vpc, securityGroups);
  fn.addEventSource(new lambdaEventSources.SqsEventSource(queue, {
    batchSize: 10,
    reportBatchItemFailures: true,
  }));
  fn.addEnvironment("WORK_QUEUE_URL", queue.queueUrl);

  return {
    grantPrincipal: fn,
    vpc: props.vpc,
    securityGroups,
    outputs: {
      workerFunctionName: fn.functionName,
      workQueueUrl: queue.queueUrl,
      deadLetterQueueUrl: deadLetterQueue.queueUrl,
    },
    alarmMetrics: [
      {
        id: "WorkerErrors",
        label: "Worker Lambda errors",
        metric: fn.metricErrors(),
        threshold: 1,
      },
      {
        id: "QueueAge",
        label: "Oldest queued message age",
        metric: queue.metricApproximateAgeOfOldestMessage(),
        threshold: 300,
      },
    ],
    addEnvironment: (name, value) => fn.addEnvironment(name, value),
  };
}

function createKubernetes(
  scope: Construct,
  props: WorkloadFactoryProps,
): WorkloadBindings {
  const { manifest, vpc } = props;
  if (!vpc) {
    throw new Error("kubernetes requires a VPC.");
  }
  const nodeRole = new iam.Role(scope, "EksNodeRole", {
    assumedBy: new iam.ServicePrincipal("ec2.amazonaws.com"),
    managedPolicies: [
      iam.ManagedPolicy.fromAwsManagedPolicyName("AmazonEKSWorkerNodePolicy"),
      iam.ManagedPolicy.fromAwsManagedPolicyName("AmazonEKS_CNI_Policy"),
      iam.ManagedPolicy.fromAwsManagedPolicyName("AmazonEC2ContainerRegistryReadOnly"),
    ],
  });
  const cluster = new eks.Cluster(scope, "EksCluster", {
    version: eks.KubernetesVersion.of(manifest.compute.kubernetesVersion),
    vpc,
    vpcSubnets: [{ subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS }],
    defaultCapacity: 0,
    endpointAccess: manifest.network.kubernetesPublicEndpoint
      ? eks.EndpointAccess.PUBLIC_AND_PRIVATE
      : eks.EndpointAccess.PRIVATE,
    placeClusterHandlerInVpc: !manifest.network.kubernetesPublicEndpoint,
    clusterLogging: manifest.observability.logs
      ? [
        eks.ClusterLoggingTypes.API,
        eks.ClusterLoggingTypes.AUDIT,
        eks.ClusterLoggingTypes.AUTHENTICATOR,
        eks.ClusterLoggingTypes.CONTROLLER_MANAGER,
        eks.ClusterLoggingTypes.SCHEDULER,
      ]
      : [],
    kubectlLayer: new KubectlV32Layer(scope, "KubectlLayer"),
  });
  const nodeGroup = cluster.addNodegroupCapacity("EksNodeGroup", {
    nodeRole,
    instanceTypes: manifest.compute.kubernetesNodeInstanceTypes.map((value) => new ec2.InstanceType(value)),
    desiredSize: manifest.compute.kubernetesMinNodes,
    minSize: manifest.compute.kubernetesMinNodes,
    maxSize: manifest.compute.kubernetesMaxNodes,
    subnets: { subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS },
  });
  let imageUri = CONTRACT_CONTAINER_IMAGE;
  if (!manifest.contractOnly) {
    const image = new ecrAssets.DockerImageAsset(scope, "KubernetesApplicationImage", {
      directory: resolveManifestPath(manifest, manifest.compute.assetPath!),
      platform: ecrAssets.Platform.LINUX_AMD64,
    });
    image.repository.grantPull(nodeRole);
    imageUri = image.imageUri;
  }
  const environment: Array<{ name: string; value: string }> = [
    { name: "DEPLOYMENT_ARCHETYPE", value: manifest.archetype },
    { name: "CONTRACT_ONLY", value: String(manifest.contractOnly) },
  ];
  let finalized = false;
  const finalize = (): void => {
    if (finalized) {
      return;
    }
    finalized = true;
    const deployment = cluster.addManifest("ApplicationWorkload", {
      apiVersion: "apps/v1",
      kind: "Deployment",
      metadata: { name: manifest.name, labels: { app: manifest.name } },
      spec: {
        replicas: manifest.compute.desiredCount,
        selector: { matchLabels: { app: manifest.name } },
        template: {
          metadata: { labels: { app: manifest.name } },
          spec: {
            containers: [{
              name: "application",
              image: imageUri,
              ports: [{ containerPort: manifest.compute.port }],
              env: environment,
              readinessProbe: {
                httpGet: { path: healthPath(manifest), port: manifest.compute.port },
              },
            }],
          },
        },
      },
    }, {
      apiVersion: "v1",
      kind: "Service",
      metadata: { name: manifest.name },
      spec: {
        type: manifest.publicInterfaces.some((entry) => entry.type === "http")
          ? "LoadBalancer"
          : "ClusterIP",
        selector: { app: manifest.name },
        ports: [{ port: 80, targetPort: manifest.compute.port }],
      },
    });
    deployment.node.addDependency(nodeGroup);
  };

  return {
    grantPrincipal: nodeRole,
    vpc,
    securityGroups: [cluster.clusterSecurityGroup],
    outputs: {
      clusterName: cluster.clusterName,
      clusterEndpoint: cluster.clusterEndpoint,
      applicationImageUri: imageUri,
    },
    alarmMetrics: [],
    addEnvironment: (name, value) => environment.push({ name, value }),
    finalize,
  };
}

export function createWorkload(
  scope: Construct,
  props: WorkloadFactoryProps,
): WorkloadBindings {
  switch (props.manifest.archetype) {
    case "static-web":
      return createStaticWeb(scope, props);
    case "serverless-http":
      return createServerlessHttp(scope, props);
    case "public-web-container":
      return createAppRunner(scope, props);
    case "private-container-service":
      return createPrivateContainer(scope, props);
    case "event-worker":
      return createEventWorker(scope, props);
    case "kubernetes":
      return createKubernetes(scope, props);
    default: {
      const exhaustive: never = props.manifest.archetype;
      throw new Error(`Unsupported archetype: ${exhaustive}`);
    }
  }
}
