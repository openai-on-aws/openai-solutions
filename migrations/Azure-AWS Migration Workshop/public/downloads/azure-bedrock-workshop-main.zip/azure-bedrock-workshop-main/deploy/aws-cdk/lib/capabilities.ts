import { Duration, RemovalPolicy, Stack } from "aws-cdk-lib";
import * as agentcore from "aws-cdk-lib/aws-bedrockagentcore";
import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
import * as docdb from "aws-cdk-lib/aws-docdb";
import * as dynamodb from "aws-cdk-lib/aws-dynamodb";
import * as ec2 from "aws-cdk-lib/aws-ec2";
import * as ecr from "aws-cdk-lib/aws-ecr";
import * as ecrAssets from "aws-cdk-lib/aws-ecr-assets";
import * as elasticache from "aws-cdk-lib/aws-elasticache";
import * as events from "aws-cdk-lib/aws-events";
import * as iam from "aws-cdk-lib/aws-iam";
import * as kms from "aws-cdk-lib/aws-kms";
import * as rds from "aws-cdk-lib/aws-rds";
import * as s3 from "aws-cdk-lib/aws-s3";
import * as secretsmanager from "aws-cdk-lib/aws-secretsmanager";
import * as sns from "aws-cdk-lib/aws-sns";
import * as sqs from "aws-cdk-lib/aws-sqs";
import * as wafv2 from "aws-cdk-lib/aws-wafv2";
import { Construct } from "constructs";
import { AlarmMetric, WorkloadBindings } from "./archetype-factory";
import {
  DataResourceManifest,
  DeploymentManifest,
  resolveManifestPath,
} from "./manifest";

export interface CapabilityFactoryProps {
  readonly manifest: DeploymentManifest;
  readonly workload: WorkloadBindings;
  readonly vpc?: ec2.IVpc;
  readonly encryptionKey?: kms.IKey;
}

export interface CapabilityBindings {
  readonly outputs: Readonly<Record<string, string>>;
}

function constructId(value: string): string {
  return value.split("-").map((part) => part.charAt(0).toUpperCase() + part.slice(1)).join("");
}

function environmentPrefix(value: string): string {
  return value.toUpperCase().replace(/[^A-Z0-9]+/g, "_");
}

function removalPolicy(manifest: DeploymentManifest, data: DataResourceManifest): RemovalPolicy {
  return manifest.contractOnly || !data.retain ? RemovalPolicy.DESTROY : RemovalPolicy.RETAIN;
}

function grantIfPresent(
  principal: iam.IGrantable | undefined,
  action: (principal: iam.IGrantable) => void,
): void {
  if (principal) {
    action(principal);
  }
}

function databaseSecurityGroup(
  scope: Construct,
  id: string,
  vpc: ec2.IVpc,
  workload: WorkloadBindings,
  port: number,
): ec2.SecurityGroup {
  if (workload.securityGroups.length === 0) {
    throw new Error(`${id} requires a VPC-attached workload security group.`);
  }
  const group = new ec2.SecurityGroup(scope, `${id}SecurityGroup`, {
    vpc,
    allowAllOutbound: false,
    description: `Accept ${id} traffic only from the selected workload`,
  });
  for (const source of workload.securityGroups) {
    group.addIngressRule(source, ec2.Port.tcp(port), `${id} from workload`);
  }
  return group;
}

function bindDatabaseSecret(
  workload: WorkloadBindings,
  secret: secretsmanager.ISecret,
  prefix: string,
): void {
  grantIfPresent(workload.grantPrincipal, (principal) => secret.grantRead(principal));
  workload.addEnvironment(`${prefix}_SECRET_ARN`, secret.secretArn);
  workload.addSecretEnvironment?.(`${prefix}_SECRET_JSON`, secret);
}

function createDataCapabilities(
  scope: Construct,
  props: CapabilityFactoryProps,
  outputs: Record<string, string>,
  alarmMetrics: AlarmMetric[],
): void {
  const { manifest, workload, vpc, encryptionKey } = props;
  for (const data of manifest.dataResources) {
    const id = constructId(data.name);
    const prefix = `DATA_${environmentPrefix(data.name)}`;
    switch (data.service) {
      case "dynamodb": {
        const table = new dynamodb.Table(scope, `${id}Table`, {
          partitionKey: { name: "pk", type: dynamodb.AttributeType.STRING },
          sortKey: { name: "sk", type: dynamodb.AttributeType.STRING },
          billingMode: dynamodb.BillingMode.PAY_PER_REQUEST,
          encryption: encryptionKey
            ? dynamodb.TableEncryption.CUSTOMER_MANAGED
            : dynamodb.TableEncryption.AWS_MANAGED,
          encryptionKey,
          pointInTimeRecoverySpecification: {
            pointInTimeRecoveryEnabled: !manifest.contractOnly && data.retain,
          },
          removalPolicy: removalPolicy(manifest, data),
        });
        grantIfPresent(workload.grantPrincipal, (principal) => table.grantReadWriteData(principal));
        workload.addEnvironment(`${prefix}_TABLE_NAME`, table.tableName);
        outputs[`${data.name}TableName`] = table.tableName;
        alarmMetrics.push({
          id: `${id}Throttles`,
          label: `${data.name} DynamoDB throttled requests`,
          metric: table.metricThrottledRequestsForOperations({
            operations: [
              dynamodb.Operation.GET_ITEM,
              dynamodb.Operation.PUT_ITEM,
              dynamodb.Operation.QUERY,
              dynamodb.Operation.UPDATE_ITEM,
            ],
          }),
          threshold: 1,
        });
        break;
      }
      case "s3": {
        const bucket = new s3.Bucket(scope, `${id}Bucket`, {
          blockPublicAccess: s3.BlockPublicAccess.BLOCK_ALL,
          enforceSSL: true,
          encryption: encryptionKey ? s3.BucketEncryption.KMS : s3.BucketEncryption.S3_MANAGED,
          encryptionKey,
          versioned: !manifest.contractOnly && data.retain,
          removalPolicy: removalPolicy(manifest, data),
          autoDeleteObjects: manifest.contractOnly || !data.retain,
        });
        grantIfPresent(workload.grantPrincipal, (principal) => bucket.grantReadWrite(principal));
        workload.addEnvironment(`${prefix}_BUCKET_NAME`, bucket.bucketName);
        outputs[`${data.name}BucketName`] = bucket.bucketName;
        break;
      }
      case "rds-postgresql": {
        if (!vpc) {
          throw new Error("rds-postgresql requires network.enabled=true.");
        }
        const group = databaseSecurityGroup(scope, id, vpc, workload, 5432);
        const database = new rds.DatabaseInstance(scope, `${id}Database`, {
          engine: rds.DatabaseInstanceEngine.postgres({
            version: rds.PostgresEngineVersion.VER_17_9,
          }),
          credentials: rds.Credentials.fromGeneratedSecret("app_admin", { encryptionKey }),
          instanceType: new ec2.InstanceType(data.instanceType ?? "t4g.medium"),
          allocatedStorage: 20,
          maxAllocatedStorage: 100,
          storageEncrypted: true,
          storageEncryptionKey: encryptionKey,
          multiAz: false,
          databaseName: data.databaseName ?? "application",
          vpc,
          vpcSubnets: { subnetType: ec2.SubnetType.PRIVATE_ISOLATED },
          securityGroups: [group],
          publiclyAccessible: false,
          backupRetention: manifest.contractOnly ? Duration.days(0) : Duration.days(7),
          deletionProtection: !manifest.contractOnly && data.retain,
          deleteAutomatedBackups: manifest.contractOnly || !data.retain,
          cloudwatchLogsExports: manifest.observability.logs ? ["postgresql"] : undefined,
          removalPolicy: removalPolicy(manifest, data),
        });
        if (!database.secret) {
          throw new Error("RDS generated credentials secret is unavailable.");
        }
        bindDatabaseSecret(workload, database.secret, prefix);
        workload.addEnvironment(`${prefix}_HOST`, database.dbInstanceEndpointAddress);
        workload.addEnvironment(`${prefix}_PORT`, database.dbInstanceEndpointPort);
        workload.addEnvironment(`${prefix}_DATABASE_NAME`, data.databaseName ?? "application");
        outputs[`${data.name}Endpoint`] = database.dbInstanceEndpointAddress;
        outputs[`${data.name}SecretArn`] = database.secret.secretArn;
        alarmMetrics.push({
          id: `${id}Cpu`,
          label: `${data.name} RDS CPU utilization`,
          metric: database.metricCPUUtilization(),
          threshold: 80,
        });
        break;
      }
      case "aurora-postgresql": {
        if (!vpc) {
          throw new Error("aurora-postgresql requires network.enabled=true.");
        }
        const group = databaseSecurityGroup(scope, id, vpc, workload, 5432);
        const fullVersion = data.engineVersion!;
        const cluster = new rds.DatabaseCluster(scope, `${id}Cluster`, {
          engine: rds.DatabaseClusterEngine.auroraPostgres({
            version: rds.AuroraPostgresEngineVersion.of(fullVersion, fullVersion.split(".")[0]!),
          }),
          credentials: rds.Credentials.fromGeneratedSecret("app_admin", { encryptionKey }),
          writer: rds.ClusterInstance.provisioned("Writer", {
            instanceType: new ec2.InstanceType(data.instanceType ?? "r6g.large"),
          }),
          readers: [],
          storageEncrypted: true,
          storageEncryptionKey: encryptionKey,
          defaultDatabaseName: data.databaseName ?? "application",
          vpc,
          vpcSubnets: { subnetType: ec2.SubnetType.PRIVATE_ISOLATED },
          securityGroups: [group],
          backup: { retention: manifest.contractOnly ? Duration.days(1) : Duration.days(7) },
          deletionProtection: !manifest.contractOnly && data.retain,
          cloudwatchLogsExports: manifest.observability.logs ? ["postgresql"] : undefined,
          removalPolicy: removalPolicy(manifest, data),
        });
        if (!cluster.secret) {
          throw new Error("Aurora generated credentials secret is unavailable.");
        }
        bindDatabaseSecret(workload, cluster.secret, prefix);
        workload.addEnvironment(`${prefix}_HOST`, cluster.clusterEndpoint.hostname);
        workload.addEnvironment(`${prefix}_PORT`, cluster.clusterEndpoint.port.toString());
        workload.addEnvironment(`${prefix}_DATABASE_NAME`, data.databaseName ?? "application");
        outputs[`${data.name}Endpoint`] = cluster.clusterEndpoint.hostname;
        outputs[`${data.name}SecretArn`] = cluster.secret.secretArn;
        alarmMetrics.push({
          id: `${id}Cpu`,
          label: `${data.name} Aurora CPU utilization`,
          metric: cluster.metricCPUUtilization(),
          threshold: 80,
        });
        break;
      }
      case "documentdb": {
        if (!vpc) {
          throw new Error("documentdb requires network.enabled=true.");
        }
        const group = databaseSecurityGroup(scope, id, vpc, workload, 27017);
        const cluster = new docdb.DatabaseCluster(scope, `${id}Cluster`, {
          engineVersion: data.engineVersion,
          masterUser: { username: "app_admin" },
          instanceType: new ec2.InstanceType(data.instanceType ?? "t3.medium"),
          instances: 1,
          storageEncrypted: true,
          kmsKey: encryptionKey,
          vpc,
          vpcSubnets: { subnetType: ec2.SubnetType.PRIVATE_ISOLATED },
          securityGroup: group,
          backup: { retention: manifest.contractOnly ? Duration.days(1) : Duration.days(7) },
          deletionProtection: !manifest.contractOnly && data.retain,
          removalPolicy: removalPolicy(manifest, data),
        });
        if (!cluster.secret) {
          throw new Error("DocumentDB generated credentials secret is unavailable.");
        }
        bindDatabaseSecret(workload, cluster.secret, prefix);
        workload.addEnvironment(`${prefix}_HOST`, cluster.clusterEndpoint.hostname);
        workload.addEnvironment(`${prefix}_PORT`, cluster.clusterEndpoint.port.toString());
        outputs[`${data.name}Endpoint`] = cluster.clusterEndpoint.hostname;
        outputs[`${data.name}SecretArn`] = cluster.secret.secretArn;
        break;
      }
      case "elasticache-redis": {
        if (!vpc) {
          throw new Error("elasticache-redis requires network.enabled=true.");
        }
        const group = databaseSecurityGroup(scope, id, vpc, workload, 6379);
        const subnetGroup = new elasticache.CfnSubnetGroup(scope, `${id}SubnetGroup`, {
          description: `${data.name} private cache subnets`,
          subnetIds: vpc.selectSubnets({ subnetType: ec2.SubnetType.PRIVATE_ISOLATED }).subnetIds,
        });
        const authSecret = new secretsmanager.Secret(scope, `${id}AuthSecret`, {
          encryptionKey,
          generateSecretString: {
            excludePunctuation: true,
            passwordLength: 32,
          },
        });
        authSecret.applyRemovalPolicy(removalPolicy(manifest, data));
        const cache = new elasticache.CfnReplicationGroup(scope, `${id}Cache`, {
          replicationGroupDescription: `${data.name} encrypted cache`,
          engine: "redis",
          engineVersion: data.engineVersion,
          cacheNodeType: data.instanceType ?? "cache.t4g.small",
          numNodeGroups: 1,
          replicasPerNodeGroup: 0,
          cacheSubnetGroupName: subnetGroup.ref,
          securityGroupIds: [group.securityGroupId],
          atRestEncryptionEnabled: true,
          transitEncryptionEnabled: true,
          authToken: authSecret.secretValue.unsafeUnwrap(),
          kmsKeyId: encryptionKey?.keyArn,
        });
        cache.addDependency(subnetGroup);
        bindDatabaseSecret(workload, authSecret, prefix);
        workload.addEnvironment(`${prefix}_HOST`, cache.attrPrimaryEndPointAddress);
        workload.addEnvironment(`${prefix}_PORT`, cache.attrPrimaryEndPointPort);
        outputs[`${data.name}Endpoint`] = cache.attrPrimaryEndPointAddress;
        outputs[`${data.name}SecretArn`] = authSecret.secretArn;
        break;
      }
      default: {
        const exhaustive: never = data.service;
        throw new Error(`Unsupported data service: ${exhaustive}`);
      }
    }
  }
}

function createIntegrationCapabilities(
  scope: Construct,
  props: CapabilityFactoryProps,
  outputs: Record<string, string>,
  alarmMetrics: AlarmMetric[],
): void {
  const { manifest, workload, encryptionKey } = props;
  for (const integration of manifest.integrations.queues) {
    const id = constructId(integration.name);
    const deadLetterQueue = new sqs.Queue(scope, `${id}DeadLetterQueue`, {
      encryption: encryptionKey ? sqs.QueueEncryption.KMS : sqs.QueueEncryption.SQS_MANAGED,
      encryptionMasterKey: encryptionKey,
      retentionPeriod: Duration.days(14),
    });
    const queue = new sqs.Queue(scope, `${id}Queue`, {
      encryption: encryptionKey ? sqs.QueueEncryption.KMS : sqs.QueueEncryption.SQS_MANAGED,
      encryptionMasterKey: encryptionKey,
      visibilityTimeout: Duration.seconds(180),
      deadLetterQueue: { queue: deadLetterQueue, maxReceiveCount: 5 },
    });
    if (integration.mode === "consumer") {
      grantIfPresent(workload.grantPrincipal, (principal) => queue.grantConsumeMessages(principal));
    } else {
      grantIfPresent(workload.grantPrincipal, (principal) => queue.grantSendMessages(principal));
    }
    const prefix = `INTEGRATION_${environmentPrefix(integration.name)}`;
    workload.addEnvironment(`${prefix}_QUEUE_URL`, queue.queueUrl);
    outputs[`${integration.name}QueueUrl`] = queue.queueUrl;
    outputs[`${integration.name}DeadLetterQueueUrl`] = deadLetterQueue.queueUrl;
    alarmMetrics.push({
      id: `${id}QueueAge`,
      label: `${integration.name} queue oldest message age`,
      metric: queue.metricApproximateAgeOfOldestMessage(),
      threshold: 300,
    });
  }

  for (const integration of manifest.integrations.eventBuses) {
    const eventBus = new events.EventBus(scope, `${constructId(integration.name)}EventBus`);
    grantIfPresent(workload.grantPrincipal, (principal) => eventBus.grantPutEventsTo(principal));
    workload.addEnvironment(
      `INTEGRATION_${environmentPrefix(integration.name)}_EVENT_BUS_NAME`,
      eventBus.eventBusName,
    );
    outputs[`${integration.name}EventBusName`] = eventBus.eventBusName;
  }

  for (const integration of manifest.integrations.topics) {
    const topic = new sns.Topic(scope, `${constructId(integration.name)}Topic`, {
      masterKey: encryptionKey,
    });
    grantIfPresent(workload.grantPrincipal, (principal) => topic.grantPublish(principal));
    workload.addEnvironment(
      `INTEGRATION_${environmentPrefix(integration.name)}_TOPIC_ARN`,
      topic.topicArn,
    );
    outputs[`${integration.name}TopicArn`] = topic.topicArn;
  }
}

function createAgentCoreCapability(
  scope: Construct,
  props: CapabilityFactoryProps,
  outputs: Record<string, string>,
): void {
  const { manifest, workload } = props;
  if (!manifest.agentCore.enabled) {
    return;
  }
  if (!workload.grantPrincipal) {
    throw new Error("AgentCore requires a workload IAM principal.");
  }

  let repository: ecr.IRepository;
  let imageTag: string;
  if (manifest.contractOnly) {
    repository = new ecr.Repository(scope, "AgentCoreContractImageRepository", {
      imageScanOnPush: true,
      removalPolicy: RemovalPolicy.DESTROY,
      emptyOnDelete: true,
    });
    imageTag = "contract-only";
  } else {
    const image = new ecrAssets.DockerImageAsset(scope, "AgentCoreImage", {
      directory: resolveManifestPath(manifest, manifest.agentCore.assetPath!),
      platform: ecrAssets.Platform.LINUX_ARM64,
    });
    repository = image.repository;
    imageTag = image.imageTag;
  }

  const stack = Stack.of(scope);
  const executionRole = new iam.Role(scope, "AgentCoreExecutionRole", {
    assumedBy: new iam.ServicePrincipal("bedrock-agentcore.amazonaws.com", {
      conditions: {
        StringEquals: { "aws:SourceAccount": stack.account },
        ArnLike: {
          "aws:SourceArn": `arn:${stack.partition}:bedrock-agentcore:${stack.region}:${stack.account}:*`,
        },
      },
    }),
  });
  executionRole.addToPolicy(new iam.PolicyStatement({
    actions: ["bedrock:CallWithBearerToken"],
    resources: ["*"],
    conditions: { StringEquals: { "bedrock:bearerTokenType": "SHORT_TERM" } },
  }));
  executionRole.addToPolicy(new iam.PolicyStatement({
    actions: [
      "bedrock-mantle:Get*",
      "bedrock-mantle:List*",
      "bedrock-mantle:CreateInference",
    ],
    resources: [`arn:${stack.partition}:bedrock-mantle:${stack.region}:${stack.account}:project/*`],
  }));

  const runtime = new agentcore.Runtime(scope, "AgentCoreRuntime", {
    agentRuntimeArtifact: agentcore.AgentRuntimeArtifact.fromEcrRepository(repository, imageTag),
    executionRole,
    authorizerConfiguration: agentcore.RuntimeAuthorizerConfiguration.usingIAM(),
    networkConfiguration: agentcore.RuntimeNetworkConfiguration.usingPublicNetwork(),
    protocolConfiguration: agentcore.ProtocolType.HTTP,
    tracingEnabled: manifest.agentCore.tracing,
    environmentVariables: {
      BEDROCK_OPENAI_RESPONSES_URL: manifest.agentCore.inferenceUrl!,
      BEDROCK_OPENAI_MODEL_ID: manifest.agentCore.modelId!,
      RESPONSES_STORE: "false",
      APP_PROVIDER: "amazon-bedrock",
    },
  });
  runtime.grantInvokeRuntime(workload.grantPrincipal);
  workload.addEnvironment("AGENTCORE_RUNTIME_ARN", runtime.agentRuntimeArn);
  outputs.agentCoreRuntimeArn = runtime.agentRuntimeArn;
  if (manifest.observability.logs) {
    outputs.agentCoreLogGroupName = runtime.applicationLogGroup.logGroupName;
  }
}

function createGeneratedSecrets(
  scope: Construct,
  props: CapabilityFactoryProps,
  outputs: Record<string, string>,
): void {
  for (const definition of props.manifest.secrets.generated) {
    const secret = new secretsmanager.Secret(scope, `${constructId(definition.name)}Secret`, {
      description: `${definition.name} generated by the deployment stack`,
      encryptionKey: props.encryptionKey,
      generateSecretString: {
        secretStringTemplate: JSON.stringify({ purpose: definition.name }),
        generateStringKey: "value",
        excludePunctuation: true,
        passwordLength: 32,
      },
    });
    secret.applyRemovalPolicy(
      props.manifest.contractOnly || !definition.retain
        ? RemovalPolicy.DESTROY
        : RemovalPolicy.RETAIN,
    );
    if (props.workload.grantPrincipal) {
      secret.grantRead(props.workload.grantPrincipal);
      props.workload.addEnvironment(`${definition.environmentName}_ARN`, secret.secretArn);
    }
    props.workload.addSecretEnvironment?.(definition.environmentName, secret);
    outputs[`${definition.name}SecretArn`] = secret.secretArn;
  }
}

function createWaf(
  scope: Construct,
  props: CapabilityFactoryProps,
  outputs: Record<string, string>,
): void {
  if (!props.manifest.security.waf) {
    return;
  }
  if (!props.workload.wafResourceArn) {
    throw new Error(`${props.manifest.archetype} does not expose a WAF association target.`);
  }
  const webAcl = new wafv2.CfnWebACL(scope, "WebAcl", {
    defaultAction: { allow: {} },
    scope: "REGIONAL",
    visibilityConfig: {
      cloudWatchMetricsEnabled: true,
      metricName: `${props.manifest.name}-waf`,
      sampledRequestsEnabled: true,
    },
    rules: [{
      name: "AWSManagedCommonRules",
      priority: 0,
      overrideAction: { none: {} },
      statement: {
        managedRuleGroupStatement: {
          name: "AWSManagedRulesCommonRuleSet",
          vendorName: "AWS",
        },
      },
      visibilityConfig: {
        cloudWatchMetricsEnabled: true,
        metricName: `${props.manifest.name}-common-rules`,
        sampledRequestsEnabled: true,
      },
    }],
  });
  new wafv2.CfnWebACLAssociation(scope, "WebAclAssociation", {
    resourceArn: props.workload.wafResourceArn,
    webAclArn: webAcl.attrArn,
  });
  outputs.webAclArn = webAcl.attrArn;
}

function createObservability(
  scope: Construct,
  props: CapabilityFactoryProps,
  alarmMetrics: readonly AlarmMetric[],
  outputs: Record<string, string>,
): void {
  if (!props.manifest.observability.alarms && !props.manifest.observability.dashboard) {
    return;
  }
  const metrics: cloudwatch.IMetric[] = [];
  for (const candidate of alarmMetrics) {
    metrics.push(candidate.metric);
    if (props.manifest.observability.alarms) {
      const alarm = new cloudwatch.Alarm(scope, `${candidate.id}Alarm`, {
        metric: candidate.metric,
        threshold: candidate.threshold,
        evaluationPeriods: 1,
        datapointsToAlarm: 1,
        treatMissingData: cloudwatch.TreatMissingData.NOT_BREACHING,
        alarmDescription: candidate.label,
      });
      outputs[`${candidate.id}AlarmName`] = alarm.alarmName;
    }
  }
  if (props.manifest.observability.dashboard && metrics.length > 0) {
    const dashboard = new cloudwatch.Dashboard(scope, "Dashboard");
    dashboard.addWidgets(new cloudwatch.GraphWidget({
      title: `${props.manifest.name} workload signals`,
      left: metrics,
      width: 24,
    }));
    outputs.dashboardName = dashboard.dashboardName;
  }
}

export function createCapabilities(
  scope: Construct,
  props: CapabilityFactoryProps,
): CapabilityBindings {
  const outputs: Record<string, string> = {};
  const alarmMetrics = [...props.workload.alarmMetrics];
  createDataCapabilities(scope, props, outputs, alarmMetrics);
  createIntegrationCapabilities(scope, props, outputs, alarmMetrics);
  createAgentCoreCapability(scope, props, outputs);
  createGeneratedSecrets(scope, props, outputs);
  createWaf(scope, props, outputs);
  createObservability(scope, props, alarmMetrics, outputs);
  return { outputs };
}
