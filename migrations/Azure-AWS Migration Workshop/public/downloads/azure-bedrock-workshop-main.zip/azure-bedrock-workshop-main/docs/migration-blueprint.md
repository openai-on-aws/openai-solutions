# Migration Blueprint

## Principle

Preserve observed application behavior, isolate provider-specific inference code, and make every migration claim traceable to source files, captured baseline evidence, or official AWS documentation.

The shopping cart is the release fixture, not the schema. For any selected application, Codex must discover public interfaces, build/run commands, state, data, identity, networking, Azure services, and Azure OpenAI behavior before proposing a target.

## Chat Completions To Responses Review

The migration contract explicitly covers:

- message and role conversion, including system/developer semantics;
- synchronous and streaming behavior;
- tools and tool-result round trips;
- structured output and schema enforcement;
- multimodal inputs and outputs;
- conversation or response state;
- error, retry, timeout, throttling, and cancellation behavior;
- output extraction and usage accounting;
- source parameters that must be omitted or transformed;
- `store: false` unless supported state retention is deliberately approved.

This is not a model-name replacement. If GPT-5.4 or GPT-5.5 on Bedrock Responses cannot preserve a required behavior, Codex stops with a blocker.

The selected model, Region, and endpoint are verified through the participant account's live `/v1/models` endpoint before `APPROVE MIGRATION`. Target generation uses only the resulting accepted model/API decision.

## Remediation Gate

When the source does not fit a validated archetype or API behavior:

1. The architect proposes the smallest behavior-preserving transformation.
2. Validation defines regression risks and acceptance checks.
3. The main session presents exact code, architecture, cost, and operational changes.
4. The participant enters `APPROVE MIGRATION`.
5. Codex applies the approved change and reruns discovery and validation.

## Data Scope

The workshop may create target schemas, migrations, and sandbox seed data. It does not move production records. The deploy package includes a separate production data migration plan with validation, rollback, reconciliation, and cutover considerations.

## Required Artifacts

All working artifacts remain under `/tmp/workshop-artifacts`:

- `migration-context.json`
- `source-profile.json`
- `architecture-decision.json`
- `model-api-decision.json`
- `migration-guide.md`
- `migration-approval.md`
- `validation-review.md`
- `deployment-manifest.json`
- `production-data-migration-plan.md`

The generated application is written to the approved target root, defaulting to `apps/aws-target-app`.
