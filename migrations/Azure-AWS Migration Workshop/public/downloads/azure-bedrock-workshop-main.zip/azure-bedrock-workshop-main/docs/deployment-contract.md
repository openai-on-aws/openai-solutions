# Deployment Contract

`deployment-manifest.json` is the boundary between migration design and infrastructure generation. It is validated before CDK reads it.

## Required Decisions

The manifest records:

- selected compute archetype and target root;
- public interfaces and health checks;
- compute, container image, and platform requirements;
- data stores and sandbox schema/seed strategy;
- queues, topics, buses, schedules, or other integrations;
- VPC, ingress, egress, and private connectivity requirements;
- secret references and runtime identities;
- logs, metrics, traces, alarms, and retention;
- optional AgentCore requirements with source evidence;
- complete teardown inventory.

## CDK Modes

The checked-in CDK package can synthesize validated example manifests without a generated target. During the workshop, `aws-deployment-engineer` creates a target-specific manifest and any required Dockerfiles or handler packages, then validation builds assets and synthesizes CloudFormation.

CDK synthesis does not authorize deployment. `cdk deploy` is prohibited until the read-only preflight is presented and the participant enters `DEPLOY`.
