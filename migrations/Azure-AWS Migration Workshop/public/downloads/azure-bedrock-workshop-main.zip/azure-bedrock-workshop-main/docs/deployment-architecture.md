# Deployment Architecture Selection

Deployment is generated from the validated `deployment-manifest.json`; it is not a fixed App Runner, RDS, NAT, or AgentCore stack.

## Selection Rules

- Choose the simplest supported compute archetype that preserves observed behavior.
- Add state, integration, network, secrets, and observability resources only when source evidence or an approved transformation requires them.
- Use AgentCore only for genuine agent, tool, session, memory, or orchestration requirements.
- Generate schemas and sandbox seed data, never production data movement.
- Keep physical names stack-generated so participant accounts remain isolated.
- Record every billable resource in `teardown_inventory`.

## Runtime Identity

Local validation may use an Amazon Bedrock API key entered securely in a terminal. Deployed workloads use AWS workload identity and managed secrets appropriate to the selected service; long-term keys are not embedded in images, templates, environment examples, or task artifacts.

## Release Gates

Before `DEPLOY`, the deployment engineer performs read-only checks for caller identity, Region, model/API availability, quotas, permissions, expected billable resources, container platforms, synthesized CloudFormation, and `cdk diff`. The participant must then enter `DEPLOY`.

Before teardown, Codex presents the complete inventory and waits for `DESTROY`. Cleanup verification must prove that workshop-created billable resources are gone; reusable CDK bootstrap resources are reported separately.
