# Evidence-Driven Architecture

The workshop does not begin with a fixed AWS diagram. Codex first produces `source-profile.json`, then the architect ranks two or three supported AWS archetypes and records the decision in `architecture-decision.json`.

## Migration Control Flow

```mermaid
flowchart LR
  S["Selected Azure OpenAI application"] --> D["migration-discovery"]
  D --> SP["source-profile.json"]
  SP --> A["migration-architect"]
  A --> AD["architecture-decision.json"]
  A --> MD["model-api-decision.json"]
  AD --> V["migration-validation"]
  MD --> V
  V --> R["migration-architect resolves findings"]
  R --> M["Live /v1/models verification"]
  M --> G{"APPROVE MIGRATION"}
  G --> T["Generated AWS target"]
  T --> L["Local live Responses validation"]
  L --> E["aws-deployment-engineer"]
  E --> DM["deployment-manifest.json and CDK"]
  DM --> P{"DEPLOY"}
  P --> AWS["Participant AWS sandbox"]
  AWS --> X{"DESTROY"}
```

## Supported Compute Archetypes

| Archetype | Select when evidence shows | AWS target |
|---|---|---|
| `static-web` | Static assets and no server runtime | S3 and CloudFront |
| `serverless-http` | Bounded stateless HTTP handlers | Lambda and API Gateway |
| `public-web-container` | One public containerized web service | App Runner |
| `private-container-service` | Private networking, multiple services, or deeper container control | ECS Fargate and ALB |
| `event-worker` | Queue, topic, schedule, or event-driven processing | Lambda or ECS with SQS/SNS/EventBridge |
| `kubernetes` | Existing Kubernetes contracts that cannot be removed cheaply | EKS |

AgentCore is not a default compute layer. It is conditional on evidence of agent loops, tools, sessions, memory, or orchestration.

## Conditional Service Mapping

| Azure evidence | Candidate AWS service | Required proof |
|---|---|---|
| Azure SQL, PostgreSQL, or MySQL | RDS or Aurora | Engine and feature compatibility |
| Cosmos DB document/key-value | DynamoDB | Access-pattern and consistency compatibility |
| Cosmos DB Mongo API | DocumentDB | Driver and feature compatibility |
| Blob Storage | S3 | Object semantics, events, and access policy |
| Service Bus | SQS and/or SNS | Queue/topic semantics, ordering, and delivery |
| Event Grid | EventBridge | Event schema and routing behavior |
| Key Vault | Secrets Manager and KMS | Secret lifecycle and key ownership |
| Azure Cache for Redis | ElastiCache | Engine/version and persistence requirements |
| Azure Monitor/Application Insights | CloudWatch and optional X-Ray | Logs, metrics, traces, and retention |
| Azure OpenAI Chat Completions | Bedrock OpenAI Responses | Model/API/Region tuple and behavior parity |

## Model/API Decision

The architect may recommend only `openai.gpt-5.4` or `openai.gpt-5.5`, and only when the selected Region and account expose a compatible Responses API tuple. `model-api-decision.json` records both URLs separately:

- model discovery: `https://bedrock-mantle.{region}.api.aws/v1/models`
- inference: the exact model-card URL ending in `/responses`

This separation prevents the common error of deriving model discovery from the inference base, or deriving inference from a generic Mantle example.

The participant workshop supports these commercial in-Region combinations from the current model cards:

- `openai.gpt-5.4`: `us-east-1`, `us-east-2`, and `us-west-2`.
- `openai.gpt-5.5`: `us-east-1` and `us-east-2`.

GovCloud is outside the participant sandbox scope. Before migration approval, Codex must verify the selected tuple through the participant account's `/v1/models` endpoint and change the model/API decision to `accepted` with redacted live evidence.

## Grounding

- [Amazon Bedrock Mantle](https://docs.aws.amazon.com/bedrock/latest/userguide/bedrock-mantle.html)
- [GPT-5.4 model card](https://docs.aws.amazon.com/bedrock/latest/userguide/model-card-openai-gpt-54.html)
- [GPT-5.5 model card](https://docs.aws.amazon.com/bedrock/latest/userguide/model-card-openai-gpt-55.html)
- [API compatibility](https://docs.aws.amazon.com/bedrock/latest/userguide/models-api-compatibility.html)
- [Model information and listing](https://docs.aws.amazon.com/bedrock/latest/userguide/models-get-info.html)
